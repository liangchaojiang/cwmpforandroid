package android.net.ethernet;

import android.os.Handler;
import android.os.RemoteException;
import android.util.Log;

public class DualStackManager {
    public static final String TAG = "DualStackManager";
    public static final int DUALSTACK_STATE_UNKNOWN = -1;
    public static final int DUALSTACK_STATE_DISABLED = 0;
    public static final int DUALSTACK_STATE_ENABLED = 1;

    public static final int EVENT_IPOE_START = 0;
    public static final int EVENT_IPOE_SUCCEEDED = 1;
    public static final int EVENT_PPPOE_START = 2;
    public static final int EVENT_PPPOE_SUCCEEDED = 3;
    public static final int EVENT_IPOE_FAILED = 4;
    public static final int EVENT_PPPOE_FAILED = 5;

    IDualStackManager mService;
    Handler mHandler;

    public DualStackManager(IDualStackManager service, Handler handler) {
        mService = service;
        mHandler = handler;
    }

    public boolean setDualStackEnabled(boolean enabled){
        try {
            return mService.setDualStackEnabled(enabled);
        } catch (RemoteException e) {
            Log.e(TAG, "[setDualStackEnabled] RemoteException");
        }
        return false;
    }

    public int getDualStackState() {
        try {
            return mService.getDualStackState();
        } catch (RemoteException e) {
            Log.e(TAG, "[getDualStackState] RemoteException");
        }
        return DUALSTACK_STATE_UNKNOWN;
    }
}
