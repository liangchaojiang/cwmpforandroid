package android.net.ethernet;

import java.util.List;
import java.net.UnknownHostException;
import java.net.InetAddress;

import android.annotation.SdkConstant;
import android.annotation.SdkConstant.SdkConstantType;
import android.net.wifi.IWifiManager;
import android.os.Handler;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.util.Slog;
import android.net.DhcpInfo;
import android.net.NetworkUtils;


public class EthernetManager {
    public static final String TAG = "EthernetManager";
    public static final int ETH_DEVICE_SCAN_RESULT_READY = 0;
    public static final String ETH_STATE_CHANGED_ACTION =
            "android.net.ethernet.ETH_STATE_CHANGED";
    public static final String NETWORK_STATE_CHANGED_ACTION =
            "android.net.ethernet.STATE_CHANGE";

    public static final String EXTRA_NETWORK_INFO = "networkInfo";
    public static final String EXTRA_ETH_STATE = "eth_state";
    public static final String EXTRA_ETHERNET_STATE = "ethernet_state";
    public static final int ETHERNET_DEVICE_SCAN_RESULT_READY = 0;
    public static final String ETHERNET_STATE_CHANGED_ACTION =	"android.net.ethernet.ETHERNET_STATE_CHANGE";
    public static final String IPV6_STATE_CHANGED_ACTION = "android.net.ethernet.IPV6_STATE_CHANGE";
    public static final int ETHERNET_STATE_DISABLED = 0;
    public static final int ETHERNET_STATE_ENABLED = 1;
    public static final int ETHERNET_STATE_UNKNOWN = 2;
    public static final int EVENT_DHCP_CONNECT_SUCCESSED = 10;
    public static final int EVENT_DHCP_CONNECT_FAILED = 11;
    public static final int EVENT_DHCP_DISCONNECT_SUCCESSED = 12;
    public static final int EVENT_DHCP_DISCONNECT_FAILED = 13;
    public static final int EVENT_STATIC_CONNECT_SUCCESSED = 14;
    public static final int EVENT_STATIC_CONNECT_FAILED = 15;
    public static final int EVENT_STATIC_DISCONNECT_SUCCESSED = 16;
    public static final int EVENT_STATIC_DISCONNECT_FAILED = 17;
    public static final int EVENT_PHY_LINK_UP =18;
    public static final int EVENT_PHY_LINK_DOWN = 19;
    public static final int IPV6_STATE_DISABLED = 0;
    public static final int IPV6_STATE_ENABLED = 1;
    public static final int IPV6_STATE_UNKNOWN = 2;
    public static final int IPV6_DHCP_START = 3;
    public static final int IPV6_DHCP_STOP = 4;
    public static final int IPV6_STATIC_START = 5;
    public static final int IPV6_STATIC_STOP = 6;
    public static final int EVENT_DHCPV6_CONNECT_SUCCESSED = 20;
    public static final int EVENT_DHCPV6_CONNECT_FAILED = 21;
    public static final int EVENT_STATIC6_CONNECT_SUCCESSED = 14;
    public static final int EVENT_STATIC6_CONNECT_FAILED = 15;
	public static final int EVENT_IPOE_CONNECT_SUCCESSED = 31;
	public static final int EVENT_IPOE_CONNECT_FAILED = 32;
	public static final int EVENT_IPOE_DISCONNECT_SUCCESSED = 33;
	public static final int EVENT_IPOE_DISCONNECT_FAILED = 34;
    /**
       * The ethernet interface is configured by dhcp
    */
    public static final String ETHERNET_CONNECT_MODE_DHCP = "dhcp";
    /**
       * The ethernet interface is configured manually
    */
    public static final String ETHERNET_CONNECT_MODE_MANUAL = "manual";
	public static final String ETHERNET_CONNECT_MODE_DHCP_AUTH = "dhcp_auth";
    public static final String EXTRA_PREVIOUS_ETH_STATE = "previous_eth_state";

    public static final int ETH_STATE_UNKNOWN = 0;
    public static final int ETH_STATE_DISABLED = 1;
    public static final int ETH_STATE_ENABLED = 2;

    IEthernetManager mService;
    Handler mHandler;

    public EthernetManager(IEthernetManager service, Handler handler) {
        Slog.i(TAG, "Init Ethernet Manager");
        mService = service;
        mHandler = handler;
    }

    public boolean isEthConfigured() {
        try {
            return mService.isEthConfigured();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not check eth config state");
        }
        return false;
    }

    public boolean isEthernetConfigured() {
	 return isEthConfigured();
    }

    public EthernetDevInfo getSavedEthConfig() {
        try {
            return mService.getSavedEthConfig();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get eth config");
        }
        return null;
    }

    private void printStackTrace() {
        Thread t = Thread.currentThread();
        StackTraceElement st[]= t.getStackTrace();
        Slog.i(TAG, "Thread " + t.getName() +"(#" + t.getId() + ")");
        for(int i=2;i<st.length;i++)
            Slog.i(TAG, i+":"+st[i]);

        Slog.i(TAG, "\n\n");
    }

    public void updateEthDevInfo(EthernetDevInfo info) {
        printStackTrace();
        try {
            mService.UpdateEthDevInfo(info);
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not update ethernet device info");
        }
    }

    public String[] getDeviceNameList() {
        try {
            return mService.getDeviceNameList();
        } catch (RemoteException e) {
            return null;
        }
    }

    public String getAuthUsername() {
        try {
            return mService.getAuthUsername();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth username");
        }
        return null;
    }

    public String getAuthPassword() {
        try {
            return mService.getAuthPassword();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth password");
        }
        return null;
    }
    
    public String getAuthVendorid() {
        try {
            return mService.getAuthVendorid();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth vendorid");
        }
        return null;
    }
    
    public boolean getAuthState() {
        try {
            return mService.getAuthState();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth state");
        }
        return false;
    }
	public boolean getAuthOption125status(){
        try {
            return mService.getAuthOption125status();
        } catch (RemoteException e) {

        }
        return false;
    }
	public boolean setAuthOption125(boolean enable, String option125Info){
        try {
            return mService.setAuthOption125(enable, option125Info);
        } catch (RemoteException e) {

        }
		return false;
	}

    public boolean setAuthState(String username, String password, String vendorid, boolean enable) {
        try {
            return mService.setAuthState(username, password, vendorid, enable);
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not set auth state, username: " + username + ", password" + password
                    + ", vendorid: " + vendorid + ", enable: " + enable);
        }
        return false;
    }

    public void setEthEnabled(boolean enable) {
        try {
            mService.setEthState(enable ? ETH_STATE_ENABLED:ETH_STATE_DISABLED);
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not set new state");
        }
    }


    public void setEthDhcp(boolean enabled) {
        try {
            mService.setEthernetDhcp(enabled);
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not set Ethernet Dhcp");
        }
    }

    public int getEthState( ) {
        try {
            return mService.getEthState();
        } catch (RemoteException e) {
            return 0;
        }
    }
    
    /**
    * @param mode
    * ETHERNET_CONNECT_MODE_DHCP or ETHERNET_CONNECT_MODE_MANUAL
    * @param dhcpInfo
    * if mode is ETHERNET_CONNECT_MODE_MANUAL,it is Required.
    */
    public void setEthernetMode(String mode, DhcpInfo dhcpInfo) {
	    try {
			mService.setEthMode(mode);
			if(mode.equals(ETHERNET_CONNECT_MODE_MANUAL)) {
				Slog.d(TAG, "setEthernetMode--dhcpInfo.ipAddress : " + NetworkUtils.intToInetAddress(dhcpInfo.ipAddress).getHostAddress());
				Slog.d(TAG, "setEthernetMode--dhcpInfo.dns1 : " + NetworkUtils.intToInetAddress(dhcpInfo.dns1).getHostAddress());
				Slog.d(TAG, "setEthernetMode--dhcpInfo.dns2 : " + NetworkUtils.intToInetAddress(dhcpInfo.dns2).getHostAddress());
				Slog.d(TAG, "setEthernetMode--dhcpInfo.gateway : " + NetworkUtils.intToInetAddress(dhcpInfo.gateway).getHostAddress());
				Slog.d(TAG, "setEthernetMode--dhcpInfo.netmask : " + NetworkUtils.intToInetAddress(dhcpInfo.netmask).getHostAddress());
				//TODO with dhcpInfo
				//ipAddress; gateway; netmask; dns1; dns2
				EthernetDevInfo ethDevInfo = getSavedEthConfig();
				if(ethDevInfo != null) {
					ethDevInfo.setIpAddress(NetworkUtils.intToInetAddress(dhcpInfo.ipAddress).getHostAddress());
					ethDevInfo.setDns1Addr(NetworkUtils.intToInetAddress(dhcpInfo.dns1).getHostAddress());
					ethDevInfo.setDns2Addr(NetworkUtils.intToInetAddress(dhcpInfo.dns2).getHostAddress());
					ethDevInfo.setRouteAddr(NetworkUtils.intToInetAddress(dhcpInfo.gateway).getHostAddress());
					ethDevInfo.setNetMask(NetworkUtils.intToInetAddress(dhcpInfo.netmask).getHostAddress());
					updateEthDevInfo(ethDevInfo);
				}
			}
		} catch (RemoteException e) {
		}
     }

     /**
     * @return
     */
     public String getEthernetMode() {
	     String ethMode = null;
	     EthernetDevInfo ethDevInfo = getSavedEthConfig();
	     if(ethDevInfo != null) {
		 	ethMode = ethDevInfo.getConnectMode();
		}
         if(ethMode != null)
            return ethMode;
         else
            return "null";
	}

	 /**
	 * @return
	 */
	 public String getInterfaceName() {
	 	String interfaceName = null;
		EthernetDevInfo ethDevInfo = getSavedEthConfig();
		if(ethDevInfo != null) {
			interfaceName = ethDevInfo.getIfName();
		}
		return interfaceName;
	}

	public boolean setInterfaceName(String iface) {
		if(iface != null && !iface.equals("")) {
			EthernetDevInfo ethDevInfo = getSavedEthConfig();
			if(ethDevInfo != null) {
				ethDevInfo.setIfName(iface);
				Slog.d(TAG, "FIXME!!! BUG-99514. DO NOT call updateEthDevInfo() in setInterfaceName(), for it will trigger dhcp");
				//updateEthDevInfo(ethDevInfo);
			}
		}
		return true;
	}

	/**
	* @param enable ETHERNET_STATE_DISABLED or ETHERNET_STATE_ENABLED
	*/
	public void setEthernetEnabled(boolean enable) {
		setEthEnabled(enable);
	}

	/**
	* @return
	*/
	public int getEthernetState() {
		int ethState = ETHERNET_STATE_UNKNOWN;
		int state = getEthState();
		if(state == ETH_STATE_UNKNOWN) {
			ethState = ETHERNET_STATE_UNKNOWN;
		}else if(state == ETH_STATE_DISABLED) {
			ethState = ETHERNET_STATE_DISABLED;
		}else if(state == ETH_STATE_ENABLED) {
			ethState = ETHERNET_STATE_ENABLED;
		}
		return ethState;
	}

	/*
	* @param enable
	*/
	public void setWifiDisguise(boolean enable) {
	}

	/**
	* @return
	*/
	public boolean getWifiDisguiseState() {
		return false;
	}
	
   public boolean getNetLinkStatus() {
   	return getNetLinkStatus(getInterfaceName()) > 0;
   }

   public int getNetLinkStatus(String ifaceName) {
   	try {
		return mService.isEthDeviceUp() ? 1:0;
	} catch (RemoteException e) {
		return 0;
	}
    }

    public boolean ethConfigured() {
        try {
            return mService.isEthConfigured();
        } catch (RemoteException e) {
            return false;
        }
    }

	public int StringIpToInt(String str){
		InetAddress address = null;
		try{
			address = InetAddress.getByName(str);
		}catch (UnknownHostException e){
			e.printStackTrace();
		}
		int ip = NetworkUtils.inetAddressToInt(address);
		return ip;
	}

    public DhcpInfo getDhcpInfo() {
		String tenderType = SystemProperties.get("sys.proj.tender.type", "");
		Slog.d(TAG, "===,getDhcpInfo,tenderType:"+tenderType);
		if("jiangxi".equals(tenderType)){
			String mode = getEthernetMode();
			Slog.d(TAG, "===,getDhcpInfo,mode:"+mode);
			if("pppoe".equals(mode)){
				Slog.d(TAG, "===,getDhcpInfo,pppoe");
				DhcpInfo info = new DhcpInfo();
				info.ipAddress = StringIpToInt(SystemProperties.get("dhcp.ppp0.ipaddress", "0.0.0.0"));
				info.gateway = StringIpToInt(SystemProperties.get("dhcp.ppp0.gateway", "0.0.0.0"));
				info.netmask = StringIpToInt(SystemProperties.get("dhcp.ppp0.mask", "0.0.0.0"));
				info.dns1 = StringIpToInt(SystemProperties.get("dhcp.ppp0.dns1", "0.0.0.0"));
				info.dns2 = StringIpToInt(SystemProperties.get("dhcp.ppp0.dns2", "0.0.0.0"));
				info.serverAddress = StringIpToInt(SystemProperties.get("dhcp.ppp0.gateway", "0.0.0.0"));
				return info;
			}else{
				try {
					return mService.getDhcpInfo();
				} catch (RemoteException e) {
					return null;
				}
			}
		}

		Slog.d(TAG, "===,getDhcpInfo,3");
        try {
            return mService.getDhcpInfo();
        } catch (RemoteException e) {
            return null;
        }
    }

    public int getTotalInterface() {
        try {
            return mService.getTotalInterface();
        } catch (RemoteException e) {
            return 0;
        }
    }

    public void ethSetDefaultConf() {
        try {
            mService.setEthMode(EthernetDevInfo.ETH_CONN_MODE_DHCP);
        } catch (RemoteException e) {
        }
    }

    public boolean isEthDeviceUp() {
        try {
            return mService.isEthDeviceUp();
        } catch (RemoteException e) {
            return false;
        }
    }

    public boolean isEthernetDeviceUp(String ifname) {
        try {
            return mService.isEthernetDeviceUp(ifname);
        } catch (RemoteException e) {
            return false;
        }
    }

    public boolean isEthDeviceAdded() {
        try {
            return mService.isEthDeviceAdded();
        } catch (RemoteException e) {
            return false;
        }
    }

    public void disconnect() {
        try {
            mService.disconnect();
        } catch (RemoteException e) {
        }
    }

    public boolean isEthernetDeviceAdded(String ifname) {
        try {
            return mService.isEthernetDeviceAdded(ifname);
        } catch (RemoteException e) {
            return false;
        }
    }

    public void enableIpv6(boolean enable) {
        try {
            mService.enableIpv6(enable);
        } catch (RemoteException e) {
        }
    }

    public int getIpv6PersistedState() {
        try {
            return mService.getIpv6PersistedState();
        } catch (RemoteException e) {
		  return EthernetManager.IPV6_STATE_UNKNOWN;
        }
    }

    public void setEthernetMode6(String mode){
        try {
            mService.setEthernetMode6(mode);
        } catch (RemoteException e) {
        }
    }

    public void setEthernetDefaultConf6() {
        try {
            mService.setEthernetDefaultConf6();
        } catch (RemoteException e) {
        }
    }

    public String getEthernetMode6()  {
        try {
            return mService.getEthernetMode6();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public void setIpv6DatabaseInfo(String ip, int prefixlength, String gw, String dns1, String dns2) {
        try {
            mService.setIpv6DatabaseInfo(ip, prefixlength, gw, dns1, dns2);
        } catch (RemoteException e) {
        }
    }

    public String getIpv6DatabaseAddress() {
        try {
            return mService.getIpv6DatabaseAddress();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public int getIpv6DatabasePrefixlength(){
        try {
            return mService.getIpv6DatabasePrefixlength();
        } catch (RemoteException e) {
		    return 0;
        }
    }
    public String getIpv6DatabaseDns1() {
        try {
            return mService.getIpv6DatabaseDns1();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public String getIpv6DatabaseDns2(){
        try {
            return mService.getIpv6DatabaseDns2();
        } catch (RemoteException e) {
		    return null;
        }
    }
    public String getIpv6DatabaseGateway() {
        try {
            return mService.getIpv6DatabaseGateway();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public boolean checkDhcpv6Status(String ifname){
        try {
            return mService.checkDhcpv6Status(ifname);
        } catch (RemoteException e) {
		    return false;
        }
    }
    public String getDhcpv6Ipaddress(String ifname) {
        try {
            return mService.getDhcpv6Ipaddress(ifname);
        } catch (RemoteException e) {
		    return null;
        }
    }

    public String getDhcpv6Gateway(){
        try {
            return mService.getDhcpv6Gateway();
        } catch (RemoteException e) {
		    return null;
        }
    }
    public int getDhcpv6Prefixlen(String ifname) {
        try {
            return mService.getDhcpv6Prefixlen(ifname);
        } catch (RemoteException e) {
            return 0;
        }
    }

    public String getDhcpv6Dns(String ifname, int number){
        try {
            return mService.getDhcpv6Dns(ifname, number);
        } catch (RemoteException e) {
		    return null;
        }
    }

    public int getDhcpv6DnsCnt(String ifname){
        try {
            return mService.getDhcpv6DnsCnt(ifname);
        } catch (RemoteException e) {
		    return 0;
        }
    }

    public boolean releaseDhcpLease(String ifname){
        try {
            return mService.releaseDhcpLease(ifname);
        } catch (RemoteException e) {
		    return false;
        }
    }
}
