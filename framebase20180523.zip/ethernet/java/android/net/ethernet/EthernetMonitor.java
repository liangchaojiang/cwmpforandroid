package android.net.ethernet;

import java.util.regex.Matcher;

import android.net.NetworkInfo;
import android.util.Config;
import android.util.Slog;
import java.util.StringTokenizer;

/**
 * Listens for events for ethernet, and passes them on
 * to the {@link EthernetStateTracker} for handling. Runs in its own thread.
 *
 * @hide
 */
public class EthernetMonitor {
    private static final String TAG = "EthernetMonitor";
    private static final int CONNECTED  = 1;
    private static final int PHYDOWN = 2;
    private static final int PHYUP = 3;
    private static final int DEVADDED = 4;
    private static final int DEVREMOVED = 5;
    private static final int IPREMOVED = 6;
    private static final int IPADDED = 7;
    private static final String connectedEvent =    "CONNECTED";
    private static final String disconnectedEvent = "DISCONNECTED";
    private static final int ADD_ADDR = 20;
    private static final int RM_ADDR = 21;
    private static final int NEW_LINK = 16;
    private static final int DEL_LINK = 17;
    private static final boolean DEBUG = true;

    private EthernetStateTracker mTracker;

    public EthernetMonitor(EthernetStateTracker tracker) {
        mTracker = tracker;
    }

    public void startMonitoring() {
        new MonitorThread().start();
    }

    class MonitorThread extends Thread {

        public MonitorThread() {
            super("EthMonitor");
        }

        public void run() {
            int index;
            int i;

            //noinspection InfiniteLoopStatement
            for (;;) {
                String eventName = EthernetNative.waitForEvent();

                if (eventName == null) {
                    continue;
                }
                if (DEBUG) Slog.i(TAG, "EVENT[" + eventName+"]");
                /*
                 * Map event name into event enum
                 */
                String [] events = eventName.split(":");
                index = events.length;
                if (index < 2)
                    continue;
                i = 0;
                while (index != 0 && i < index-1) {
                    int event = 0;
                    if ("added".equals(events[i+1]) ) {
                        event = DEVADDED;
                        handleEvent(events[i],event);
                    }
                    else if ("removed".equals(events[i+1])) {
                        event = DEVREMOVED;
                        handleEvent(events[i],event);
                    }
                    else {
                    int cmd =Integer.parseInt(events[i+1]);
                    if ( cmd == DEL_LINK) {
                        event = PHYDOWN;
                        handleEvent(events[i],event);
                    }
                    else if (cmd == ADD_ADDR) {
                        event = CONNECTED;
                        handleEvent(events[i],event);
                    }
                    /*
                    BUG:
                    After calling NetworkUtils.stopDhcp("eth0");
                    or run command:
                        ifconfig eth0 0.0.0.0
                    IP address and route about eth0 is cleared,
                    but 'dumpsys connectivity' still says that Ethernet is connected.
                    Handle RM_ADDR to fix the bug.
                    */
                    else if (cmd == RM_ADDR) {
                        event = IPREMOVED;
                        handleEvent(events[i],event);
                    }
                    else if (cmd == NEW_LINK) {
                        event = PHYUP;
                        handleEvent(events[i],event);
                    }
                    }
                    i = i + 2;
                }
            }
        }
        /**
         * Handle all supplicant events except STATE-CHANGE
         * @param event the event type
         * @param remainder the rest of the string following the
         * event name and &quot;&#8195;&#8212;&#8195;&quot;
         */
        void handleEvent(String ifname,int event) {
            switch (event) {
                case DEVADDED:
                    mTracker.notifyDeviceAdded(ifname);
                    break;
                case DEVREMOVED:
                    mTracker.notifyDeviceRemoved(ifname);
                    break;
                case PHYDOWN:
                    //mTracker.notifyStateChange(ifname,NetworkInfo.DetailedState.DISCONNECTED);
                    mTracker.notifyPhyDisConnected(ifname);
                    break;
                case IPREMOVED:
                    //mTracker.notifyIpRemoved(ifname);
                    break;
                case CONNECTED:
                    mTracker.notifyStateChange(ifname,NetworkInfo.DetailedState.CONNECTED);
                    break;
                case PHYUP:
                    mTracker.notifyPhyConnected(ifname);
                    break;
                default:
                    mTracker.notifyStateChange(ifname,NetworkInfo.DetailedState.FAILED);
            }
        }

    }
}
