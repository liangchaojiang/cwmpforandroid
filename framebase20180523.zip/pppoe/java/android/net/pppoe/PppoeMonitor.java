package android.net.pppoe;

import java.util.regex.Matcher;

import android.os.SystemProperties;
import android.net.NetworkInfo;
import android.util.Config;
import android.util.Slog;
import java.util.StringTokenizer;

/**
 * Listens for events for pppoe, and passes them on
 * to the {@link PppoeStateTracker} for handling. Runs in its own thread.
 *
 * @hide
 */
public class PppoeMonitor {
    private static final String TAG = "PppoeMonitor";
    private static final int CONNECTED	= 1;
    private static final int INTERFACE_DOWN = 2;
    private static final int INTERFACE_UP = 3;
    private static final int DEV_ADDED = 4;
    private static final int DEV_REMOVED = 5;
    private static final String connectedEvent =	"CONNECTED";
    private static final String disconnectedEvent = "DISCONNECTED";

    private static final int NEW_LINK = 16;
    private static final int DEL_LINK = 17;
    private static final boolean DEBUG = true;
    private int event = 0;

    private PppoeStateTracker mTracker;

    public PppoeMonitor(PppoeStateTracker tracker) {
        mTracker = tracker;
    }

    public void startMonitoring() {
        new MonitorThread().start();
    }

    class MonitorThread extends Thread {
        public MonitorThread() {
            super("PppoeMonitor");
        }

        public void run() {
            int index;
            int i;

            for (;;) {
                String eventName = PppoeNative.waitForEvent();

                String propVal = SystemProperties.get(PppoeManager.PPPOE_RUNNING_FLAG);
                int n = 0;
                if (propVal.length() != 0) {
                    try {
                        n = Integer.parseInt(propVal);
                    } catch (NumberFormatException e) {}
                }

                if (eventName == null) {
                    continue;
                }
                /*if (DEBUG) */Slog.i(TAG, "EVENT[" + eventName+"]");
				
                if ( 0 == n) {
                    if((event != DEV_ADDED) && (event != INTERFACE_UP)) {
                        continue;
                    }
                }
                /*
                * Map event name into event enum
                */
                String [] events = eventName.split(":");
                index = events.length;
                if (index < 2) {
                    continue;
                }
                /*if (DEBUG) */Slog.i(TAG, "interface: " + events[0]);
                if(!"ppp0".equals(events[0]) && !"eth0".equals(events[0])) {
                    continue;
                }

                i = 0;
                while (index != 0 && i < index-1) {
                    if ("added".equals(events[i+1]) ) {
                        event = DEV_ADDED;
                    } else if ("removed".equals(events[i+1])) {
                        event = DEV_REMOVED;
                        handleEvent(events[i], event);
                    } else {
                        int cmd =Integer.parseInt(events[i+1]);
                        if ( cmd == DEL_LINK) {
                            event = INTERFACE_DOWN;
                            handleEvent(events[i], event);
                        } else if (cmd == NEW_LINK) {
                            event = INTERFACE_UP;
                            handleEvent(events[i], event);
                        }
                    }
                    i = i + 2;
                }
            }
        }

        void handleEvent(String ifname,int event) {
            switch (event) {
            case INTERFACE_DOWN:
                mTracker.notifyStateChange(ifname, NetworkInfo.DetailedState.DISCONNECTED);
                break;
            case INTERFACE_UP:
                mTracker.notifyStateChange(ifname, NetworkInfo.DetailedState.CONNECTED);
                break;
            case DEV_REMOVED:
                mTracker.notifyStateChange(ifname, NetworkInfo.DetailedState.PPPOE_DISCONNECTED);
                break;
            default:
                mTracker.notifyStateChange(ifname, NetworkInfo.DetailedState.FAILED);
            }
        }
    }
}
