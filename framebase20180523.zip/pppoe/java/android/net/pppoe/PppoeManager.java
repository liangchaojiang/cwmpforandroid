package android.net.pppoe;

import java.util.List;

import android.annotation.SdkConstant;
import android.annotation.SdkConstant.SdkConstantType;
import android.net.wifi.IWifiManager;
import android.net.ethernet.EthernetManager;
import android.os.Handler;
import android.os.SystemProperties;
import android.os.RemoteException;
import android.content.Context;
import android.util.Slog;
import android.net.DhcpInfo;
import android.net.NetworkUtils;
import android.net.ethernet.EthernetDevInfo;

public class PppoeManager {
    public static final String TAG = "PppoeManager";
    public static final int PPPOE_DEVICE_SCAN_RESULT_READY = 0;
    public static final String NETWORK_STATE_CHANGED_ACTION = "android.net.pppoe.STATE_CHANGE";
    public static final String EXTRA_NETWORK_INFO = "networkInfo";
    public static final String EXTRA_PPPOE_STATE = "pppoe_state";
    public static final String EXTRA_PPPOE_ERRMSG = "pppoe_errmsg";
    public static final String EXTRA_PPPOE_INTERFACE = "pppoe_interface";
    public static final String EXTRA_PPPOE_ERRCODE = "pppoe_errcode";
    public static final String EXTRA_PPPOE_ERRCODE_TIMEOUT = "650";
    public static final String EXTRA_PPPOE_ERRCODE_AUTH_FAILED = "691";
    public static final String PROP_VAL_PPP_NOERR = "0:0";
    public static final String EXTRA_PREVIOUS_PPPOE_STATE = "previous_pppoe_state";

    public static final int PPPOE_STATE_UNKNOWN = 0;
    public static final int PPPOE_STATE_DISABLED = 1;
    public static final int PPPOE_STATE_ENABLED = 2;

    public static final String PPPOE_STATE_CHANGED_ACTION = "android.net.pppoe.PPPOE_STATE_CHANGED";
    public static final int PPPOE_STATE_CONNECT = 1;
    public static final int PPPOE_STATE_DISCONNECT = 2;
    public static final int PPPOE_STATE_CONNECTING = 3;
    public static final int PPPOE_STATE_DISCONNECTING = 4;
    public static final int PPPOE_STATE_SERVER_DISCONNECT = 5;
    public static final int PPPOE_STATE_AUTH_FAILED = 6;
    public static final int PPPOE_STATE_CONNECT_FAILED = 7;

    public static final int _EVENT_CONNECTING        = 20;
    public static final int _EVENT_CONNECTED         = 30;
    public static final int _EVENT_DISCONNECTED     = 40;
    public static final int _EVENT_CONNECT_FAILED	= 50;
    public static final int _EVENT_DISCONNECT_FAILED	= 60;

    public static final int EVENT_CONNECT_SUCCESSED = 0;
    public static final int EVENT_CONNECT_FAILED = 1;
    public static final int EVENT_DISCONNECT_SUCCESSED = 4;
    /**
    * The pppoe interface is configured by dhcp
    */
    public static final String PPPOE_CONNECT_MODE_DHCP= "dhcp";
    /**
    * The pppoe interface is configured manually
    */
    public static final String PPPOE_CONNECT_MODE_MANUAL = "manual";

    public static final String PPPOE_RUNNING_FLAG = "net.pppoe.running";

    private Context mContext;
    private IPppoeManager mService;
    private Handler mHandler;

    public PppoeManager(Context context,IPppoeManager service, Handler handler) {
        Slog.i(TAG, "Init Pppoe Manager");
        mContext = context;
        mService = service;
        mHandler = handler;
    }

    public boolean isPppoeConfigured() {
        try {
            return mService.isPppoeConfigured();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not check pppoe config state");
        }
        return false;
    }

    public PppoeDevInfo getSavedPppoeConfig() {
        try {
            return mService.getSavedPppoeConfig();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get pppoe config");
        }
        return null;
    }

    public void UpdatePppoeDevInfo(PppoeDevInfo info) {
        try {
            mService.UpdatePppoeDevInfo(info);
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not update pppoe device info");
        }
    }

    public String[] getDeviceNameList() {
        try {
            return mService.getDeviceNameList();
        } catch (RemoteException e) {
            return null;
        }
    }

    public void setPppoeEnabled(boolean enable) {
        try {
            mService.setPppoeState(enable ? PPPOE_STATE_ENABLED:PPPOE_STATE_DISABLED);
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not set new state");
        }
    }

    /**
    * @return
    * PPPOE_STATE_UNKNOWN 0
    * PPPOE_STATE_CONNECT 1
    * PPPOE_STATE_DISCONNECT 2
    * PPPOE_STATE_CONNECTING 3
    */
    public int getPppoeState( ) {
        int pppoeState = PPPOE_STATE_UNKNOWN;
        try {
            pppoeState = mService.getPppoeState();
        } catch (RemoteException e) {
            return PPPOE_STATE_UNKNOWN;
        }
        return pppoeState;
    }

    public boolean pppoeConfigured() {
        try {
            return mService.isPppoeConfigured();
        } catch (RemoteException e) {
            return false;
        }
    }

    /**
    * pppoe connect
    * @param name
    * @param pswd
    * @param ifaceName  for instance:eth0
    */
    public synchronized void connect(String username,String password, String ifaceName){
        String proj = SystemProperties.get("sys.proj.type");
        if ("mobile".equals(proj) && "eth0".equals(ifaceName)) {
               Slog.i(TAG, "disconnect ethernet before PPPoE connect on " + ifaceName);
               EthernetManager mEthManager = (EthernetManager)mContext.getSystemService("ethernet");
               mEthManager.setEthDhcp(false);

               EthernetDevInfo info = new EthernetDevInfo();
               info.setIfName(ifaceName);
               info.setConnectMode(EthernetDevInfo.ETH_CONN_MODE_PPPOE);
               mEthManager.updateEthDevInfo(info);
        }
		ifaceName = "eth0.45";
        connect(username, password, ifaceName, PppoeDevInfo.PPPOE_DIAL_MODE_AUTO);
    }

    public synchronized void connect(String username,String password, String ifaceName, String dialmode){
        try {
            mService.connect(username, password, ifaceName, dialmode);
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not connect");
        }
    }

    /**
    * @param ifaceName  for instance:eth0
    */
    public synchronized void disconnect(String ifaceName){
        try {
             mService.disconnect(ifaceName);
        } catch (RemoteException e) {
             Slog.i(TAG,"Can not disconnect");
        }
    }
    
    /**
    @hide
    **/
    public synchronized void terminate(){
        try {
            mService.terminate();
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not terminate");
        }
    }
    
    public synchronized int status() {
        try {
            return mService.status();
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not get status");
        }
        return PppoeOperation.PPP_STATUS_DISCONNECTED;
    }

	/* get PPPoE Connect Type return : wlan0/eth0"*/
    public String getPppoeConnectType(){
         return SystemProperties.get("net.pppoe.phyif");
    }
    
    /**
    * @param mode PPOE_CONNECT_MODE_DHCP or PPPOE_CONNECT_MODE_MANUAL
    * @param info  if mode is PPOE_CONNECT_MODE_MANUAL, it is required
    */
    public synchronized void setPppoeMode(String mode,DhcpInfo info) {
        pppoeSetDefaultConf();
        /*try {
            mService.setPppoeMode(mode);
            if(mode.equals(PPPOE_CONNECT_MODE_MANUAL)) {
                //TODO with DhcpInfo
            }
        } catch (RemoteException e) {
        }*/
    }

    /**
    * @return mode PPOE_CONNECT_MODE_DHCP or PPPOE_CONNECT_MODE_MANUAL
    */
    public synchronized String getPppoeMode() {
        String pppoeMode = null;
        PppoeDevInfo pppoeDevInfo = getSavedPppoeConfig();
        if(pppoeDevInfo != null) {
            pppoeMode = pppoeDevInfo.getConnectMode();
        }
        return pppoeMode;
    }

    public DhcpInfo getDhcpInfo() {
        try {
            return mService.getDhcpInfo();
        } catch (RemoteException e) {
            return null;
        }
    }

    public int getTotalInterface() {
        try {
            return mService.getTotalInterface();
        } catch (RemoteException e) {
            return 0;
        }
    }

    public void pppoeSetDefaultConf() {
        try {
            mService.setPppoeMode(PppoeDevInfo.PPPOE_CONN_MODE_DHCP);
        } catch (RemoteException e) {
        }
    }

    public boolean isPppoeDeviceUp() {
        try {
            return mService.isPppoeDeviceUp();
        } catch (RemoteException e) {
            return false;
        }
    }
}
