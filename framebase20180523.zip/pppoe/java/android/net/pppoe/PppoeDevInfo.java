package android.net.pppoe;


import android.net.pppoe.PppoeDevInfo;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class PppoeDevInfo implements Parcelable {
    private String ifname;
    private String account;
    private String password;
    private String wifissid;
    private String ipaddr;
    private String netmask;
    private String route;
    private String dns1;
    private String dns2;
    private String mode;
    private String dialmode;
    public static final String PPPOE_CONN_MODE_DHCP = "dhcp";
    public static final String PPPOE_CONN_MODE_MANUAL = "manual";
    public static final String PPPOE_DIAL_MODE_AUTO = "auto";
    public static final String PPPOE_DIAL_MODE_MANUAL = "manual";

    public PppoeDevInfo () {
        ifname = null;
        account = null;
        password = null;
        wifissid = null;
        dialmode = PPPOE_DIAL_MODE_MANUAL;

        ipaddr = null;
        dns1 = null;
        dns2 = null;
        route = null;
        netmask = null;
        mode = PPPOE_CONN_MODE_DHCP;
    }

    public void setIfName(String ifname) {
        this.ifname = ifname;
    }

    public String getIfName() {
        return this.ifname;
    }

    public void setAccount(String name) {
        this.account = name;
    }

    public String getAccount() {
        return this.account;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return this.password;
    }

    public void setWifissid(String ssid) {
        this.wifissid = ssid;
    }

    public String getWifissid() {
        return this.wifissid;
    }

    public void setIpAddress(String ip) {
        this.ipaddr = ip;
    }

    public String getIpAddress( ) {
        return this.ipaddr;
    }

    public void setNetMask(String ip) {
        this.netmask = ip;
    }

    public String getNetMask( ) {
        return this.netmask;
    }

    public void setRouteAddr(String route) {
        this.route = route;
    }

    public String getRouteAddr() {
        return this.route;
    }

    public void setDnsAddr(String dns) {
        this.dns1 = dns;
    }

    public String getDnsAddr( ) {
        return this.dns1;
    }

    public void setDns1Addr(String dns1) {
        this.dns1 = dns1;
    }

    public String getDns1Addr( ) {
        return this.dns1;
    }

    public void setDns2Addr(String dns2) {
        this.dns2 = dns2;
    }

    public String getDns2Addr( ) {
        return this.dns2;
    }

    public boolean setConnectMode(String mode) {
        if(mode == null)
            return false;
        if (mode.equals(PPPOE_CONN_MODE_DHCP) || mode.equals(PPPOE_CONN_MODE_MANUAL)) {
            this.mode = mode;
            return true;
        }
        return false;
    }

    public String getConnectMode() {
        return this.mode;
    }

    public boolean setDialMode(String mode) {
        if(mode == null)
            return false;
        if (mode.equals(PPPOE_DIAL_MODE_AUTO) || mode.equals(PPPOE_DIAL_MODE_MANUAL)) {
            this.dialmode = mode;
            return true;
        }
        return false;
    }

    public String getDialMode() {
        return this.dialmode;
    }
    
    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.ifname);
        dest.writeString(this.account);
        dest.writeString(this.password);
        dest.writeString(this.wifissid);
        dest.writeString(this.ipaddr);
        dest.writeString(this.netmask);
        dest.writeString(this.route);
        dest.writeString(this.dns1);
        dest.writeString(this.dns2);
        dest.writeString(this.mode);
        dest.writeString(this.dialmode);
    }

    /** Implement the Parcelable interface {@hide} */
    public static final Creator<PppoeDevInfo> CREATOR = new Creator<PppoeDevInfo>() {
        public PppoeDevInfo createFromParcel(Parcel in) {
            PppoeDevInfo info = new PppoeDevInfo();
            info.setIfName(in.readString());
            info.setAccount(in.readString());
            info.setPassword(in.readString());
            info.setWifissid(in.readString());
            info.setIpAddress(in.readString());
            info.setNetMask(in.readString());
            info.setRouteAddr(in.readString());
            info.setDns1Addr(in.readString());
            info.setDns2Addr(in.readString());
            info.setConnectMode(in.readString());
            info.setDialMode(in.readString());
            return info;
        }

        public PppoeDevInfo[] newArray(int size) {
            return new PppoeDevInfo[size];
        }
    };
    
    @Override
    public String toString() {
        return "{ ifname: " + ifname + " }\n"
                + "{ account: " + account + " }\n"
                + "{ password: " + password + " }\n"
                + "{ wifissid: " + wifissid + " }\n"
                + "{ ipaddr: " + ipaddr + " }\n"
                + "{ netmask: " + netmask + " }\n"
                + "{ route: " + route + " }\n"
                + "{ dns1: " + dns1 + " }\n"
                + "{ dns2: " + dns2 + " }\n"
                + "{ mode: " + mode + " }\n"
                + "{ dialmode: " + dialmode + " }\n";
    }
}
