package android.net.pppoe;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Timer;
import java.util.TimerTask;
import java.io.File;

//import android.R;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothHeadset;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.DhcpInfoInternal;
import android.net.InterfaceConfiguration;
import android.net.NetworkInfo;
import android.net.NetworkInfo.DetailedState;
import android.net.RouteInfo;
import android.net.LinkAddress;
import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.net.LinkQualityInfo;
import android.net.NetworkStateTracker;
import android.net.NetworkUtils;
import android.net.NetworkInfo.DetailedState;
import android.net.SamplingDataTracker;
import android.net.ethernet.DualStackManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.INetworkManagementService;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.SystemProperties;
import android.os.ServiceManager;
import android.os.INetworkManagementService;
import android.os.RemoteException;
import android.util.*;

/**
 * Track the state of Pppoe connectivity. All event handling is done here,
 * and all changes in connectivity state are initiated here.
 *
 * @hide
 */
public class PppoeStateTracker implements NetworkStateTracker {
    private static final String TAG="PppoeStateTracker";
    private static final String PROP_PPP_ADDR = "dhcp.ppp0.ipaddress";
    private static final String PROP_PPP_MASK = "dhcp.ppp0.mask";
    private static final String PROP_PPP_DNS1 = "dhcp.ppp0.dns1";
    private static final String PROP_PPP_DNS2 = "dhcp.ppp0.dns2";
    private static final String PROP_PPP_GW = "dhcp.ppp0.gateway";

    private static final String PROP_VAL_PPP_NOERR = "0:0";
    private static final String PROP_NAME_PPP_ERRCODE = "net.ppp.errcode";

    private static final int EVENT_REQUEST_CONNECT     = 7;
    private static final int EVENT_REQUEST_DISCONNECT  = 8;
    private static final int EVENT_REQUEST_TERMINATE   = 9;
    private static final int EVENT_REQUEST_DISCONNECT_TIMEOUT     = 10;
    private PppoeOperation mPppoeOp;

    private PppoeManager mEM;
    private boolean mServiceStarted;
    private boolean mInterfaceStopped;
    private String mInterfaceName = "ppp0";
    private DhcpInfoInternal mDhcpInfoInternal;
    private PppoeMonitor mMonitor;

    private AtomicBoolean mTeardownRequested = new AtomicBoolean(false);
    private AtomicBoolean mPrivateDnsRouteSet = new AtomicBoolean(false);
    private AtomicBoolean mDefaultRouteSet = new AtomicBoolean(false);

    private LinkProperties mLinkProperties;
    private LinkCapabilities mLinkCapabilities;
    private NetworkInfo mNetworkInfo;

    private Handler mTarget;
    private Handler mTrackerTarget;
    private Handler mPppoeTarget;
    private Context mContext;
    private static DetailedState mLastState = DetailedState.DISCONNECTED;
    private int mPppoeState = PppoeManager.PPPOE_STATE_UNKNOWN;
    private int mPppoeStatus = PppoeOperation.PPP_STATUS_DISCONNECTED;
    private String mPppoeDev = null;
    private String mUserName = null;
    private String mPassWord = null;
    private String mIfName = null;
    private int RetryCount = 0;
    private boolean mIgnoreDownEvent = true;
    
    private Timer mConnectTimer = new Timer();
    private Handler mDualStackTarget;

    public PppoeStateTracker(int netType, String networkName) {
        Slog.i(TAG,"Starts ...");

        mNetworkInfo = new NetworkInfo(netType, 0, networkName, "");
        mNetworkInfo.setIsAvailable(false);
        setTeardownRequested(false);

        mLinkProperties = new LinkProperties();
        mLinkCapabilities = new LinkCapabilities();

        if (PppoeNative.initPppoeNative() != 0 ) {
            Slog.e(TAG,"Can not init pppoe device layers");
            return;
        }
        Slog.i(TAG,"Successed");

        mServiceStarted = true;
        mPppoeOp = PppoeOperation.getInstance();

        HandlerThread pppoeThread = new HandlerThread("PPPoE Handler Thread");
        pppoeThread.start();
        mPppoeTarget = new Handler(pppoeThread.getLooper(), mPppoeHandlerCallback);

        mMonitor = new PppoeMonitor(this);
    }

    public boolean stopInterface(boolean suspend) {
        if(mInterfaceName != null) {
            mInterfaceStopped = true;
            Slog.i(TAG, "stop interface");

            NetworkUtils.resetConnections(mInterfaceName, NetworkUtils.RESET_ALL_ADDRESSES);
            if (!suspend)
                NetworkUtils.disableInterface(mInterfaceName);
        }
        return true;
    }

    private boolean configureInterfaceStatic(String ifname, DhcpInfoInternal dhcpInfoInternal) {
        IBinder b = ServiceManager.getService(Context.NETWORKMANAGEMENT_SERVICE);
        INetworkManagementService netd = INetworkManagementService.Stub.asInterface(b);
        InterfaceConfiguration ifcg = new InterfaceConfiguration();
        ifcg.setLinkAddress(dhcpInfoInternal.makeLinkAddress());
        Slog.i(TAG, "configureInterface on dev:" + ifname);
        try {
            netd.setInterfaceConfig(ifname, ifcg);
            mLinkProperties = dhcpInfoInternal.makeLinkProperties();
            mLinkProperties.setInterfaceName(ifname);
            return true;
        } catch (RemoteException re) {
            Slog.i(TAG, "IP configuration failed: " + re);
            return false;
        } catch (IllegalStateException e) {
            Slog.i(TAG, "IP configuration failed: " + e);
            return false;
        }
    }

    private boolean configureInterface(PppoeDevInfo info) throws UnknownHostException {
        mInterfaceStopped = false;

        mDhcpInfoInternal = new DhcpInfoInternal();
        mDhcpInfoInternal.ipAddress = info.getIpAddress();
        mDhcpInfoInternal.addRoute(new RouteInfo(NetworkUtils.numericToInetAddress(info.getRouteAddr())));

        InetAddress ia = NetworkUtils.numericToInetAddress(info.getNetMask());
        mDhcpInfoInternal.prefixLength = NetworkUtils.netmaskIntToPrefixLength(
                NetworkUtils.inetAddressToInt((Inet4Address)ia));
        mDhcpInfoInternal.dns1 = info.getDns1Addr();
        mDhcpInfoInternal.dns2 = info.getDns2Addr();
        
        if(mInterfaceName != null)
            configureInterfaceStatic(mInterfaceName, mDhcpInfoInternal);
        return true;
    }

    public boolean resetInterface()  throws UnknownHostException {
        /* This will guide us to enabled the enabled device */
        Slog.i(TAG, ">>>resetInterface");
        if (mEM != null) {
            Slog.i(TAG, "pppoeConfigured: " + mEM.pppoeConfigured());
            PppoeDevInfo info = mEM.getSavedPppoeConfig();

            if (info != null && mEM.pppoeConfigured()) {
                Slog.i(TAG, "IfName:" + info.getIfName());
                Slog.i(TAG, "IP:" + info.getIpAddress());
                Slog.i(TAG, "Mask:" + info.getNetMask());
                Slog.i(TAG, "DNS1:" + info.getDns1Addr());
                Slog.i(TAG, "DNS2:" + info.getDns2Addr());

                synchronized(this) {
                    if(mInterfaceName != null) {
                        Slog.i(TAG, "reset device " + mInterfaceName);
                        NetworkUtils.resetConnections(mInterfaceName,
                                NetworkUtils.RESET_ALL_ADDRESSES);
                    }

                    Slog.i(TAG, "Force the connection disconnected before configuration");
                    setPppoeState(false, PppoeManager._EVENT_DISCONNECTED,
                            PppoeManager.PROP_VAL_PPP_NOERR);

                    configureInterface(info);
                }
            }
        }
        return true;
    }

    @Override
    public String getTcpBufferSizesPropName() {
        // TODO Auto-generated method stub
        return "net.tcp.buffersize.pppoe";
    }

    public void StartPolling() {
        Slog.i(TAG, "start monitoring");
        mMonitor.startMonitoring();
    }

    @Override
    public boolean isAvailable() {
        // Only say available if we have interfaces and user did not disable us.
        return ((mEM.getTotalInterface() != 0)
                && (mEM.getPppoeState() != PppoeManager.PPPOE_STATE_DISABLED));
    }

    @Override
    public boolean reconnect() {
        Slog.i(TAG, ">>>reconnect");
        try {
            if (mEM.getPppoeState() != PppoeManager.PPPOE_STATE_DISABLED ) {
                // maybe this is the first time we run, so set it to enabled
                mEM.setPppoeEnabled(true);
                if (!mEM.pppoeConfigured()) {
                    mEM.pppoeSetDefaultConf();
                }
                return resetInterface();
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean setRadio(boolean turnOn) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void startMonitoring(Context context, Handler target) {
        Slog.i(TAG,"start to monitor the pppoe devices");
        if (mServiceStarted) {
            mContext = context;
            mEM = (PppoeManager)mContext.getSystemService(Context.PPPOE_SERVICE);
            mTarget = target;
            mTrackerTarget = new Handler(target.getLooper(), mTrackerHandlerCallback);
            if (mEM == null) {
                Slog.i(TAG,"failed to start startMonitoring");
                return;
            }

            int state = mEM.getPppoeState();
            if (state != mEM.PPPOE_STATE_DISABLED) {
                if (state == mEM.PPPOE_STATE_UNKNOWN){
                    // maybe this is the first time we run, so set it to enabled
                    mEM.setPppoeEnabled(true);
                } else {
                    try {
                        resetInterface();
                    } catch (UnknownHostException e) {
                        Slog.e(TAG, "Wrong pppoe configuration");
                    }
                }
            }
        }
    }

    public boolean teardown() {
        return (mEM != null) ? stopInterface(false) : false;
    }

    public void captivePortalCheckComplete() {
        //TODO
    }

    private void sendSHCMCCBroadcast(int event, String errcode) {
        final Intent intent = new Intent("PPPOE_STATE_CHANGED");
        intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
        int invertEvent = 0;
        String errmsg = null;

        if(event == PppoeManager._EVENT_CONNECT_FAILED) {
            invertEvent = PppoeManager.EVENT_CONNECT_FAILED;
            if(!PppoeManager.PROP_VAL_PPP_NOERR.equals(errcode)) {
                if("691".equals(errcode)) {
                    errmsg = mContext.getResources().getString(
                            com.android.internal.R.string.pppoe_errmsg_err_usrpwd);
                } else {
                    errmsg = mContext.getResources().getString(
                            com.android.internal.R.string.pppoe_errmsg_timeout);
                }
            }
		    } else if(event == PppoeManager._EVENT_CONNECTED) {
            invertEvent = PppoeManager.EVENT_CONNECT_SUCCESSED;
        } else if(event == PppoeManager._EVENT_DISCONNECTED){
            invertEvent = PppoeManager.EVENT_CONNECT_FAILED;
            errmsg = mContext.getResources().getString(
                    com.android.internal.R.string.pppoe_errmsg_disconnected);
        }

        Slog.d(TAG, "sendSHCMCCBroadcast, " + toEventString(invertEvent) + " errmsg : " + errmsg);
        intent.putExtra(PppoeManager.EXTRA_PPPOE_STATE, invertEvent);
        intent.putExtra(PppoeManager.EXTRA_PPPOE_INTERFACE, mIfName);
        if(errmsg != null)
            intent.putExtra(PppoeManager.EXTRA_PPPOE_ERRMSG, errmsg);
        intent.putExtra(PppoeManager.EXTRA_PPPOE_ERRCODE, errcode);
        mContext.sendBroadcast(intent);
    }

    private void sendIhomeBroadcast(int event, String errcode) {
        final Intent intent = new Intent("com.android.ihome.action.pppoe");
        Slog.d(TAG, "sendIhomeBroadcast " + toEventString(event) + ", errcode: " + errcode);
        if(event == PppoeManager._EVENT_DISCONNECTED) {
            intent.putExtra("pppoe", "false");
        } else if(event == PppoeManager._EVENT_CONNECTED) {
            intent.putExtra("pppoe", "true");
        }
        mContext.sendBroadcast(intent);
    }
	
    private void sendBroadcast(String action, int event, String errcode) {
        if(action == null)
            action = PppoeManager.PPPOE_STATE_CHANGED_ACTION;
        final Intent intent = new Intent(action);
        intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
        int invertEvent = 0;
        String errmsg = null;

        if(event == PppoeManager._EVENT_CONNECT_FAILED) {
            invertEvent = PppoeManager.EVENT_CONNECT_FAILED;
            if(!PppoeManager.PROP_VAL_PPP_NOERR.equals(errcode)) {
                if("691".equals(errcode)) {
                    errmsg = mContext.getResources().getString(
                            com.android.internal.R.string.pppoe_errmsg_err_usrpwd);
                } else {
                    errmsg = mContext.getResources().getString(
                            com.android.internal.R.string.pppoe_errmsg_timeout);
                }
            }
		    } else if(event == PppoeManager._EVENT_CONNECTED) {
            invertEvent = PppoeManager.EVENT_CONNECT_SUCCESSED;
        } else if(event == PppoeManager._EVENT_DISCONNECTED){
            invertEvent = PppoeManager.EVENT_DISCONNECT_SUCCESSED;
            errmsg = mContext.getResources().getString(
                    com.android.internal.R.string.pppoe_errmsg_disconnected);
        }

        intent.putExtra(PppoeManager.EXTRA_PPPOE_STATE, invertEvent);
        intent.putExtra(PppoeManager.EXTRA_PPPOE_INTERFACE, mIfName);
        if(errmsg != null)
            intent.putExtra(PppoeManager.EXTRA_PPPOE_ERRMSG, errmsg);
        intent.putExtra(PppoeManager.EXTRA_PPPOE_ERRCODE, errcode);
        mContext.sendBroadcast(intent);
    }

    private void postNotification(int event, String errcode) {
        String proj_type = null;
        String proj_middleware = null;

        proj_type = SystemProperties.get("sys.proj.type", "ott");
        proj_middleware = SystemProperties.get("sys.proj.middleware", null);
        Slog.d(TAG, "postNotification, proj type: " + proj_type + ", middleware: " + proj_middleware);
        Slog.d(TAG, "postNotification, " + toEventString(event) + " errcode: " + errcode);
        if ("mobile".equals(proj_type)) {
            sendSHCMCCBroadcast(event, errcode);
        } else {
            if("sy".equals(proj_middleware)) {
                sendBroadcast("PPPOE_STATE_CHANGED", event, errcode);
            } else {
                sendBroadcast(PppoeManager.PPPOE_STATE_CHANGED_ACTION, event, errcode);
            }
            sendIhomeBroadcast(event, errcode);
        }
        Slog.d(TAG, "Send PPPOE_STATE_CHANGED_ACTION");
    }

    private void setPppoeState(boolean state, int event, String errcode) {
        Slog.d(TAG, "PST.setPppoeState()" + mNetworkInfo.isConnected() + " ==> " + state + ",event is: "+event );
        mPppoeState = event;
		
		if (mIfName!=null) {
			Slog.d(TAG, "Ths interface name is : " + mIfName );
		}

        if (event == PppoeManager._EVENT_CONNECT_FAILED || mNetworkInfo.isConnected() != state) {
            Slog.d(TAG, "+++++++++++++ check if needed reconnect "  );
            cancelConnectTimer();
            if((event == PppoeManager._EVENT_CONNECT_FAILED) && (("eth0").equals(mIfName)||("eth0.45").equals(mIfName)) && RetryCount == 0){
                  RetryCount = SystemProperties.getInt("net.ppp.retrycount",0);
            }
            Slog.d(TAG, "RetryCount is : " + RetryCount );
            if((mDualStackTarget == null) && (RetryCount > 0) && (event == PppoeManager._EVENT_CONNECT_FAILED)){
                  RetryCount--;
                  if(RetryCount == 0)
                       RetryCount = -1;
                  mPppoeStatus = PppoeOperation.PPP_STATUS_DISCONNECTED;
                  Slog.d(TAG, "Pppoe Connect Failed, retry count: " + RetryCount);
                  try {
                        int sleepTime = SystemProperties.getInt("net.ppp.retrysleep",3000);
                        Thread.sleep(sleepTime);
                  } catch (InterruptedException ex) {
                        // Shut up!
                  }
                  if((mUserName != null) && (mPassWord != null) && (mIfName != null)){
                      connect(mUserName,mPassWord,mIfName);
                  }
                  return ;
             }else{
                mNetworkInfo.setIsAvailable(state);
                postNotification(event, errcode);
                mPppoeStatus = PppoeOperation.PPP_STATUS_DISCONNECTED;
                RetryCount = 0;

                if (mDualStackTarget != null) {
                    Slog.i(TAG, "Send EVENT_PPPOE_FAILED to DualStackService Anywhere");
                    mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_PPPOE_FAILED);
                }
             }
        }

        if (mNetworkInfo.isConnected() != state) {
            if (state) {
                cancelConnectTimer();
                mNetworkInfo.setDetailedState(DetailedState.CONNECTED, null, null);
                mPppoeStatus = PppoeOperation.PPP_STATUS_CONNECTED;
                RetryCount = 0;
            } else {
                mNetworkInfo.setDetailedState(DetailedState.DISCONNECTED, null, null);
                if( PppoeManager._EVENT_DISCONNECTED == event ) {
                    Slog.d(TAG, "EVENT_DISCONNECTED: StopInterface");
                    cancelConnectTimer();
                    mPppoeStatus = PppoeOperation.PPP_STATUS_DISCONNECTED;
                    stopInterface(true);
                }
            }
            try {
               Thread.sleep(100);
             } catch (InterruptedException ex) {
              // Shut up!
             }

            Message msg = mTarget.obtainMessage(EVENT_STATE_CHANGED, mNetworkInfo);
            msg.sendToTarget();
        }
    }

    public void setConnectingState(){       
        mPppoeState = PppoeManager._EVENT_CONNECTING ;
    }

    public int getPppoeState(){
        int pppoeState ;

        if(mPppoeState == PppoeManager._EVENT_CONNECTED) {
            pppoeState = PppoeManager.PPPOE_STATE_CONNECT;
        } else if(mPppoeState == PppoeManager._EVENT_DISCONNECTED 
                || mPppoeState == PppoeManager._EVENT_CONNECT_FAILED) {
            pppoeState = PppoeManager.PPPOE_STATE_DISCONNECT;
        } else if(mPppoeState == PppoeManager._EVENT_CONNECTING) {
            pppoeState = PppoeManager.PPPOE_STATE_CONNECTING;
        } else {
            pppoeState = mPppoeState;
        }
        return pppoeState;
    }

    public DhcpInfo getDhcpInfo() {
        return mDhcpInfoInternal.makeDhcpInfo();
    }

    private Handler.Callback mTrackerHandlerCallback = new Handler.Callback() {
        /** {@inheritDoc} */
        public boolean handleMessage(Message msg) {
            synchronized (this) {
                boolean newNetworkstate = false;
                PppoeDevInfo info = new PppoeDevInfo();

                switch (msg.what) {
                case PppoeManager._EVENT_DISCONNECTED:
                    Slog.i(TAG, "[EVENT: PPP DOWN]");
                    Slog.i(TAG, "DO NOT clear IP Config and PPP Property");
                    
                    if(mPppoeStatus == PppoeOperation.PPP_STATUS_DISCONNECTING) {
                        info.setIfName(mInterfaceName);
                        info.setIpAddress("0.0.0.0");
                        info.setNetMask("0.0.0.0");
                        info.setDns1Addr("0.0.0.0");
                        info.setDns2Addr("0.0.0.0");
                        info.setRouteAddr("0.0.0.0");
                       try {
                            configureInterface(info);
                        } catch (UnknownHostException e) {
                            e.printStackTrace();
                        }
                    }

                    newNetworkstate = false;

                    String ppp_err = SystemProperties.get(PROP_NAME_PPP_ERRCODE,
                            PppoeManager.PROP_VAL_PPP_NOERR);
                    Slog.i(TAG, "ppp_err:" + ppp_err);

                    if (ppp_err.equals(PROP_VAL_PPP_NOERR)) {
                        if((mPppoeStatus == PppoeOperation.PPP_STATUS_DISCONNECTING)) {
                            setPppoeState(newNetworkstate, PppoeManager._EVENT_DISCONNECTED,
                                    PppoeManager.PROP_VAL_PPP_NOERR);
                        }
                    } else {
                        if (mDualStackTarget != null) {
                            if (mIgnoreDownEvent) {
                                Slog.i(TAG, "Ignore the first DOWN EVENT");
                                mIgnoreDownEvent = false;
                            }
                            else {
                                Slog.i(TAG, "Send EVENT_PPPOE_FAILED to DualStackService");
                                mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_PPPOE_FAILED);
                            }
                        }
                        setPppoeState(newNetworkstate,
                                PppoeManager._EVENT_CONNECT_FAILED, ppp_err);
                    }
                    
										if ("unicom".equals(SystemProperties.get("sys.proj.type"))
											&& "shandong".equals(SystemProperties.get("sys.proj.tender.type"))) {
                    
                    		if(mPppoeStatus !=PppoeOperation.PPP_STATUS_CONNECTED) {
                        		if (SystemProperties.getInt("persist.sys.dhcp.vlan_id",0) == 43) {
                            		SystemProperties.set("dhcp.hybrid.ppp.started","false");
                            		SystemProperties.set("dhcp.hybrid.route_config","false");
                        		}
                    		}
                  	}
                    break;
                case PppoeManager._EVENT_CONNECTED:
                    Slog.i(TAG, "[EVENT: PPP UP]");
                    newNetworkstate = true;
                    int i=0;
                    info.setIfName(mInterfaceName);
                    String prop_val = null;
                    do {
                        prop_val = SystemProperties.get(PROP_PPP_ADDR, "0.0.0.0");
                        info.setIpAddress(prop_val);
                        Slog.i(TAG, "ip:" + prop_val);
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException ex) {
                            // Shut up!
                        }
                        i++;
                    } while(info.getIpAddress().equals("0.0.0.0") && i<100);

                    prop_val = SystemProperties.get(PROP_PPP_MASK, "0.0.0.0");
                    info.setNetMask(prop_val);
                    Slog.i(TAG, "mask:" + prop_val);

                    prop_val = SystemProperties.get(PROP_PPP_DNS1, "0.0.0.0");
                    info.setDns1Addr(prop_val);
                    Slog.i(TAG, "dns1:" + prop_val);

                    prop_val = SystemProperties.get(PROP_PPP_DNS2, "0.0.0.0");
                    info.setDns2Addr(prop_val);
                    Slog.i(TAG, "dns2:" + prop_val);

                    prop_val = SystemProperties.get(PROP_PPP_GW, "0.0.0.0");
                    info.setRouteAddr(prop_val);
                    Slog.i(TAG, "gw:" + prop_val);

                    //mEM.UpdatePppoeDevInfo(info);
                    if (mDualStackTarget != null) {
                        Slog.i(TAG, "Send EVENT_PPPOE_SUCCEEDED to DualStackService");
                        mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_PPPOE_SUCCEEDED);
                    }
                    try {
                        configureInterface(info);
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                    }

										if ("unicom".equals(SystemProperties.get("sys.proj.type"))
											&& "shandong".equals(SystemProperties.get("sys.proj.tender.type"))) {
                    
                    		if (SystemProperties.getInt("persist.sys.dhcp.vlan_id",0) == 43) {
                        		SystemProperties.set("dhcp.hybrid.ppp.started","true");
                        		if(SystemProperties.getBoolean("dhcp.hybrid.ap.started",false))
                            		SystemProperties.set("dhcp.hybrid.route_config","true");
                    		}
										}
										
                    setPppoeState(newNetworkstate,
                            PppoeManager._EVENT_CONNECTED,
                            PppoeManager.PROP_VAL_PPP_NOERR);
                    break;
                }
            }
            return true;
        }
    };

    private String getPppoeEventDesc(int event) {
        if (event == EVENT_REQUEST_CONNECT) {
            return "REQUEST_CONNECT";
        } else if (event == EVENT_REQUEST_DISCONNECT) {
            return "REQUEST_DISCONNECT";
        } else if (event == EVENT_REQUEST_TERMINATE) {
            return "REQUEST_TERMINATE";
        } else if (event == EVENT_REQUEST_DISCONNECT_TIMEOUT) {
            return "REQUEST_DISCONNECT_TIMEOUT";
        } else {
            return "UNKNOWN_EVENT(" + event + ")";
        }
    }

    private Handler.Callback mPppoeHandlerCallback = new Handler.Callback() {
        /** {@inheritDoc} */
        public boolean handleMessage(Message msg) {
            String event_desc = getPppoeEventDesc(msg.what);
            Slog.i(TAG, "Handle event:" + event_desc);

            switch (msg.what) {
            case EVENT_REQUEST_CONNECT:
                if (mEM != null) {
                    Slog.i(TAG, "pppoeConnect BEGIN");
                    Slog.i(TAG, "PPPoE connect mUserName: " + mUserName + ", mPassWord: " + mPassWord
                            + ", mIfName: " + mIfName);
                    if (mDualStackTarget != null) {
                        Slog.i(TAG, "Send EVENT_PPPOE_START to DualStackService");
                        mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_PPPOE_START);
                    }
                    mPppoeTarget.removeMessages(EVENT_REQUEST_DISCONNECT_TIMEOUT);
                    SystemProperties.set(PppoeManager.PPPOE_RUNNING_FLAG, "100");
                    mPppoeStatus = PppoeOperation.PPP_STATUS_CONNECTING;
                    mIgnoreDownEvent = true;
                    mPppoeOp.connect(mIfName, mUserName, mPassWord);
                    waitForConnected();
                    Slog.i(TAG, "pppoeConnect END");
                } else {
                    Slog.i(TAG, "pppoeConnect faield for mPppoeManager uniinitialized");
                }
                break;
            case EVENT_REQUEST_DISCONNECT:
                if (mEM != null) {
                    Slog.i(TAG, "pppoeDisconnect BEGIN");
                    mPppoeStatus = PppoeOperation.PPP_STATUS_DISCONNECTING;
                    mPppoeOp.disconnect();
                    mNetworkInfo.setDetailedState(DetailedState.DISCONNECTED, null, null);
                    mPppoeTarget.sendEmptyMessageDelayed(EVENT_REQUEST_DISCONNECT_TIMEOUT, 6000);
                    Slog.i(TAG, "pppoeDisconnect END");
                } else {
                    Slog.i(TAG, "pppoeDisconnect faield for mPppoeManager uniinitialized");
                }
                break;
            case EVENT_REQUEST_TERMINATE:
                if (mEM != null) {
                    Slog.i(TAG, "pppoeTerminate BEGIN");
                    mPppoeTarget.removeMessages(EVENT_REQUEST_DISCONNECT_TIMEOUT);
                    mPppoeStatus = PppoeOperation.PPP_STATUS_DISCONNECTING;
                    mPppoeOp.terminate();
                    mNetworkInfo.setDetailedState(DetailedState.DISCONNECTED, null, null);
                    Slog.i(TAG, "pppoeTerminate END");
                } else {
                    Slog.i(TAG, "pppoeTerminate faield for mPppoeManager uniinitialized");
                }
                break;
            case EVENT_REQUEST_DISCONNECT_TIMEOUT:
                SystemProperties.set(PppoeManager.PPPOE_RUNNING_FLAG, "0");
                break;
            }
            return true;
        }
    };

    private void removeAllMsgs() {
        mPppoeTarget.removeMessages(EVENT_REQUEST_TERMINATE);
        mPppoeTarget.removeMessages(EVENT_REQUEST_DISCONNECT);
        mPppoeTarget.removeMessages(EVENT_REQUEST_DISCONNECT_TIMEOUT);
        mPppoeTarget.removeMessages(EVENT_REQUEST_CONNECT);
    }

    private int getPppoeConnectTimeout() {
        int count = SystemProperties.getInt("net.pppoe.padt_count", 2);
        int timeout = SystemProperties.getInt("net.pppoe.padt_timeout", 1000);
        File padt1 = new File("/data/misc/etc/ppp/eth_padt_bin");
        File padt2 = new File("/data/misc/ppp/wlan_padt_bin");
        if((mDualStackTarget == null) &&( padt1.exists() || padt2.exists())) {
            Slog.d(TAG, "getPppoeConnectTimeout, eth_padt_bin or wlan_padt_bin is exists");
            return count*timeout;
        } else {
            return 500;
        }
    }
    
    private static int mConnectTimerTimeout = 0;
    private void cancelConnectTimer() {
        Log.d(TAG, "cancelConnectTimer start");
        if(mConnectTimer != null) {
            mConnectTimer.cancel();
            mConnectTimer = null;
        }
        mConnectTimerTimeout = 0;
    }

    public void waitForConnected() {
        Log.d(TAG, "waitForConnected start");
        TimerTask task = new TimerTask(){
            public void run() {
                Log.d(TAG, "waitForConnected, timeout: " + mConnectTimerTimeout);
                int timeout = SystemProperties.getInt("net.ppp.waittime", 30);
                if(mConnectTimerTimeout >= timeout) {
                    setPppoeState(false, PppoeManager._EVENT_CONNECT_FAILED, "650");
                    return;
                }
                String ppp_err = SystemProperties.get(PROP_NAME_PPP_ERRCODE,
                        PppoeManager.PROP_VAL_PPP_NOERR);
                Slog.i(TAG, "ppp_err:" + ppp_err);
                if (!ppp_err.equals(PROP_VAL_PPP_NOERR)) {
                    setPppoeState(false, PppoeManager._EVENT_CONNECT_FAILED, ppp_err);
                    return;
                }
                mConnectTimerTimeout++;
            }
        };

        cancelConnectTimer();
        mConnectTimer = new Timer();
        mConnectTimer.schedule(task, 1000, 1000);
    }

    public void connect(String username,String password, String ifaceName) {
        Slog.i(TAG, "PPPoE connect status is " + mPppoeStatus + ", ifaceName is " + ifaceName);
		if((mPppoeStatus == PppoeOperation.PPP_STATUS_CONNECTING)){
        //if((mPppoeStatus == PppoeOperation.PPP_STATUS_CONNECTING)
        //        || (mPppoeStatus == PppoeOperation.PPP_STATUS_CONNECTED)) {
            Slog.w(TAG, "PPPoE connecting or connected, do not connect again!");
            return;
        }
        mUserName = username;
        mPassWord = password;
        mIfName = ifaceName;
        mPppoeDev = new String(ifaceName);
        Message message = new Message();
        message.what = EVENT_REQUEST_CONNECT;
        mPppoeTarget.removeMessages(EVENT_REQUEST_TERMINATE);
        mPppoeTarget.removeMessages(EVENT_REQUEST_DISCONNECT_TIMEOUT);
        mPppoeTarget.removeMessages(EVENT_REQUEST_CONNECT);
        mPppoeTarget.sendEmptyMessageDelayed(EVENT_REQUEST_TERMINATE, 100);
        mPppoeTarget.sendMessageDelayed(message, getPppoeConnectTimeout());
    }

    public void disconnect(String ifaceName) {
        Slog.i(TAG, "PPPoE disconnect ifaceName is " + ifaceName);
        PppoeDevInfo info = mEM.getSavedPppoeConfig();
        if(info == null) {
            Slog.w(TAG, "getSavedPppoeConfig info is null");
            return;
        }
        if((ifaceName == null) || !ifaceName.equals(info.getIfName())) {
            Slog.w(TAG, "disconnect ifname: " + ifaceName + ", but saved ifname: " + info.getIfName());
            return;
        }
        removeAllMsgs();
        mPppoeDev = null;
        mUserName = null;
        mPassWord = null;
        mIfName = null;
        mPppoeStatus = PppoeOperation.PPP_STATUS_DISCONNECTING;
        Message message = new Message();
        message.what = EVENT_REQUEST_DISCONNECT;
        mPppoeTarget.sendMessageDelayed(message, 100);
    }

    public void terminate() {
        removeAllMsgs();
        mPppoeTarget.sendEmptyMessageDelayed(EVENT_REQUEST_TERMINATE, 100);
    }

    public int status() {
        return mPppoeStatus;
    }

    public void notifyStateChange(String ifname, DetailedState state) {
        Slog.i(TAG, "report state change:" + mLastState.toString() + "->" + state.toString() + " on dev " + ifname);
        if (ifname.equals(mInterfaceName)) {
            mLastState = state;
            synchronized(this) {
            	  if(state.equals(DetailedState.PPPOE_DISCONNECTED)) {
                    Slog.i(TAG, "ppp0 is remove, send disconnected msg");
                    setPppoeState(false, PppoeManager._EVENT_DISCONNECTED,
                            PppoeManager.PROP_VAL_PPP_NOERR);
            	  } else {
                    mTrackerTarget.sendEmptyMessage(state.equals(DetailedState.CONNECTED)
                            ? PppoeManager._EVENT_CONNECTED : PppoeManager._EVENT_DISCONNECTED);
                }
            }
        } else if(ifname.equals(mPppoeDev) && state.equals(DetailedState.DISCONNECTED)) {
            Slog.w(TAG, "PPPoE dev(" + ifname + ") is down, disconnect pppoe!");

            Slog.w(TAG, "Try to nuke all TCP connections about pppoe");
            NetworkUtils.resetConnections(mInterfaceName, 
                NetworkUtils.RESET_ALL_ADDRESSES|NetworkUtils.RESET_DO_NOT_CLEAR_IP_ADDR);
            disconnect(ifname);
        }
    }

    /**
     * Fetch NetworkInfo for the network
     */
    public NetworkInfo getNetworkInfo() {
        return new NetworkInfo(mNetworkInfo);
    }

    /**
     * Fetch LinkProperties for the network
     */
    public LinkProperties getLinkProperties() {
        return new LinkProperties(mLinkProperties);
    }

    /**
     * A capability is an Integer/String pair, the capabilities
     * are defined in the class LinkSocket#Key.
     *
     * @return a copy of this connections capabilities, may be empty but never null.
     */
    public LinkCapabilities getLinkCapabilities() {
        return new LinkCapabilities(mLinkCapabilities);
    }

    public void setUserDataEnable(boolean enabled) {
        Slog.d(TAG, "ignoring setUserDataEnable(" + enabled + ")");
    }

    public void setPolicyDataEnable(boolean enabled) {
        Slog.d(TAG, "ignoring setPolicyDataEnable(" + enabled + ")");
    }

    /**
     * Check if private DNS route is set for the network
     */
    public boolean isPrivateDnsRouteSet() {
        Slog.v(TAG, "isPrivateDnsRouteSet");
        return mPrivateDnsRouteSet.get();
    }

    /**
     * Set a flag indicating private DNS route is set
     */
    public void privateDnsRouteSet(boolean enabled) {
        Slog.v(TAG, "privateDnsRouteSet");
        mPrivateDnsRouteSet.set(enabled);
    }

    /**
     * Check if default route is set
     */
    public boolean isDefaultRouteSet() {
        Slog.v(TAG, "isDefaultRouteSet");
        return mDefaultRouteSet.get();
    }

    /**
     * Set a flag indicating default route is set for the network
     */
    public void defaultRouteSet(boolean enabled) {
        Slog.v(TAG, "defaultRouteSet");
        mDefaultRouteSet.set(enabled);
    }

    public void setTeardownRequested(boolean isRequested) {
        Slog.v(TAG, "setTeardownRequested(" + isRequested + ")");
        mTeardownRequested.set(isRequested);
    }

    public boolean isTeardownRequested() {
        boolean flag = mTeardownRequested.get();
        Slog.v(TAG, "isTeardownRequested: " + flag);
        return flag;
    }

    public void setDependencyMet(boolean met) {
        // not supported on this network
    }

    /**
     * Informs the state tracker that another interface is stacked on top of it.
     **/
    public void addStackedLink(LinkProperties link){
    }

    /**
     * Informs the state tracker that a stacked interface has been removed.
     **/
    public void removeStackedLink(LinkProperties link){
    }

    /*
     * Called once to setup async channel between this and
     * the underlying network specific code.
     */
    public void supplyMessenger(Messenger messenger){
    }

    /*
     * Network interface name that we'll lookup for sampling data
     */
    public String getNetworkInterfaceName(){
        return null;
    }

    /*
     * Save the starting sample
     */
    public void startSampling(SamplingDataTracker.SamplingSnapshot s){
    }

    /*
     * Save the ending sample
     */
    public void stopSampling(SamplingDataTracker.SamplingSnapshot s) {
    }

    @Override
    public void captivePortalCheckCompleted(boolean isCaptivePortal) {
        // not implemented
    }

    /**
     * Get interesting information about this network link
     * @return a copy of link information, null if not available
     */
    public LinkQualityInfo getLinkQualityInfo(){
        return null;
    }

    public String toEventString(int event) {
        if(event == PppoeManager._EVENT_CONNECTING) {
            return "_EVENT_CONNECTING(" + event + ")";
        } else if(event == PppoeManager._EVENT_CONNECTED) {
            return "_EVENT_CONNECTED(" + event + ")";
        } else if(event == PppoeManager._EVENT_DISCONNECTED) {
            return "_EVENT_DISCONNECTED(" + event + ")";
        } else if(event == PppoeManager._EVENT_CONNECT_FAILED) {
            return "_EVENT_CONNECT_FAILED(" + event + ")";
        } else if(event == PppoeManager._EVENT_DISCONNECT_FAILED) {
            return "_EVENT_DISCONNECT_FAILED(" + event + ")";
        } else if(event == PppoeManager.EVENT_CONNECT_SUCCESSED) {
            return "EVENT_CONNECT_SUCCESSED(" + event + ")";
        } else if(event == PppoeManager.EVENT_CONNECT_FAILED) {
            return "EVENT_CONNECT_FAILED(" + event + ")";
        } else {
            return "UNKOWN_EVENT(" + event + ")";
        }
    }

    public boolean startDualStackPppoe() {
        Slog.i(TAG, "Dualstack pppoe start!");
        PppoeDevInfo info = mEM.getSavedPppoeConfig();
        if(info == null) {
            Slog.w(TAG, "getSavedPppoeConfig info is null");
            Slog.i(TAG, "Dualstack pppoe start failed!");
            return false;
        }
        String usr = info.getAccount();
        String pwd = info.getPassword();
        Slog.i(TAG, "Username: " + usr + ", Password: " + pwd);
        if ((usr != null) && (pwd != null)) {
            connect(usr, pwd, "eth0.45");
            Slog.i(TAG, "Dualstack pppoe start OK!");
            return true;
        }
        Slog.i(TAG, "Dualstack pppoe start failed!");
        return false;
    }

    public void disconnectDualStackPppoe() {
        Slog.i(TAG, "Dualstack disconnect pppoe!");
        disconnect("eth0");
    }

    public void setDualStackTarget(Handler target) {
        mDualStackTarget = target;
    }
}
