#define LOG_NDEBUG 0
#define LOCAL_TAG "PPPOE_JNI"

#include <jni.h>
#include <JNIHelp.h>
#include <android_runtime/AndroidRuntime.h>
#include <utils/Log.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <netwrapper.h> 
#include <android/log.h>

#include "cutils/properties.h"
#include "../../../../external/ppp/pppd/pathnames.h"

#define PPPOE_PIDFILE _ROOT_PATH "/etc/ppp/pppoe.pid"
#define PPPOE_WRAPPER_CLIENT_PATH _ROOT_PATH "/etc/ppp/pppoe"
#define PPPOE_WRAPPER_SERVER_PATH "/dev/socket/pppoe_wrapper"

#define PPPOE_PLUGIN_CMD_LEN_MAX 256
#define PPPOE_CONNECT_CMD_LEN_MAX 512

#define LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, LOCAL_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOCAL_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOCAL_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOCAL_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOCAL_TAG, __VA_ARGS__)

#define TRACE() LOGI("[%s::%d]\n",__FUNCTION__,__LINE__)
using namespace android;

struct fields_t {
    JavaVM      *gJavaVM ;
    JNIEnv* env;
    jmethodID   post_event;
};

static struct fields_t fields;

static char pppoe_connect_cmd[PPPOE_CONNECT_CMD_LEN_MAX];
static char pppoe_disconnect_cmd[512] = "ppp-stop";
static char pppoe_terminate_cmd[512] = "ppp-terminate";
static char pppoe_plugin_cmd[PPPOE_PLUGIN_CMD_LEN_MAX];

#define PPPD_OPTIONS_LEN 512
static char pppd_options[PPPD_OPTIONS_LEN + 1] = {"debug logfd 1 noipdefault noauth default-asyncmap show-password nodetach mtu 1492 mru 1492 noaccomp nodeflate nopcomp novj usepeerdns novjccomp lcp-echo-interval 20 lcp-echo-failure 3"};

static int is_dual_stack()
{
    char tmp[PROPERTY_VALUE_MAX] = {'\0'};
    property_get("persist.sys.eth.doublestack", tmp, "false");
    LOGW("%s: %s\n", __FUNCTION__, tmp);
    return (0 != strcmp(tmp, "false"));
}

static int getTimeout()
{
    char tmp[PROPERTY_VALUE_MAX] = {'\0'};
    property_get("net.dualstack.timeout", tmp, "0");
    LOGW("%s: %s\n", __FUNCTION__, tmp);
    return atoi(tmp);
}

static int getInterBase()
{
    char tmp[PROPERTY_VALUE_MAX] = {'\0'};
    property_get("net.dualstack.interbase", tmp, "0");
    LOGW("%s: %s\n", __FUNCTION__, tmp);
    return atoi(tmp);
}

static char* create_pppoe_plugin_cmd(char *pid_file, char *phy_if)
{
    int len;
    if (is_dual_stack()) {
        len = snprintf(pppoe_plugin_cmd, PPPOE_PLUGIN_CMD_LEN_MAX,
                   "'pppoe -p %s -I %s -T %d -t %d -B -U -m 1412'",
                   pid_file, phy_if, getTimeout(), getInterBase());
    } else {
        len = snprintf(pppoe_plugin_cmd, PPPOE_PLUGIN_CMD_LEN_MAX, 
                   "'pppoe -p %s -I %s -T 80 -U -m 1412'", 
                   pid_file, phy_if);
    }

    if ( len < 0 || len >= PPPOE_PLUGIN_CMD_LEN_MAX ) {
        return NULL;
    }

    return pppoe_plugin_cmd;

}

static char* create_pppoe_connect_cmd
(char *plugin_cmd, char *options, char *username, char *pwd)
{
    int len;
    len = snprintf(pppoe_connect_cmd, PPPOE_CONNECT_CMD_LEN_MAX, 
                   "pppd pty %s %s user %s password %s &", 
                   plugin_cmd, options, username, pwd);
    if ( len < 0 || len >= PPPOE_CONNECT_CMD_LEN_MAX ) {
        return NULL;
    }

    return pppoe_connect_cmd;
}

#include "../../../../external/ppp/pppd/pathnames.h"
#define CONFIG_FILE  _ROOT_PATH "/etc/ppp/pppd_options.conf"

/* Handy routine to read very long lines in text files.
 * This means we read the whole line and avoid any nasty buffer overflows. */
static ssize_t get_line(char **line, size_t *len, FILE *fp)
{
    char *p;
    size_t last = 0;

    while(!feof(fp)) {
        if (*line == NULL || last != 0) {
            *len += BUFSIZ;
            *line = (char*)realloc(*line, *len);
        }
        p = *line + last;
        memset(p, 0, BUFSIZ);
        if (fgets(p, BUFSIZ, fp) == NULL)
            break;
        last += strlen(p);
        if (last && (*line)[last - 1] == '\n') {
            (*line)[last - 1] = '\0';
            break;
        }
    }
    return last;
}

static const char PPPOE_PHY_IF_PROP_NAME[]    = "net.pppoe.phyif";

static jboolean android_net_pppoe_PppoeOperation_connect
(JNIEnv *env, jobject obj, jstring jstr_if_name, jstring jstr_account, jstring jstr_passwd)
{
    char *p_ifname;
    char *p_user; 
    char *p_passwd;
    struct netwrapper_ctrl * ctrl;
    char *p;
    char smtu[PROPERTY_VALUE_MAX] = {0};
    property_get("sys.net.mtu",smtu, "0");
    int mtu = atoi(smtu);
    char pppd_options_mtu[PPPD_OPTIONS_LEN + 1] = {0};
    if(mtu > 1000) {
       int pppmtu = mtu - 8;
       snprintf(pppd_options_mtu,PPPD_OPTIONS_LEN,"debug logfd 1 noipdefault noauth default-asyncmap show-password nodetach mtu %d mru %d noaccomp nodeflate nopcomp novj usepeerdns novjccomp lcp-echo-interval 20 lcp-echo-failure 3",pppmtu, pppmtu);
       LOGD("pppoe mtu: [%s]\n", smtu);
   }

    FILE *f;
    f = fopen(CONFIG_FILE, "r");
    LOGD("Try Open %s\n", CONFIG_FILE);

    if (is_dual_stack()) {
        snprintf(pppd_options, sizeof(pppd_options), "%s lcp-max-configure %d", pppd_options, getTimeout());
    }
    LOGD("pppd_options %s\n", pppd_options);

    if (f) {
        char *line, *option, *p, *buffer = NULL;
        size_t len = 0;

        get_line(&buffer, &len, f);
        LOGD("get_line: [%s]\n", buffer);
        if (buffer){
            if(mtu > 1000){
                strncpy(pppd_options_mtu, buffer, sizeof(pppd_options_mtu) - 1);
            } else {
                strncpy(pppd_options, buffer, sizeof(pppd_options) - 1);
            }
            free(buffer);
        }
        fclose(f);
    }

    p_ifname = (char *)env->GetStringUTFChars(jstr_if_name, NULL);
    p_user = (char *)env->GetStringUTFChars(jstr_account, NULL);
    p_passwd = (char *)env->GetStringUTFChars(jstr_passwd, NULL);

    property_set(PPPOE_PHY_IF_PROP_NAME, p_ifname);

    p = create_pppoe_plugin_cmd((char*)PPPOE_PIDFILE, p_ifname);
    if (!p) {
        LOGW("failed to create plug_in command\n");
        return -1;
    }

    LOGD("plug_in command: %s\n", p);

    if (mtu > 1000) {
        p = create_pppoe_connect_cmd(p, pppd_options_mtu, p_user, p_passwd);
    } else {
        p = create_pppoe_connect_cmd(p, pppd_options, p_user, p_passwd);
    }
    if (!p) {
        LOGW("failed to create connect command\n");
        return -1;
    }

    LOGD("connect command: %s\n", p);
    LOGD("ppp.connect\n");

    ctrl = netwrapper_ctrl_open(PPPOE_WRAPPER_CLIENT_PATH, PPPOE_WRAPPER_SERVER_PATH);
    if (ctrl == NULL) {
        LOGW("Failed to connect to pppd\n");
        return -1;
    }
    netwrapper_ctrl_request(ctrl, pppoe_connect_cmd, strlen(pppoe_connect_cmd));
    netwrapper_ctrl_close(ctrl);

    env->ReleaseStringUTFChars(jstr_if_name, p_ifname);
    env->ReleaseStringUTFChars(jstr_account, p_user);
    env->ReleaseStringUTFChars(jstr_passwd, p_passwd);
    return 1;
}

jboolean android_net_pppoe_PppoeOperation_disconnect
(JNIEnv *env, jobject obj)
{
    struct netwrapper_ctrl * ctrl;

    LOGD("ppp.disconnect\n");
    ctrl = netwrapper_ctrl_open(PPPOE_WRAPPER_CLIENT_PATH, PPPOE_WRAPPER_SERVER_PATH);
    if (ctrl == NULL) {
        LOGW("Failed to connect to pppd\n");
        return -1;
    }

    netwrapper_ctrl_request(ctrl, pppoe_disconnect_cmd, strlen(pppoe_disconnect_cmd));
    netwrapper_ctrl_close(ctrl);
    return 1;
}

jboolean android_net_pppoe_PppoeOperation_terminate
(JNIEnv *env, jobject obj)
{
    struct netwrapper_ctrl * ctrl;
    char value[PROPERTY_VALUE_MAX] = {0};

    property_get(PPPOE_PHY_IF_PROP_NAME, value, "eth0");
    LOGD("ppp.terminate(%s)\n", value);

    ctrl = netwrapper_ctrl_open(PPPOE_WRAPPER_CLIENT_PATH, PPPOE_WRAPPER_SERVER_PATH);
    if (ctrl == NULL) {
        LOGW("Failed to connect to pppd\n");
        return -1;
    }

    netwrapper_ctrl_request(ctrl, pppoe_terminate_cmd, strlen(pppoe_terminate_cmd));
    netwrapper_ctrl_close(ctrl);
    return 1;
}

static JNINativeMethod gPppoeJNIMethods[] = {
    /* name, signature, funcPtr */
    { "connect",       "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z", (void*) android_net_pppoe_PppoeOperation_connect },
    { "disconnect",    "()Z", (void*) android_net_pppoe_PppoeOperation_disconnect },
    { "terminate",     "()Z", (void*) android_net_pppoe_PppoeOperation_terminate },
};

#define PPPOE_CLASS_NAME "android/net/pppoe/PppoeOperation"

int register_pppoe_jni(JNIEnv* env)
{
    int ret;
    jclass pppoe = env->FindClass(PPPOE_CLASS_NAME);
    if (NULL == pppoe) {
        LOGI("%s:Unable to find class %s", __FUNCTION__, PPPOE_CLASS_NAME);
        return -1;
    }
    else {
        LOGI("%s:class %s FOUND", __FUNCTION__, PPPOE_CLASS_NAME);
    }
    
    TRACE();
    ret = android::AndroidRuntime::registerNativeMethods(env,
            PPPOE_CLASS_NAME, gPppoeJNIMethods, NELEM(gPppoeJNIMethods));
    return ret;
}


JNIEXPORT jint
JNI_OnLoad(JavaVM* vm, void* reserved)
{
    jint ret;
    JNIEnv* env = NULL;
    TRACE();
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK || NULL == env) {
        LOGE("GetEnv failed!");
        return -1;
    }
    fields.gJavaVM = vm;
    fields.env = env;
    TRACE();
    ret = register_pppoe_jni(env);
    LOGI("register_pppoe_jni=%d\n", ret);
    if (ret == 0) {
        return JNI_VERSION_1_4;
    } else {
        return -1;
    }
}


JNIEXPORT void
JNI_OnUnload(JavaVM* vm, void* reserved)
{
    return;
}


