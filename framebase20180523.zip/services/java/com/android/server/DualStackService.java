package com.android.server;  
  
import android.content.Context;
import android.content.ContentResolver;
import android.database.ContentObserver;
import android.net.ethernet.EthernetStateTracker;
import android.net.ethernet.EthernetManager;
import android.net.vlan.VlanStateTracker;
import android.net.vlan.VlanManager;
import android.net.vlan.VlanDevInfo;
import android.net.ethernet.DualStackManager;
import android.net.ethernet.IDualStackManager;
import android.net.pppoe.PppoeDevInfo;
import android.net.pppoe.PppoeManager;
import android.net.pppoe.PppoeStateTracker;
import android.net.NetworkStateTracker;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.SystemProperties;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import android.util.Slog;

public class DualStackService extends IDualStackManager.Stub {
    private static final String TAG = "DualStackService";
    private static final String CONF_PATH = "/data/misc/etc/dhcpcd.conf";
    private static final String DEF_CONF_PATH = "/system/etc/dhcpcd/dhcpcd.conf";
    private static final int NR_IPOE_RETRY = 2;
    private EthernetManager mEthMgr;
    private PppoeManager mPppoeMgr;
    private VlanManager mVlanMgr;
    private ArrayList<NetworkStateTracker> mNetTrackers =  new ArrayList<NetworkStateTracker>();
    private EthernetStateTracker mEthTracker = null;
    private PppoeStateTracker mPppTracker = null;
    private VlanStateTracker mVlanTracker = null;
    private Handler mDualStackHandler = null;
    private Context mContext = null;
    private ContentResolver mCR = null;
    private static int mLoop = 0;
    private static final int LOOP_MAX  = 10;

    private static final int STATE_INIT     = 0;
    private static final int STATE_IPOE_STARTED     = 100;
    private static final int STATE_PPPOE_STARTED     = 200;
    private static final int STATE_IPOE_FAILED     = 300;
    private static final int STATE_PPPOE_FAILED     = 400;
    private static final int STATE_NETWORK_FAILED     = 500;
    private static final int STATE_NETWORK_READY     = 600;
    private int mState = STATE_INIT;
    

    public DualStackService(Context context){
        mContext = context;
        mNetTrackers.clear();
        mCR = mContext.getContentResolver();

        Slog.d(TAG, "Init");

        HandlerThread dualStackThread = new HandlerThread("DualStack HandlerThread");
        dualStackThread.start();
        mDualStackHandler = new Handler(dualStackThread.getLooper(), mDualStackHandlerCallback);
        mCR.registerContentObserver(Settings.Secure.getUriFor(
                Settings.Secure.ETH_DUALSTACK), false,
                new ContentObserver(null) {
                    @Override
                    public void onChange(boolean selfChange) {
                        Slog.d(TAG, Settings.Secure.ETH_DUALSTACK + " is onChange!");
                        setDualStackEnabledImpl(getDualStackState());
                    }
                });
    }
    

    public void addNetStateTracker(ArrayList<NetworkStateTracker> trackers) {
        mNetTrackers.addAll(trackers);
        mEthMgr = (EthernetManager) mContext.getSystemService(Context.ETH_SERVICE);
        mVlanMgr = (VlanManager) mContext.getSystemService(Context.VLAN_SERVICE);
        mPppoeMgr = (PppoeManager) mContext.getSystemService(Context.PPPOE_SERVICE);
        for (NetworkStateTracker tracker : mNetTrackers) {
            if (tracker instanceof EthernetStateTracker) {
                Slog.d(TAG, "EthernetStateTracker is Added");
                mEthTracker = (EthernetStateTracker) tracker;
            } else if (tracker instanceof VlanStateTracker) {
                Slog.d(TAG, "VlanStateTracker is Added");
                mVlanTracker = (VlanStateTracker) tracker;
            } else if (tracker instanceof PppoeStateTracker) {
                Slog.d(TAG, "PppoeStateTracker is Added");
                mPppTracker = (PppoeStateTracker) tracker;
            }
        }
        setDualStackEnabledImpl(getDualStackState());
    }

    private String getStateDesc(int state) {
        if (state == STATE_INIT)
            return "INIT";
        else if (state == STATE_IPOE_STARTED)
            return "IPOE_STARTED";
        else if (state == STATE_PPPOE_STARTED)
            return "PPPOE_STARTED";
        else if (state == STATE_IPOE_FAILED)
            return "IPOE_FAILED";
        else if (state == STATE_PPPOE_FAILED)
            return "PPPOE_FAILED";
        else if (state == STATE_NETWORK_FAILED)
            return "NETWORK_FAILED";
        else if (state == STATE_NETWORK_READY)
            return "NETWORK_READY";
        else
            return "UNKNOWN";
    }

    private String getEventDesc(int event) {
        if (event == DualStackManager.EVENT_IPOE_START)
            return "IPOE_START";
        else if (event == DualStackManager.EVENT_IPOE_SUCCEEDED)
            return "IPOE_OK";
        else if (event == DualStackManager.EVENT_IPOE_FAILED)
            return "IPOE_FAILED";
        else if (event == DualStackManager.EVENT_PPPOE_START)
            return "PPPOE_START";
        else if (event == DualStackManager.EVENT_PPPOE_SUCCEEDED)
            return "PPPOE_OK";
        else if (event == DualStackManager.EVENT_PPPOE_FAILED)
            return "PPPOE_FAILED";
        else
            return "UNKNOWN";
    }

    private Handler.Callback mDualStackHandlerCallback = new Handler.Callback() {
        /** {@inheritDoc} */
        public boolean handleMessage(Message msg) {
            synchronized (this) {
                Slog.d(TAG, "Recv EVENT:" + getEventDesc(msg.what) + " on STATE:" + getStateDesc(mState));
                switch (mState) {
                case STATE_INIT:
                    if (msg.what == DualStackManager.EVENT_IPOE_START) {
                        mState = STATE_IPOE_STARTED;
                    }
                    else if (msg.what == DualStackManager.EVENT_IPOE_FAILED) {
                        mState = STATE_PPPOE_STARTED;
                        if (mPppTracker != null) {
                            mLoop++;
                            mPppTracker.startDualStackPppoe();
                        }
                    }
                    else if (msg.what == DualStackManager.EVENT_PPPOE_START) {
                        mState = STATE_PPPOE_STARTED;
                    }
                    mLoop++;
                    break;

                case STATE_IPOE_STARTED:
                    if (mLoop >= 2*LOOP_MAX) {
                        mState = STATE_NETWORK_FAILED;
                        break;
                    }

                    if (msg.what == DualStackManager.EVENT_IPOE_SUCCEEDED) {
                        mState = STATE_NETWORK_READY;
                    }
                    else if (msg.what == DualStackManager.EVENT_IPOE_FAILED) {
                        mState = STATE_PPPOE_STARTED;
                        if (mPppTracker != null) {
                            mLoop++;
                            mPppTracker.startDualStackPppoe();
                        }
                    }
                    break;

                case STATE_PPPOE_STARTED:
                    if (mLoop >= 2*LOOP_MAX) {
                        mState = STATE_NETWORK_FAILED;
                        break;
                    }

                    if (msg.what == DualStackManager.EVENT_PPPOE_SUCCEEDED) {
                        mState = STATE_NETWORK_READY;
                    }
                    else if (msg.what == DualStackManager.EVENT_PPPOE_FAILED) {
                        mState = STATE_IPOE_STARTED;
                        if (mVlanTracker != null) {
                            mLoop++;
                            mVlanTracker.startDualStackIpoe();
                        }
                    }
                    break;
                case STATE_NETWORK_FAILED:
                    break;
                }
            }

            return true;
        }
    };

    public boolean setDualStackEnabled(boolean enabled) {
        Slog.d(TAG, "setDualStackEnabled: " + enabled);
        Settings.Secure.putString(mCR, Settings.Secure.ETH_DUALSTACK, enabled ? "true" : "false");
        if (enabled) {
            setDualStackEnabledImpl(DualStackManager.DUALSTACK_STATE_ENABLED);
        } else {
            setDualStackEnabledImpl(DualStackManager.DUALSTACK_STATE_DISABLED);
        }
        return true;
    }
    
    private void setDualStackEnabledImpl(int state) {
        Slog.d(TAG, "setDualStackEnabledImpl: " + state);
        if (state == DualStackManager.DUALSTACK_STATE_ENABLED) {
            if (mEthTracker != null) {
                Slog.d(TAG, "setDualStackEnabledImpl: ignore EthernetStateTracker");
                //mEthTracker.setDualStackTarget(mDualStackHandler);
            } 
            if (mVlanTracker != null) {
                mVlanTracker.setDualStackTarget(mDualStackHandler);
            }

            if (mPppTracker != null) {
                mPppTracker.setDualStackTarget(mDualStackHandler);
            }
        } else if (state == DualStackManager.DUALSTACK_STATE_DISABLED) {
            if (mEthTracker != null) {
                mEthTracker.setDualStackTarget(null);
            } else if (mVlanTracker != null) {
                mVlanTracker.setDualStackTarget(null);
            } else if (mPppTracker != null) {
                mPppTracker.setDualStackTarget(null);
            }
        }
    }

    public int getDualStackState() {
		String doubleStackEnabled = SystemProperties.get("persist.sys.eth.doublestack");
        String enabled = Settings.Secure.getString(mCR, Settings.Secure.ETH_DUALSTACK);
		enabled = doubleStackEnabled;
        Slog.d(TAG, "getDualStackState: " + enabled);
        if("true".equals(enabled)) {
			Settings.Secure.putString(mCR, Settings.Secure.ETH_DUALSTACK,"true");
            return DualStackManager.DUALSTACK_STATE_ENABLED;
        } else {
			Settings.Secure.putString(mCR, Settings.Secure.ETH_DUALSTACK,"false");
            return DualStackManager.DUALSTACK_STATE_DISABLED;
        }
    }
}

