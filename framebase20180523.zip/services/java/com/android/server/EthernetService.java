/*
 * Copyright (C) 2009 The Android-x86 Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Author: Yi Sun <beyounn@gmail.com>
 */

package com.android.server;

import java.net.UnknownHostException;
import android.net.ethernet.EthernetNative;
import android.net.ethernet.IEthernetManager;
import android.net.wifi.WifiManager;
import android.net.ethernet.EthernetManager;
import android.net.ethernet.EthernetStateTracker;
import android.net.ethernet.EthernetDevInfo;
import android.net.vlan.VlanDevInfo;
import android.net.ConnectivityManager;
import android.net.ethernet.EthernetStateMachine;

import android.provider.Settings;
import android.util.Slog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.FileUtils;
import android.os.Handler;
import android.os.PowerManager;
import android.os.SystemProperties;
import android.net.DhcpInfo;
import android.net.NetworkUtils;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.net.NetworkInterface;
import android.os.IBinder;
import android.os.INetworkManagementService;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.net.InterfaceConfiguration;
import java.net.InetAddress;
import android.net.LinkAddress;
import android.net.NetworkInfo;
import android.net.RouteInfo;
import android.net.DhcpInfoInternal;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import android.text.TextUtils;
import java.util.Enumeration;
import java.net.SocketException;
import android.os.UserHandle;
import java.util.NoSuchElementException;

public class EthernetService<syncronized> extends IEthernetManager.Stub{
    private Context mContext;
    private EthernetStateTracker mTracker;
    private String[] DevName;
    private static final String TAG = "EthernetService";
    private int isEthEnabled ;
    private static boolean mIpv6ConnectStatus = false;
    private int mEthState= EthernetManager.ETH_STATE_UNKNOWN;
    
    private Handler mDelayedHandler;    
    private Handler mEthStateHandler;
    private boolean isEthernetServiceInited = false;    
    private PowerManager.WakeLock mWakeLock = null;

    private final EthernetStateMachine mEthStateMachine;

    public EthernetService(Context context, EthernetStateTracker Tracker){
        mTracker = Tracker;
        mContext = context;

        mWakeLock = ((PowerManager)mContext.getSystemService(Context.POWER_SERVICE)).newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, TAG);
        wakeLock();

        isEthEnabled = getPersistedState();
        Slog.v(TAG,"Ethernet dev enabled " + isEthEnabled );
        getDeviceNameList();
        mEthStateMachine = new EthernetStateMachine(mContext,ConnectivityManager.TYPE_ETHERNET);
        mTracker.setEthernetStateMachine(mEthStateMachine);

        HandlerThread ethStateThread = new HandlerThread("ethState Handler Thread");
        ethStateThread.start();
        mEthStateHandler = new Handler(ethStateThread.getLooper(), mEthStateHandlerCallback);
        setEthState(isEthEnabled);
        isEthernetServiceInited = true;
        registerForBroadcasts();
        Slog.v(TAG, "Trigger the ethernet monitor");
        mTracker.StartPolling();
        mDelayedHandler = new Handler();  
        //parserConf(createAuthFileName());
    }
 
    public void checkIfNeddStart(){
        isEthEnabled = getPersistedState();
        Slog.v(TAG,"Ethernet dev enabled " + isEthEnabled );
        getDeviceNameList();
        isEthernetServiceInited = true;
        setEthState(isEthEnabled);
    }
    
    private void wakeLock() {
        if(!mWakeLock.isHeld())
            mWakeLock.acquire();
    }
    
    private void wakeUnlock() {
        if(mWakeLock.isHeld())
            mWakeLock.release();
    }

    public boolean isEthConfigured() {
        final ContentResolver cr = mContext.getContentResolver();
        int x = Settings.Secure.getInt(cr, Settings.Secure.ETH_CONF,0);

        if (x == 1)
            return true;
        return false;
    }

    public synchronized EthernetDevInfo getSavedEthConfig() {
        if (isEthConfigured()) {
            final ContentResolver cr = mContext.getContentResolver();
            EthernetDevInfo info = new EthernetDevInfo();
            info.setConnectMode(Settings.Secure.getString(cr, Settings.Secure.ETH_MODE));
            info.setIfName(Settings.Secure.getString(cr, Settings.Secure.ETH_IFNAME));
            info.setIpAddress(Settings.Secure.getString(cr, Settings.Secure.ETH_IP));
            info.setDns1Addr(Settings.Secure.getString(cr, Settings.Secure.ETH_DNS1));
            info.setDns2Addr(Settings.Secure.getString(cr, Settings.Secure.ETH_DNS2));
            info.setNetMask(Settings.Secure.getString(cr, Settings.Secure.ETH_MASK));
            info.setRouteAddr(Settings.Secure.getString(cr, Settings.Secure.ETH_ROUTE));

            final String host = Settings.Secure.getString(cr, Settings.Secure.ETH_PROXY_HOST);
            if (host != null && host.length() != 0) {
                info.setProxy(host,
                    Settings.Secure.getInt(cr, Settings.Secure.ETH_PROXY_PORT, 8080),
                    Settings.Secure.getString(cr, Settings.Secure.ETH_PROXY_EXCLUSION_LIST));
            }

            return info;
        }
        return null;
    }

    public synchronized void setEthMode(String mode) {
        final ContentResolver cr = mContext.getContentResolver();
        Slog.v(TAG,"Set ethernet mode " + DevName + " -> " + mode);
        if (DevName != null) {
            Settings.Secure.putString(cr, Settings.Secure.ETH_IFNAME, DevName[0]);
        } else {
            if((scanEthDevice() > 0) && (DevName != null)) {
               Settings.Secure.putString(cr, Settings.Secure.ETH_IFNAME, DevName[0]);
            } else {
               Slog.v(TAG,"Set ifname default eth0");
               Settings.Secure.putString(cr, Settings.Secure.ETH_IFNAME, "eth0");
            }
        }
        Settings.Secure.putInt(cr, Settings.Secure.ETH_CONF, 1);
        Settings.Secure.putString(cr, Settings.Secure.ETH_MODE, mode);
        if(EthernetDevInfo.ETH_CONN_MODE_MANUAL.equals(mode)
                || EthernetDevInfo.ETH_CONN_MODE_DHCP.equals(mode)) {
            setAuthState(mUserName, mPassword, mVendorId, false);
        }
    }

    /* Checking ip address conflict has to wait for arp reply packet.
     * Arping service is blocked if there is no ip conflict existed.
     * In order to avoid demaging User Exerience, We ONLY give CHECK_TIMEOUT_MS
     * time for arpingThread to get the result.
     *
     * If CHECK_TIMEOUT_MS is too short to get an arp reply in some network environment.
     * our returnal result would be incorrect and ip conflict is omissioned, but the
     * background thread will still send broadcast to notify ip conflict.
     *
     */
    private boolean isIpConflict = false;
    private boolean isIpConflict(String address, String interfaceName) {
        int CHECK_TIMEOUT_MS = 400;
        isIpConflict = false;
        final String ipAddress = address;
        final String ifname = interfaceName;

        /* switch for IpConflict
         * TODO: use property or other method to control this ipconflict check switch.
         */
        if (false) {
            Slog.d(TAG, "isIpConflict check is disabled.");
            return false;
        }
        Thread arpingThread = new Thread(new Runnable() {
            public void run() {
                Slog.d(TAG, "start arpingThread: isIpConflict:ifname:"+ifname +" ipAddress:"+ipAddress);
                //compare ifname and ip with other interfaces on board.
                Enumeration<NetworkInterface> netInterfaces = null;
                try{
                    netInterfaces = NetworkInterface.getNetworkInterfaces();
                }catch(SocketException e){
                    e.printStackTrace();
                }

                if (netInterfaces != null) {
                    while (netInterfaces.hasMoreElements()) {
                        NetworkInterface ni = netInterfaces.nextElement();
                        Enumeration<InetAddress> ips = ni.getInetAddresses();
                        while(ips.hasMoreElements()){
                            InetAddress ia = null;
                            try {
                                ips.nextElement();
                                ia = ips.nextElement();
                            }
                            catch (NoSuchElementException e) {
                                    e.printStackTrace();
                                    break;
                            }
                            if(ni.getName().equals(ifname))
                                break;
                            if(ia.toString().substring(1).equals(ipAddress)) {
                                isIpConflict = true;
                            }
                        }
                    }
                }

                if(!isIpConflict)
                    isIpConflict = NetworkUtils.runArping(ifname, ipAddress);

                Slog.d(TAG, "arpingThread: isIpConflict:" + isIpConflict);
                if(isIpConflict){
                    //broadcast a intent
                    Intent intent = new Intent(ConnectivityManager.ACTION_IP_ADDRESS_CONFLICTED);
                    intent.addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);
                    /*
                     * Connectivity events can happen before boot has completed ...
                     */
                    intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
                    mContext.sendBroadcastAsUser(intent, UserHandle.ALL);
                    Slog.d(TAG, "intent:ACTION_IP_ADDRESS_CONFLICTED is broadcasted !");
                }
            }
        });
        arpingThread.start();

        try {
                Thread.sleep(50);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        }
        /* Wait if Ip Conflict is not detected for after 50ms.
         * 50ms is a experiment time value: tests indicates that we
         * get arp reply packet no sooner than 50ms if there is a conflcit ip.
         * */
        if (!isIpConflict) {
                Slog.d(TAG, "isIpConflict:" + " wait...");
            try {
                    Thread.sleep(CHECK_TIMEOUT_MS - 50);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
                return false;
            }
        }

        Slog.d(TAG, "isIpConflict: return " +isIpConflict);
        return isIpConflict;
    }

	private void printStackTrace() {
		Thread t = Thread.currentThread();
		StackTraceElement st[]= t.getStackTrace();
		Slog.i(TAG, "Thread " + t.getName() +"(#" + t.getId() + ")");
		for(int i=2;i<st.length;i++)
			Slog.i(TAG, i+":"+st[i]);
	
		Slog.i(TAG, "\n\n");
	}


    public synchronized void UpdateEthDevInfo(EthernetDevInfo info) {
        final ContentResolver cr = mContext.getContentResolver();
        String mode = info.getConnectMode();

        Settings.Secure.putInt(cr, Settings.Secure.ETH_CONF,1);
        Settings.Secure.putString(cr, Settings.Secure.ETH_IFNAME, info.getIfName());
        if (EthernetDevInfo.ETH_CONN_MODE_MANUAL.equals(mode)
                || EthernetDevInfo.ETH_CONN_MODE_DHCP.equals(mode)) {
            setAuthState(mUserName, mPassword, mVendorId, false);
        }
        if (EthernetDevInfo.ETH_CONN_MODE_MANUAL.equals(mode)) {
            if (mTracker.isIpAddress(info.getIpAddress())
                            && mTracker.isIpAddress(info.getNetMask())
                            &&!isIpConflict(info.getIpAddress(), info.getIfName())) {
                Settings.Secure.putString(cr, Settings.Secure.ETH_IP, info.getIpAddress());
                Settings.Secure.putString(cr, Settings.Secure.ETH_MASK,info.getNetMask());
                Settings.Secure.putString(cr, Settings.Secure.ETH_DNS1, info.getDns1Addr());
                Settings.Secure.putString(cr, Settings.Secure.ETH_DNS2, info.getDns2Addr());
                Settings.Secure.putString(cr, Settings.Secure.ETH_ROUTE, info.getRouteAddr());
            } else {
                Slog.e(TAG, "UpdateEthDevInfo, ip or netmask is error, ip: " + info.getIpAddress()
                        + " netmask: " + info.getNetMask());
                return;
            }
        }
        	Settings.Secure.putString(cr, Settings.Secure.ETH_MODE, mode);
        if(mode.equals(EthernetDevInfo.ETH_CONN_MODE_DHCP_AUTH)) {
            Slog.e(TAG, "Fixme: " + info.getIfName() + ". update VLAN to "+ VlanDevInfo.VLAN_CONN_MODE_DHCP_AUTH);
            Settings.Secure.putString(cr, Settings.Secure.VLAN_MODE, VlanDevInfo.VLAN_CONN_MODE_DHCP_AUTH);
        }

        if(mode.equals(EthernetDevInfo.ETH_CONN_MODE_PPPOE)) {
            Slog.e(TAG, "Fixme: " + info.getIfName() + ". update VLAN to "+ VlanDevInfo.VLAN_CONN_MODE_PPPOE);
            Settings.Secure.putString(cr, Settings.Secure.VLAN_MODE, VlanDevInfo.VLAN_CONN_MODE_PPPOE);
        }

        if (info.hasProxy()) {
            Settings.Secure.putString(cr, Settings.Secure.ETH_PROXY_HOST, info.getProxyHost());
            Settings.Secure.putInt(cr, Settings.Secure.ETH_PROXY_PORT, info.getProxyPort());
            Settings.Secure.putString(cr, Settings.Secure.ETH_PROXY_EXCLUSION_LIST,
                info.getProxyExclusionList());
        } else {
            Settings.Secure.putString(cr, Settings.Secure.ETH_PROXY_HOST, "");
            Settings.Secure.putInt(cr, Settings.Secure.ETH_PROXY_PORT, 8080);
            Settings.Secure.putString(cr, Settings.Secure.ETH_PROXY_EXCLUSION_LIST, "");
        }

        if (EthernetDevInfo.ETH_CONN_MODE_PPPOE.equals(mode)) {
            Slog.v(TAG, "Fixme: UGLY. For Force PPPoE to DHCP. MUST DO SOMETHING LATER.");
            //Slog.v(TAG, "ONLY change coonect mode for PPPOE.");
            //return;
        }
		printStackTrace();
        if (mEthState == EthernetManager.ETH_STATE_ENABLED) {
            try {
				Slog.i(TAG, "$$UpdateEthDevInfo() call resetInterface()");
                mTracker.resetInterface();
            } catch (UnknownHostException e) {
                Slog.e(TAG, "Wrong ethernet configuration");
            }
        }
    }

    private void registerForBroadcasts() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        mContext.registerReceiver(mReceiver, intentFilter);
    }

    public int getTotalInterface() {
        return EthernetNative.getInterfaceCnt();
    }


    private int scanEthDevice() {
        int i = 0,j;
        if ((i = EthernetNative.getInterfaceCnt()) != 0) {
            Slog.i(TAG, "total found " + i + " net devices");
            if (DevName == null || DevName.length != i)
                DevName = new String[i];
        }
        else
            return i;

        for (j = 0; j < i; j++) {
            DevName[j] = EthernetNative.getInterfaceName(j);
            if (DevName[j] == null)
                break;
            Slog.i(TAG," device " + j + " name " + DevName[j]);
        }

        return i;
    }

    public String[] getDeviceNameList() {
        return (scanEthDevice() > 0 ) ? DevName : null;
    }

    private int getPersistedState() {
        final ContentResolver cr = mContext.getContentResolver();
        try {
            return Settings.Secure.getInt(cr, Settings.Secure.ETH_ON);
        } catch (Settings.SettingNotFoundException e) {
            //return EthernetManager.ETH_STATE_UNKNOWN;
            return EthernetManager.ETH_STATE_ENABLED;
        }
    }

    private synchronized void persistEthEnabled(boolean enabled) {
        final ContentResolver cr = mContext.getContentResolver();
        Settings.Secure.putInt(cr, Settings.Secure.ETH_ON,
        enabled ? EthernetManager.ETH_STATE_ENABLED : EthernetManager.ETH_STATE_DISABLED);
    }

    private final Runnable mResetInterface = new Runnable() {
        public void run() {
            try {
                mTracker.resetInterface();
                Slog.i(TAG, "$$ mResetInterface call resetInterface()");
            } catch (UnknownHostException e) {
                Slog.e(TAG, "Wrong ethernet configuration");
            }
        }
    };

    private final Runnable mUnlockTimeout = new Runnable() {
        public void run() {
            ConnectivityManager mCM= (ConnectivityManager)mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            String[] TetheredIfaces = mCM.getTetheredIfaces();
            Slog.d(TAG, "Runnable TetheredIfaces size is:"+TetheredIfaces.length);
            if(TetheredIfaces.length > 0 && getPersistedState() == 2){
                Slog.d(TAG,"Runnable ether dev:"+DevName[0] +" is used for tethering !!");
                wakeUnlock();
                return ;
            }
            if(SystemProperties.getBoolean("net.dhcp.release", false)) {
                Slog.w(TAG, "Send release when suspend!");
                NetworkUtils.releaseDhcpLease("eth0");
            }
            mTracker.stopInterface_when_suspend();
            stopIpv6dhcp_when_suspend();
            mDelayedHandler.postDelayed(mWakeUnlock, 200);
        }
    };

    private final Runnable mWakeUnlock = new Runnable() {
        public void run() {
            wakeUnlock();
        }
    };
    
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equals(Intent.ACTION_SCREEN_ON)) {
                Slog.d(TAG, "ACTION_SCREEN_ON");
                mDelayedHandler.removeCallbacks(mUnlockTimeout);
                if(mWakeLock.isHeld()) {
                    ConnectivityManager mCM = (ConnectivityManager)mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
                    String[] TetheredIfaces = mCM.getTetheredIfaces();
                    Slog.d(TAG, "Receiver TetheredIfaces size: is" + TetheredIfaces.length);
                    if(TetheredIfaces.length > 0 && getPersistedState() == 2){
                        Slog.d(TAG,"Receiver ether dev:"+DevName[0] +" is used for tethering !!");
                        return;
                    }
                    mTracker.stopInterface_when_suspend();
                    stopIpv6dhcp_when_suspend();
                }
                wakeLock();
                if(getPersistedState() == 2){
                    mDelayedHandler.postDelayed(mResetInterface, 500); // wait 500ms for device ready
                }
            } else if(action.equals(Intent.ACTION_SCREEN_OFF) && !isWifiAPNetworkEnable()) {
                int delaytime = SystemProperties.getInt("sys.supend.delaytime", 0);
                Slog.d(TAG, "ACTION_SCREEN_OFF, delaytime: " + delaytime);
                mDelayedHandler.removeCallbacks(mResetInterface);
                mDelayedHandler.postDelayed(mUnlockTimeout, delaytime);
            }
        }
    };

    private boolean isWifiAPNetworkEnable() {
        boolean ap_suspend = SystemProperties.getBoolean("net.wifiap.suspend", true);
        if (!ap_suspend) {
            WifiManager wifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
            if (wifiManager != null && (wifiManager.getWifiApState() == WifiManager.WIFI_AP_STATE_ENABLED
                    || wifiManager.getWifiApState() == WifiManager.WIFI_AP_STATE_ENABLING)) {
                if(isEthernetNetworkAvailable()){
	                try {
	                    final String prefix = "/proc/ledlight/netled/state";
	                    FileUtils.stringToFile(prefix, "always_on");
	                } catch (IOException e) {
	                    Slog.e(TAG, "Can't set net led:" + e);
	                }
                }
                return true;
            }
        }
        return false;
    }

    private boolean isEthernetNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.getType() ==  ConnectivityManager.TYPE_ETHERNET) {
            return networkInfo.isAvailable();
        }
        return false;
   }

   private void sendIpv6Broadcast(String action, int event){

        final Intent intent = new Intent(action); 
        intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
        intent.putExtra(EthernetManager.EXTRA_ETHERNET_STATE, event);

        Slog.i(TAG, "sendIpv6Broadcast action : " + action + " event : " + event);
        if(event == EthernetManager.EVENT_DHCPV6_CONNECT_SUCCESSED || event == EthernetManager.EVENT_STATIC6_CONNECT_SUCCESSED){
              mIpv6ConnectStatus = true;
        }else{
              mIpv6ConnectStatus = false;
        }
        mContext.sendBroadcast(intent);   
   }

    private Handler.Callback mEthStateHandlerCallback = new Handler.Callback() {
        /** {@inheritDoc} */
        public boolean handleMessage(Message msg) {
            synchronized (this) {
                switch(msg.what) {
                case EthernetManager.ETH_STATE_DISABLED:
                    mTracker.stopInterface(false);
                    break;
                case EthernetManager.ETH_STATE_ENABLED:
                    try {
                        mTracker.resetInterface();
                    } catch (UnknownHostException e) {
                        Slog.e(TAG, "Wrong ethernet configuration");
                    }
                    break;
                case EthernetManager.IPV6_DHCP_START:
                     Slog.i(TAG, "IPV6_DHCP_START start");
                     NetworkUtils.resetConnections("eth0", NetworkUtils.RESET_IPV6_ADDRESSES);
                     SystemProperties.set("dibbler.eth0.result","none");
                     SystemProperties.set("ctl.start","dhcpv6_start");
                     int count = 20;
                     do {
                          try {
                              Thread.sleep(1000);
                              String dhcpResult  = SystemProperties.get("dibbler.eth0.result", "none");
                              count--;
                              if(dhcpResult.equals("OK")){
                                   Slog.i(TAG, "dhcpv6 suscced");
                                   Slog.i(TAG, "dhcpv6 IP : " + SystemProperties.get("dibbler.eth0.ipaddress", "none")); 
                                   Slog.i(TAG, "dhcpv6 DNS : " + SystemProperties.get("dibbler.eth0.dns1", "none")); 
                                   count = 0;
                                   sendIpv6Broadcast(EthernetManager.IPV6_STATE_CHANGED_ACTION, EthernetManager.EVENT_DHCPV6_CONNECT_SUCCESSED);
								   return true;
                               }else if(dhcpResult.equals("FAILED")){
                                   Slog.e(TAG, "dhcpv6 failed");
                                   count = 0;
                                   sendIpv6Broadcast(EthernetManager.IPV6_STATE_CHANGED_ACTION, EthernetManager.EVENT_DHCPV6_CONNECT_FAILED);
								   return true;
                               }
                          } catch (InterruptedException ex) {
                        }
                     } while(count != 0);
                     sendIpv6Broadcast(EthernetManager.IPV6_STATE_CHANGED_ACTION, EthernetManager.EVENT_DHCPV6_CONNECT_FAILED);
                     SystemProperties.set("ctl.start","dhcpv6_stop");
                     break;
                case EthernetManager.IPV6_DHCP_STOP:
                     NetworkUtils.resetConnections("eth0", NetworkUtils.RESET_IPV6_ADDRESSES);
                     SystemProperties.set("ctl.start","dhcpv6_stop");
                     Slog.i(TAG, "IPV6_DHCP_STOP");
					 break;
                case EthernetManager.IPV6_STATIC_START:
                     Slog.i(TAG, "IPV6_STATIC_START");
                     SystemProperties.set("ctl.start","dhcpv6_stop");
                     String ipaddress = getIpv6DatabaseAddress();
                     String gateway = getIpv6DatabaseGateway();
                     String dns1 = getIpv6DatabaseDns1();
                     String dns2 = getIpv6DatabaseDns2();
                     int    mask = getIpv6DatabasePrefixlength();
                     setIpv6DatabaseInfo(ipaddress,mask,gateway,dns1,dns2);
				     break;
                case EthernetManager.IPV6_STATIC_STOP:
                     Slog.i(TAG, "IPV6_STATIC_STOP");
                     NetworkUtils.resetConnections("eth0", NetworkUtils.RESET_IPV6_ADDRESSES);
                     break;
                }
            }

            return true;
        }
    };

    public synchronized void setEthState(int state) {
        Slog.i(TAG, "setEthState from " + mEthState + " to "+ state);
        if (!isEthernetServiceInited){
            Slog.i(TAG, "EthernetService uninited, don`t change eth state");
            return;
        }
        final ContentResolver cr = mContext.getContentResolver();

        if (mEthState != state) {
            mEthState = state;
            if (state == EthernetManager.ETH_STATE_DISABLED) {
                persistEthEnabled(false);
                mEthStateHandler.removeMessages(EthernetManager.ETH_STATE_ENABLED);
                mEthStateHandler.sendEmptyMessage(state);
            } else {
                persistEthEnabled(true);
                if (!isEthConfigured()) {
                    // If user did not configure any interfaces yet, pick the first one
                    // and enable it.
                    setEthMode(EthernetDevInfo.ETH_CONN_MODE_DHCP);
                }
                mEthStateHandler.removeMessages(EthernetManager.ETH_STATE_DISABLED);
                mEthStateHandler.sendEmptyMessage(state);
            }
        }
    }

    public void setEthernetDhcp(boolean enabled) {
        Slog.i(TAG, "setEthernetDhcp  " + enabled );
        if (!isEthernetServiceInited){
            Slog.i(TAG, "EthernetService uninited, do nothing");
            return;
        }
        if (enabled) {
            EthernetDevInfo info = new EthernetDevInfo();
            //FIXME: hard code for interface name
            info.setIfName("eth0");
            info.setConnectMode(EthernetDevInfo.ETH_CONN_MODE_DHCP);
            info.setIpAddress(null);
            info.setRouteAddr(null);
            info.setDns1Addr(null);
            info.setDns2Addr(null);
            info.setNetMask(null);
            String proj_type = SystemProperties.get("sys.proj.type", null);
            String proj_middleware = SystemProperties.get("sys.proj.middleware", null);
            if (!("unicom".equals(proj_type)) && !("sy".equals(proj_middleware)))
				        UpdateEthDevInfo(info);
        }
        else {
            mTracker.stopInterface(false);
        }
    }

    public int getEthState() {
        return mEthState;
    }

    public boolean isEthDeviceUp() {
        try {
            boolean retval = false;
            FileReader fr = new FileReader("/sys/class/net/" + DevName[0] +"/operstate");
            BufferedReader br = new BufferedReader(fr, 32);
            String status = br.readLine();
            if (status != null && status.equals("up")) {
                Slog.d(TAG, DevName[0] + " status:" + status);
                retval = true;
            }
            else if (status != null && status.equals("down")) {
                Slog.d(TAG, DevName[0] + " status:" + status);
                retval = false;
            }
            else {
                retval =  false;
            }
            br.close();
            fr.close();
            return retval;
        } catch (IOException e) {
            Slog.d(TAG, "get " + DevName[0] + " status error");
            return false;
        }
    }


    public boolean isEthernetDeviceUp(String ifname) {
        try {
            boolean retval = false;
            FileReader fr = new FileReader("/sys/class/net/" + ifname +"/operstate");
            BufferedReader br = new BufferedReader(fr, 32);
            String status = br.readLine();
            if (status != null && (status.equals("up")||status.equals("unknown"))) {
                Slog.d(TAG, ifname + " status:" + status);
                retval = true;
            }
            else if (status != null && status.equals("down")) {
                Slog.d(TAG, ifname + " status:" + status);
                retval = false;
            }
            else {
                retval =  false;
            }
            br.close();
            fr.close();
            return retval;
        } catch (IOException e) {
            Slog.d(TAG, "get " + ifname + " status error");
            return false;
        }
    }

    public boolean isEthDeviceAdded() {
        if (null == DevName || null == DevName[0]) {
            Slog.d(TAG, "isEthDeviceAdded: trigger scanEthDevice");
            scanEthDevice();
        }

        if (null == DevName || null == DevName[0]) {
            Slog.d(TAG, "EthernetNative.isEthDeviceAdded: No Device Found");
            return false;
        }

        int retval = EthernetNative.isInterfaceAdded(DevName[0]);
        Slog.d(TAG, "EthernetNative.isEthDeviceAdded(" + DevName[0] +") return " + (0 == retval));
        if (retval == 0)
            return true;
        else
            return false;
    }


    public boolean isEthernetDeviceAdded(String ifname) {

        int retval = EthernetNative.isInterfaceAdded(ifname);
        Slog.d(TAG, "isEthernetDeviceAdded(" + ifname +") return " + (0 == retval));
        if (retval == 0)
            return true;
        else
            return false;
    }

    public void disconnect() {
        mEthStateHandler.removeMessages(EthernetManager.ETH_STATE_ENABLED);
        mEthStateHandler.sendEmptyMessage(EthernetManager.ETH_STATE_DISABLED);
    }

    public DhcpInfo getDhcpInfo() {
        return mTracker.getDhcpInfo();
    }

    private static final String AUTH_DHCP_DIR = "/data/misc/etc/";
    private static final String AUTHNET_STATE = "authnet_state";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    private static final String VENDORID = "local_vendorclassid";
    private String mAuthState = null;
    private String mUserName = null;
    private String mPassword = null;
    private String mVendorId = null;
    
    private String createAuthFileName() {
        String filename = AUTH_DHCP_DIR + "dhcpcd-eth0-auth.conf";

        if (isEthConfigured()) {
            EthernetDevInfo info = getSavedEthConfig();
            if (info !=null) {
                String ifname = info.getIfName();
                if ((ifname != null ) && (ifname != "")) {
                    if (ifname.equals("eth0")) {
                        Slog.d(TAG, "Fixme: DISABLE IPOE for eth0 ALWAYS");
                        return null;
                    }
                    filename = AUTH_DHCP_DIR + "dhcpcd-" + ifname + "-auth.conf";
                }
            }
        }

        Slog.d(TAG, "new auth-conf file: " + filename);
        return filename;
    }

    public String getAuthUsername() {
        return mUserName;
    }

    public String getAuthPassword() {
        return mPassword;
    }
    
    public String getAuthVendorid() {
        return mVendorId;
    }
    
    public boolean getAuthState() {
        if((mAuthState != null) && (mAuthState.equals("enable"))) {
            return true;
        }
        return false;
    }
    public boolean getAuthOption125status(){
        return TextUtils.isEmpty(mVendorId);
    }

	public boolean setAuthOption125(boolean enable, String option125Info){
           Slog.d(TAG, "setAuthOption125 enable: " + enable + " option125Info: " + option125Info);
           setAuthState(mUserName, mPassword, (enable ? option125Info:""), ("enable".equals(mAuthState)));
           return true;
	}
    
    public boolean setAuthState(String username, String password, String vendorid, boolean enable) {
        Slog.d(TAG, "setAuthState username: " + username + " password: " + password
                + " vendorid: " + vendorid + " enable: " + enable);
        String authFile = createAuthFileName();
        if (authFile == null)
            return true;

        deleteAuthConf(authFile);
        try {
            File conf = new File(authFile);
            conf.createNewFile();
            conf.setReadable(true, false);
            String auth_state = enable ? "enable" : "disable";
            BufferedWriter confBufWriter = new BufferedWriter(new FileWriter(authFile));
            confBufWriter.write(AUTHNET_STATE + " \"" + auth_state + "\"");
            confBufWriter.newLine();
            confBufWriter.write(USERNAME + " \"" + (username != null ? username:"") + "\"");
            confBufWriter.newLine();
            confBufWriter.write(PASSWORD + " \"" + (password != null ? password:"") +  "\"");
            confBufWriter.newLine();
            confBufWriter.write(VENDORID + " \"" + (vendorid != null ? vendorid:"") +  "\"");
            confBufWriter.flush();
            confBufWriter.close();
            parserConf(authFile);
            return true;
        } catch(IOException e) {
            Slog.d(TAG, "write authFile failed: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    private boolean deleteAuthConf(String fileName) {
        File conf = new File(fileName);
        if(conf.exists()) {
            conf.delete();
        }
        return true;
    }
    
    private void parserConf(String fileName) {
        File conf = new File(fileName);
        if(!conf.exists()) {
            Slog.w(TAG, fileName + " is not exists");
            return;
        }

        try {
            mUserName = null;
            mPassword = null;
            mVendorId = null;
            mAuthState = null;
            BufferedReader confBufReader = new BufferedReader(new FileReader(fileName));
            while(true) {
                String line = confBufReader.readLine();
                Slog.d(TAG, "parserConf line: " + line);
                if(line == null) {
                    Slog.d(TAG, "parserConf end!");
                    break;
                }
                if(line.startsWith(USERNAME)) {
                    String[] cells = line.split("\"");
                    if(cells.length >= 2) {
                        mUserName = cells[1];
                        Slog.d(TAG, "parserConf " + USERNAME + ": " + mUserName);
                    }
                } else if(line.startsWith(PASSWORD)) {
                    String[] cells = line.split("\"");
                    if(cells.length >= 2) {
                        mPassword = cells[1];
                        Slog.d(TAG, "parserConf " + PASSWORD + ": " + mPassword);
                    }
                } else if(line.startsWith(VENDORID)) {
                    String[] cells = line.split("\"");
                    if(cells.length >= 2) {
                        mVendorId = cells[1];
                        Slog.d(TAG, "parserConf " + VENDORID + ": " + mVendorId);
                    }
                } else if(line.startsWith(AUTHNET_STATE)) {
                    String[] cells = line.split("\"");
                    if(cells.length >= 2) {
                        mAuthState = cells[1];
                        Slog.d(TAG, "parserConf " + AUTHNET_STATE + ": " + mAuthState);
                    }
                }
            }
            confBufReader.close();
        } catch(IOException e) {
            Slog.d(TAG, "parse authFile failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void stopIpv6dhcp_when_suspend(){
     mEthStateHandler.removeMessages(EthernetManager.IPV6_DHCP_STOP);
                mEthStateHandler.removeMessages(EthernetManager.IPV6_DHCP_START);
                mEthStateHandler.sendEmptyMessageDelayed(EthernetManager.IPV6_DHCP_STOP,10);
                Slog.w(TAG, "stopIpv6dhcp_when_suspend");
    }
		/**
	    * Enable/Disable DHCPV6
	    * @param enable DHCPV6 Enabled/Disabled
	    */
	public void enableIpv6(boolean enable) {

        if(getEthernetMode6() == null){
            setEthernetDefaultConf6();			 
        }

        if (enable)
        {
             if(mEthState == EthernetManager.ETH_STATE_DISABLED){
                  Slog.w(TAG, "ipv4 is closed pls open ipv4");
                  return ;
             } 
             if(getEthernetMode6() != null && getEthernetMode6().equals("dhcp")){
                mEthStateHandler.removeMessages(EthernetManager.IPV6_DHCP_START);
                mEthStateHandler.removeMessages(EthernetManager.IPV6_DHCP_STOP);
                mEthStateHandler.sendEmptyMessageDelayed(EthernetManager.IPV6_DHCP_STOP,50);
                mEthStateHandler.sendEmptyMessageDelayed(EthernetManager.IPV6_DHCP_START,1000);
                Slog.w(TAG, "start ipv6 dhcp");
             }else if(getEthernetMode6().equals("manual")){
                mEthStateHandler.removeMessages(EthernetManager.IPV6_STATIC_STOP);
                mEthStateHandler.sendEmptyMessage(EthernetManager.IPV6_STATIC_START);
                Slog.w(TAG, "start ipv6 static");
             }
             final ContentResolver cr = mContext.getContentResolver();
             Settings.Secure.putInt(cr, Settings.Secure.ETHV6_ON,EthernetManager.IPV6_STATE_ENABLED);
        } else{
             if(getEthernetMode6() != null && getEthernetMode6().equals("dhcp")){
                mEthStateHandler.removeMessages(EthernetManager.IPV6_DHCP_STOP);
                mEthStateHandler.removeMessages(EthernetManager.IPV6_DHCP_START);
                mEthStateHandler.sendEmptyMessageDelayed(EthernetManager.IPV6_DHCP_STOP,10);
                Slog.w(TAG, "stop ipv6 dhcp");
             }else if(getEthernetMode6().equals("manual")){
                mEthStateHandler.removeMessages(EthernetManager.IPV6_STATIC_START);
                mEthStateHandler.sendEmptyMessage(EthernetManager.IPV6_STATIC_STOP);
                Slog.w(TAG, "stop ipv6 dhcp--manual");
             }

             final ContentResolver cr = mContext.getContentResolver();
             mIpv6ConnectStatus = false;
             Settings.Secure.putInt(cr, Settings.Secure.ETHV6_ON,EthernetManager.IPV6_STATE_DISABLED);
        }
    }
	/**
	    * Get DHCPV6 State
	    * @return
	    *  DHCPV6_STATE_ENABLED
	    *  DHCPV6_STATE_DISABLED
	    *  DHCPV6_STATE_UNKNOWN
	    */
	public int getIpv6PersistedState() {
	    Slog.w(TAG, "getIpv6PersistedState");
	   final ContentResolver cr = mContext.getContentResolver();
        try {
            return Settings.Secure.getInt(cr, Settings.Secure.ETHV6_ON);
          } catch (Settings.SettingNotFoundException e) {
            return EthernetManager.IPV6_STATE_DISABLED;
          }
    }
	/**
	    * Save Ethernet IPV6 Obtain IP Mode
	    * @param mode
	    * ETHERNET_CONNECT_MODE_DHCP
	    * ETHERNET_CONNECT_MODE_MANUAL
	    * 
	    * String ETHERNET_CONNECT_MODE_DHCP = "dhcp";
	  * 	String ETHERNET_CONNECT_MODE_MANUAL = "manual";
	  * 	String ETHERNET_CONNECT_MODE_PPPOE = "pppoe";
	  * 	String ETHERNET_CONNECT_MODE_NONE = "none";
	    */
	public void setEthernetMode6(String mode) {
	      Slog.w(TAG, "setEthernetMode6:" + mode);
		  final ContentResolver cr = mContext.getContentResolver();
          Settings.Secure.putString(cr, Settings.Secure.ETHV6_MODE,mode);
	}
	/**
	   * Set Ethernet IPV6 Default Obtain IP Mode DHCPV6
	   */
	public void setEthernetDefaultConf6() {
		  Slog.w(TAG, "setEthernetDefaultConf6");
		  final ContentResolver cr = mContext.getContentResolver();
          Settings.Secure.putString(cr, Settings.Secure.ETHV6_MODE,"dhcp");
	}
	/**
	    * Get Ethernet IPV6 Obtain IP Mode
	    */
	public String getEthernetMode6() {
           String mode = "unknown";
           final ContentResolver cr = mContext.getContentResolver();
           mode = Settings.Secure.getString(cr, Settings.Secure.ETHV6_MODE); 
           Slog.w(TAG, "getEthernetMode6:" + mode);
           return mode;
	}
	/**
	    * Save Ethernet IPV6 Ip, Prefixlength, Gateway, Dns1, Dns2 in Database
	    * @param ip ipv6 static ip address
	    * @param prefixlength ipv6 static ip prefixlength
	    * @param gw ipv6 static ip gateway
	    * @param dns1 ipv6 static ip dns1
	    * @param dns2 ipv6 static ip dns2
	    */
	public void setIpv6DatabaseInfo(String ip, int prefixlength, String gw, String dns1, String dns2) {
			Slog.w(TAG, "setIpv6DatabaseInfo ip:" + ip + " prefixlength: " + " gw:" + gw + " dns1:" + dns1 + " dns2:" + dns2 );
            int staticresult = 1;
             if(mEthState == EthernetManager.ETH_STATE_DISABLED){
                  Slog.w(TAG, "ipv4 is closed pls open ipv4 by static ipv6");
                  return ;
             } 
			try {
				String ifname = "eth0";
				DhcpInfoInternal dhcpInfo = new DhcpInfoInternal();
				dhcpInfo.ipAddress = ip;

				dhcpInfo.prefixLength = prefixlength;

				LinkAddress myLinkAddr = new LinkAddress(dhcpInfo.ipAddress + "/" + dhcpInfo.prefixLength);
				dhcpInfo.addRoute(new RouteInfo(myLinkAddr));
				dhcpInfo.addRoute(new RouteInfo(NetworkUtils.numericToInetAddress(gw)));

				dhcpInfo.dns1 = dns1;
				Slog.d(TAG, "set IPv6: " + dhcpInfo.toString());
				NetworkUtils.resetConnections(ifname, NetworkUtils.RESET_IPV6_ADDRESSES);

				IBinder b = ServiceManager.getService(Context.NETWORKMANAGEMENT_SERVICE);
				INetworkManagementService netd = INetworkManagementService.Stub.asInterface(b);
				InterfaceConfiguration ifcg = new InterfaceConfiguration();
				ifcg.setLinkAddress(dhcpInfo.makeLinkAddress());
				ifcg.setInterfaceUp();
				try {
					netd.setInterfaceConfig(ifname, ifcg);
				} catch (RemoteException re) {
					Slog.i(TAG, "Static IPv6 configuration failed: " + re);
					 staticresult = 0;
				} catch (IllegalStateException e) {
					Slog.i(TAG, "Static IPv6 configuration failed: " + e);
					staticresult = 0;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
                Slog.i(TAG, "Static IPv6 configuration failed: " + e);
				staticresult = 0;
			}
            if(staticresult == 1){
               final ContentResolver cr = mContext.getContentResolver();
               Settings.Secure.putString(cr, Settings.Secure.ETHV6_IP, ip);
               Settings.Secure.putString(cr, Settings.Secure.ETHV6_MODE,"manual");
               Settings.Secure.putInt(cr, Settings.Secure.ETHV6_MASK,prefixlength);
               Settings.Secure.putString(cr, Settings.Secure.ETHV6_DNS1, dns1);
               Settings.Secure.putString(cr, Settings.Secure.ETHV6_DNS2, dns2);
               Settings.Secure.putString(cr, Settings.Secure.ETHV6_ROUTE, gw);
               sendIpv6Broadcast(EthernetManager.IPV6_STATE_CHANGED_ACTION, EthernetManager.EVENT_STATIC6_CONNECT_SUCCESSED);
            }else{
               sendIpv6Broadcast(EthernetManager.IPV6_STATE_CHANGED_ACTION, EthernetManager.EVENT_STATIC6_CONNECT_FAILED);
            }
	}
	/**
	    * Get Ethernet IPV6 Static Ip Address From Database
	    * @return ipv6 static ip address
	    */
	public String getIpv6DatabaseAddress() {
           final ContentResolver cr = mContext.getContentResolver();
           String ipaddress = null;
           ipaddress =  Settings.Secure.getString(cr, Settings.Secure.ETHV6_IP);;
           Slog.w(TAG, "getIpv6DatabaseAddress:" + ipaddress);
           return ipaddress;
	}
	/**
	    * Get Ethernet IPV6 Static Ip Prefixlength From Database
	    * @return ipv6 static ip prefixlength
	    */
	public int getIpv6DatabasePrefixlength() {
           final ContentResolver cr = mContext.getContentResolver();
		   int prefix = 0;
           try {
               prefix = Settings.Secure.getInt(cr, Settings.Secure.ETHV6_MASK);
               Slog.w(TAG, "getIpv6DatabasePrefixlength:" + prefix);
           }catch (Settings.SettingNotFoundException e) {
               Slog.w(TAG, "getIpv6DatabasePrefixlength:" + prefix);
          }
          return prefix;
    }
	/**
	    * Get Ethernet IPV6 Static Ip Dns1 From Database
	    * @return ipv6 static ip dns1
	    */
	public String getIpv6DatabaseDns1() {
	       String dns1 = null;
           final ContentResolver cr = mContext.getContentResolver();
           dns1 = Settings.Secure.getString(cr, Settings.Secure.ETHV6_DNS1);
           Slog.w(TAG, "getIpv6DatabaseDns1:" + dns1);
           return dns1;
	}
	/**
	   * Get Ethernet IPV6 Static Ip Dns2 From Database
	   * @return ipv6 static ip dns2
	   */
	public String getIpv6DatabaseDns2() {
           final ContentResolver cr = mContext.getContentResolver();
           String dns2 = null;
           dns2 = Settings.Secure.getString(cr, Settings.Secure.ETHV6_DNS2);
           Slog.w(TAG, "getIpv6DatabaseDns2:" + dns2);
           return dns2;
	}
	/**
	   * Get Ethernet IPV6 Static Ip Gateway From Database
	   * @return ipv6 static ip gateway
	   */
	public String getIpv6DatabaseGateway() {
           final ContentResolver cr = mContext.getContentResolver();
           String gateway = null;
           gateway = Settings.Secure.getString(cr, Settings.Secure.ETHV6_ROUTE);
           Slog.w(TAG, "getIpv6DatabaseGateway:" + gateway);
           return gateway;
	}
	/**
	    * Get DHCPV6 Proccess Status
	    * @param ifname interface name
	    * @return
	    *  true for finished
	    *  false for unfinished
	    */
	public boolean checkDhcpv6Status(String ifname) {
             if(mEthState == EthernetManager.ETH_STATE_DISABLED || !isEthDeviceUp()){
                mIpv6ConnectStatus = false;			  
             }
             return mIpv6ConnectStatus;
	}
	/**
	   * Get DHCPV6 Ipaddress
	   * @param ifname interface name
	   * @return
	   *  dhcpv6 ipaddress, null for Error
	   */
	public String getDhcpv6Ipaddress(String ifname) {
        Slog.w(TAG, "getDhcpv6Ipaddres");
		String ip_address = null;
		if(getEthernetMode6() != null && getEthernetMode6().equals("dhcp")){
		   ip_address = SystemProperties.get("dibbler.eth0.ipaddress", "");
		}else{
		   ip_address = getIpv6DatabaseAddress();
		}
        return ip_address;	
	}
	/**
	    * Get DHCPV6 Gateway
	    * @param ifname interface name
	    * @return
	    *  dhcpv6 gateway address, null for Error
	    */
	public String getDhcpv6Gateway() {
        Slog.w(TAG, "getDhcpv6Gateway");
		String resultString = null;
		String check = null;
        if(getEthernetMode6() != null && getEthernetMode6().equals("manual")){
             return getIpv6DatabaseGateway();
        }
        check = "dev eth0";
            try {
                Process process = new ProcessBuilder()
                        .command("/system/bin/ip","-6","route","show")
                        .redirectErrorStream(true)
                        .start();
               try {
                    InputStream inputStream = process.getInputStream();
                    OutputStream puOutputStream = process.getOutputStream();
                    InputStreamReader inputReader = null;
                    BufferedReader reader = null;
                    inputReader = new InputStreamReader(inputStream);
                    reader = new BufferedReader(inputReader);
                    String tmp = null;
                    while((tmp = reader.readLine()) != null) {
                        if (tmp.contains(check)) {
                            String[] arr = tmp.split(" ");
                            for(int i=0;i<arr.length;i++) {
                               if (arr[i].contains(":")) {
                                   resultString = arr[i];
                                   Slog.d(TAG, resultString);
                                   return resultString;
                                }
                             }
                         }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    process.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(resultString == null)
                Slog.d(TAG, "ipv6 is not connected!!!");
            return resultString;
	}
	/**
	    * Get DHCPV6 Prefixlen
	    * @param ifname interface name
	    * @return
	    *  dhcpv6 prefixlen, null for Error
	    */
	public int getDhcpv6Prefixlen(String ifname) {
        Slog.w(TAG, "getDhcpv6Prefixlen");
		int resultLength=0;
		int prefixLength = 0;
		String resultString = null;
		String check = null;
		if(getEthernetMode6() != null && getEthernetMode6().equals("dhcp")){
		   check = "scope global dynamic";
		}else{
           return getIpv6DatabasePrefixlength();
		}
            try {
                Process process = new ProcessBuilder()
                        .command("/system/bin/ip","-6","addr","show")
                        .redirectErrorStream(true)
                        .start();
               try {
                    InputStream inputStream = process.getInputStream();
                    OutputStream puOutputStream = process.getOutputStream();
                    InputStreamReader inputReader = null;
                    BufferedReader reader = null;
                    inputReader = new InputStreamReader(inputStream);
                    reader = new BufferedReader(inputReader);

                    String tmp = null;
                    while((tmp = reader.readLine()) != null) {
                        if (tmp.contains(check)) {
                            resultString = tmp;
                            resultString = resultString.trim();
                            Slog.d(TAG, resultString);
                            int end = resultString.indexOf("s");
                            int start = resultString.indexOf("/");
                            resultString = resultString.substring(start+1, end);
                            Slog.d(TAG, "--------result:" + resultString);
                            resultString = resultString.trim();
                            try {
                                resultLength = Integer.valueOf(resultString).intValue();
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    process.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(resultString == null)
                Slog.d(TAG, "ipv6 is not connected!!!");
            prefixLength = resultLength;
            return prefixLength;
    }
	/**
	    * Get DHCPV6 DNS I
	    * @param ifname interface name
	    * @param number the number of dns
	    * @return
	    *  dhcpv6 dns i, null for Error
	    */
	public String getDhcpv6Dns(String ifname, int number) {
        Slog.w(TAG, "getDhcpv6Dns");
		String dns = null;
        if(getEthernetMode6() != null && getEthernetMode6().equals("dhcp")){
             dns = SystemProperties.get("dibbler.eth0.dns1","");
        }else{
             dns = getIpv6DatabaseDns1();
        }
        return dns;
	}
	/**
	   * Get The Number of DHCPV6 Dnses
	   * @param ifname interface name
	   * @return
	   *  the number of dhcpv6 dnses
	   */
	public int getDhcpv6DnsCnt(String ifname) {
           Slog.w(TAG, "getDhcpv6DnsCnt");
           return 1;
	}

	public boolean releaseDhcpLease(String ifname) {
        Slog.w(TAG, "releaseDhcpLease");
	    return NetworkUtils.releaseDhcpLease(ifname);
	}
}
