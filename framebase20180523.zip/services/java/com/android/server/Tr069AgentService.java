package com.android.server;

import android.net.tr069agent.ITr069AgentManager;
import android.net.tr069agent.Tr069AgentManager;
import android.net.tr069agent.AgentService;

import android.util.Slog;
import android.content.Context;

public class Tr069AgentService<syncronized> extends ITr069AgentManager.Stub{
    private Context mContext;
    private AgentService mAgent;
    private static final String TAG = "Tr069AgentService";

        public Tr069AgentService(Context context){
        mContext = context;
        mAgent = new AgentService(context);
        mAgent.startCwmp();
    }

    public String getUpdateURL() {
        return mAgent.getUpdateURL();
    }

    public String getPlatformURL() {
        return mAgent.getPlatformURL();
    }

    public String getPlatformURLBackup() {
        return mAgent.getPlatformURLBackup();
    }

    public String getAcsURL() {
        return mAgent.getAcsURL();
    }

    public String getAcsURLBackup() {
        return mAgent.getAcsURLBackup();
    }

    public String getHDCURL() {
        return mAgent.getHDCURL();
    }

	public void uploadUpdateResult(boolean value) {
        mAgent.uploadUpdateResult(value);
    }

	public String getCurrentSysVersion() {
        return mAgent.getCurrentSysVersion();
    }

    public String getNtpTimer(int index) {
        return mAgent.getNtpTimer(index);
    }
    
    public void setNtpTime(String time1, String time2) {
        mAgent.setNtpTime(time1, time2);
    }

    /*
         @call for manager
         @return allow usb install package name list;
     */
    public String[] getAllowInstallList() {
        return mAgent.getAllowInstallList();
    }

    public int getAllowInstallType() {
        return mAgent.getAllowInstallType();
    }
}


