/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.server;

import android.provider.Settings;
import android.content.ContentResolver;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import android.os.RecoverySystem;
import android.util.Log;
import android.util.Slog;
import java.io.IOException;
import android.net.ethernet.EthernetDevInfo;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;


public class MasterClearReceiver extends BroadcastReceiver {
    private static final String TAG = "MasterClear";

    @Override
    public void onReceive(final Context context, final Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_REMOTE_INTENT.equals(action)) {
            if (!"google.com".equals(intent.getStringExtra("from"))) {
                Slog.w(TAG, "Ignoring master clear request -- not from trusted server.");
                return;
            }
        }
        
        if("android.intent.action.MASTER_CLEAR".equals(action)) {
            Slog.w(TAG, "!!! FACTORY RESET !!!");

			if ("unicom".equals(SystemProperties.get("sys.proj.type"))
					&& "shandong".equals(SystemProperties.get("sys.proj.tender.type"))) {

				write_keep_net_state(context);
			}

			
			
            // The reboot call is blocking, so we need to do it on another thread.
            Thread thr = new Thread("Reboot") {
                @Override
                public void run() {
                    try {
                        boolean value = intent.getBooleanExtra("wipe_media", false);
                        RecoverySystem.isNeedWipeMedia = value;  
                        Slog.d(TAG, "setWipeMediaEnable:"+value);
						
						if(SystemProperties.getBoolean("sys.keepwipe", false))
						{
							Slog.d(TAG, "rebootWipeUserData_Iptv:");
							RecoverySystem.rebootWipeUserData_Iptv(context, "/data/yuemecert");
						}
						else
						{
							Slog.d(TAG, "setWipeMediaEnable:");
							RecoverySystem.rebootWipeUserData(context);
						}

						Log.wtf(TAG, "Still running after master clear?!");
                    } catch (IOException e) {
                        Slog.e(TAG, "Can't perform master clear/factory reset", e);
                    }
                }
            };
            thr.start();
        } else if("android.intent.action.WIPE_KEEP_DATA".equals(action)) {
            Slog.w(TAG, "!!! FACTORY RESET AND KEEP DATA FILE!!!");
            Thread thr = new Thread("WipeKeepData") {
                @Override
                public void run() {
                    String path = intent.getStringExtra("PATH");
                    Slog.d(TAG, "rebootWipeUserData_Iptv path:" + path);
                    RecoverySystem.rebootWipeUserData_Iptv(context, path);
                }
            };
            thr.start();
        } else if("android.intent.action.RESTORE_DATA".equals(action)) {
            Slog.w(TAG, "!!! RESTORE DATA FILE!!!");
            Thread thr = new Thread("RestoreData") {
                @Override
                public void run() {
                    String path = intent.getStringExtra("PATH");
                    Slog.d(TAG, "userDataRestore_Iptv path:" + path);
                    RecoverySystem.userDataRestore_Iptv(context, path);
                }
            };
            thr.start();
        }
    }

	private void file_backup(final String s_path) {
		//String old_path_ipoe = "/data/misc/etc/eth_auth.conf";
		//String old_path_pppoe = "/data/misc/etc/ppp/eth_padt_bin";
		//String old_path_pppoe = "/data/misc/etc/ppp/wlan_padt_bin";
	
		String old_path = s_path;
		String new_path = "/params/eth_auth.conf";
		
		File f_old = new File(old_path);
		if(f_old.exists()) {
			File f_new = new File(new_path);
			if(f_new.exists())
				f_new.delete();
			
			try {
				FileInputStream fis = new FileInputStream(f_old);
				FileOutputStream fos = new FileOutputStream(f_new);
				byte[] buf = new byte[1024];
				int byteread = 0;
				while((byteread = fis.read(buf)) != -1) {
					fos.write(buf, 0, byteread);
				}
				
				fis.close();
				fos.close();

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	private void write_keep_net_state(final Context context) {
		
		Slog.w(TAG, "write_keep_net_state()");
		
		String keep_path = "/params/keepnet";

		String ipoe_eth_auth_path = "/data/misc/etc/eth_auth.conf";
		String pppoe_eth_padt_path = "/data/misc/etc/ppp/eth_padt_bin";
		String pppoe_wlan_padt_path = "/data/misc/etc/ppp/wlan_padt_bin";
		
		File f_keep = new File(keep_path);
		
		if(f_keep.exists()){
			f_keep.delete();
			Slog.w(TAG, "deleted /params/keepnet ");
		}
		
		try {
			ContentResolver cr = context.getContentResolver();
			int eth_conf = Settings.Secure.getInt(cr, Settings.Secure.ETH_CONF, 1);
			String eth_mode = Settings.Secure.getString(cr, Settings.Secure.ETH_MODE);

			Slog.w(TAG, "get settings.secure : eth_conf = " + eth_conf + "; eth_mode = " + eth_mode); 

			StringBuffer strbuf = new StringBuffer();
			if(eth_mode.equals(EthernetDevInfo.ETH_CONN_MODE_MANUAL)) {
				String eth_ifname = Settings.Secure.getString(cr, Settings.Secure.ETH_IFNAME);
				String eth_ip = Settings.Secure.getString(cr, Settings.Secure.ETH_IP);
				String eth_mask = Settings.Secure.getString(cr, Settings.Secure.ETH_MASK);
				String eth_dns1 = Settings.Secure.getString(cr, Settings.Secure.ETH_DNS1);
				String eth_dns2 = Settings.Secure.getString(cr, Settings.Secure.ETH_DNS2);
				String eth_route = Settings.Secure.getString(cr, Settings.Secure.ETH_ROUTE);

				strbuf.append("eth_conf").append("=").append(eth_conf).append("\n");
				strbuf.append("eth_mode").append("=").append(eth_mode).append("\n");
				strbuf.append("eth_ifname").append("=").append(eth_ifname).append("\n");
				strbuf.append("eth_ip").append("=").append(eth_ip).append("\n");
				strbuf.append("eth_mask").append("=").append(eth_mask).append("\n");
				strbuf.append("eth_dns1").append("=").append(eth_dns1).append("\n");
				strbuf.append("eth_dns2").append("=").append(eth_dns2).append("\n");
				strbuf.append("eth_route").append("=").append(eth_route).append("\n");

			} else if(eth_mode.equals(EthernetDevInfo.ETH_CONN_MODE_PPPOE)) {
				String pppoe_usr = Settings.Secure.getString(cr, Settings.Secure.PPPOE_USR);
				String pppoe_pwd = Settings.Secure.getString(cr, Settings.Secure.PPPOE_PWD);
				String pppoe_itf = Settings.Secure.getString(cr, Settings.Secure.PPPOE_ITF);
				String pppoe_autod = Settings.Secure.getString(cr, Settings.Secure.PPPOE_AUTOD);

				strbuf.append("eth_conf").append("=").append(eth_conf).append("\n");
				strbuf.append("eth_mode").append("=").append(eth_mode).append("\n");
				strbuf.append("pppoe_usr").append("=").append(pppoe_usr).append("\n");
				strbuf.append("pppoe_pwd").append("=").append(pppoe_pwd).append("\n");
				strbuf.append("pppoe_itf").append("=").append(pppoe_itf).append("\n");
				strbuf.append("pppoe_autod").append("=").append(pppoe_autod).append("\n");

				file_backup(pppoe_eth_padt_path);
				file_backup(pppoe_wlan_padt_path);
				
			} else if(eth_mode.equals(EthernetDevInfo.ETH_CONN_MODE_DHCP_AUTH)) {

				strbuf.append("eth_conf").append("=").append(eth_conf).append("\n");
				strbuf.append("eth_mode").append("=").append(eth_mode).append("\n");
				file_backup(ipoe_eth_auth_path);
			}

			if(!eth_mode.equals(EthernetDevInfo.ETH_CONN_MODE_DHCP)) {
				
				f_keep.createNewFile();
				FileWriter fw = new FileWriter(keep_path);
				fw.write(strbuf.toString());
				fw.flush();
				fw.close();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
}
