/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.server;

import android.content.Context;
import android.app.IGpioManager;

import android.util.Log;

public class GpioManagerService extends IGpioManager.Stub {
    private static final String TAG = "GpioService";
    
    private final Context mContext;

    GpioManagerService(Context context) {
        mContext = context;
    }

    public void setGpioNum(int gpio_num) {
        mContext.enforceCallingOrSelfPermission(
                "android.permission.GPIO_RWONLY",
                "setGpioNum");

		Log.d("GpioManager", "setGpioNum gpio_num = " + gpio_num);
        setGpioNum_native(gpio_num);
    }

    public void setGpioDirectionCmd(int gpio_num, String gpio_cmd) {
        mContext.enforceCallingOrSelfPermission(
                "android.permission.GPIO_RWONLY",
                "setGpioDirectionCmd");

        Log.d("GpioManager", "setGpioDirectionCmd gpio_cmd = " + gpio_cmd);
        setGpioDirectionCmd_native(gpio_num, gpio_cmd);
    }

    public String getGpioDirection(int gpio_num) {
        mContext.enforceCallingOrSelfPermission(
                "android.permission.GPIO_RWONLY",
                "getGpioDirection");

        Log.d("GpioManager", "getGpioDirection gpio_num = " + gpio_num);
        return getGpioDirection_native(gpio_num);
    }

    public String getGpioValue(int gpio_num) {
        mContext.enforceCallingOrSelfPermission(
                "android.permission.GPIO_RWONLY",
                "getGpioDirection");

        Log.d("GpioManager", "getGpioValue gpio_num = " + gpio_num);
        return getGpioValue_native(gpio_num);
    }

    private static native void setGpioNum_native(int gpio_num);
    private static native void setGpioDirectionCmd_native(int gpio_num, String gpio_cmd);
    private static native String getGpioDirection_native(int gpio_num);
    private static native String getGpioValue_native(int gpio_num);
}
