package com.android.server;

import android.content.Context;
import android.os.SystemProperties;
import android.util.Slog;
import android.app.ISystemLogService;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;


import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.os.SystemProperties;
import java.io.FileInputStream;


class SystemLogService extends ISystemLogService.Stub {
 
    private static final String TAG = "SystemLogService";
    private static final boolean DEBUG = true;
    private final Context mContext;

	private static int DELAY = 2*1000;
    private static int DELAY_GETSIZE = 300*1000;
	private LogDumper mLogDumper = null;  
	private Handler mProgressHandler;
    
	public static final String LOGDIR = "/tmp/capture/";
    public static final String LOGPATH = "/tmp/capture/logcat.txt";
    public static boolean mIsRun = false;
    /**
    * @hide
    */
    public SystemLogService(Context context) {
        super();
        mContext = context;
        File file = new File(LOGPATH);
        file.delete();
    }
     
    /**
    * @hide
    */
    public void startRecord(){
        if(DEBUG)
            Slog.i(TAG, "startRecord:");
        mIsRun = true;
        
        mLogDumper = new LogDumper(String.valueOf(android.os.Process.myPid()));   
        mLogDumper.start(); 

        mProgressHandler = new DelayedHandler();
        if (mProgressHandler != null) {
            mProgressHandler.sendEmptyMessageDelayed(0, DELAY);
            mProgressHandler.sendEmptyMessageDelayed(1, DELAY_GETSIZE);}
    }

    /**
    * @hide
    */
    public void stopRecord(){
        if(DEBUG)
            Slog.i(TAG, "startRecord:");
        if(mLogDumper != null)
            mLogDumper.stopLogs();
    }
    
    private class LogDumper extends Thread {   
	    
        private Process logcatProc;   
        private BufferedReader mReader = null;   
        private boolean mRunning = true;   
        String cmds = null;   
        private String mPID;   
        private FileOutputStream out = null; 
        
        String dirPath = LOGDIR;
        //String filePath = dirPath+ "log" + System.currentTimeMillis() + ".txt";
        String filePath = LOGPATH;
       /* String cmd = "logcat -v time > "
                + filePath + "& ";*/
        String cmd = "logcat -v time \n";
    
        public LogDumper(String pid) {   
            mPID = pid;
            Log.e(TAG,"dirPath:"+dirPath);
            Log.e(TAG,"filePath:"+filePath);
            try{ 
            	File dirFile = new File(dirPath);
                File logFile = new File(filePath);
                try {
                    if(!dirFile.exists()){
                        dirFile.mkdirs();
                    }
                    logFile.createNewFile();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    Log.d(TAG," IOException ,mkdir");
                    e1.printStackTrace();
                }
                out = new FileOutputStream(logFile);   
            } catch(FileNotFoundException e) {   
                // TODO Auto-generated catch block    
                e.printStackTrace();   
            }   
        }   
    
        public void stopLogs() {   
            mRunning = false;   
        }   
    
        @Override  
        public void run() {   
            try{   
                logcatProc = Runtime.getRuntime().exec(cmd);   
                mReader = new BufferedReader(new InputStreamReader(   
                        logcatProc.getInputStream()), 1024);   
                String line = null;   
                while(mRunning && (line = mReader.readLine()) != null) {   
                    if(!mRunning) {   
                        break;   
                    }   
                    if(line.length() == 0) {   
                        continue;   
                    }   
                    if(out != null&& line.contains(mPID)) {   
                        out.write((System.currentTimeMillis() + "  "+ line + "\n")   
                                .getBytes());   
                    }   
                }   
    
            } catch(IOException e) {   
                e.printStackTrace();   
            } finally{   
                if(logcatProc != null) {   
                    logcatProc.destroy();   
                    logcatProc = null;   
                }   
                if(mReader != null) {   
                    try{   
                        mReader.close();   
                        mReader = null;   
                    } catch(IOException e) {   
                        e.printStackTrace();   
                    }   
                }   
                if(out != null) {   
                    try{   
                        out.close();   
                    } catch(IOException e) {   
                        e.printStackTrace();   
                    }   
                    out = null;   
                }   
            }   
        }   
    
    }    
	
    /*----------------------*/
    private class DelayedHandler extends Handler {
    @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    onDelayedProcess();
                    break;
                case 1:
                    onGetLogSizeProcess();
                    break;
            }
        }
    }
	private void onGetLogSizeProcess() {
		File logFile = new File(LOGPATH);
		try {
			if(getFileSizes(logFile) > 2097152){
                logFile.delete();

                mLogDumper.stopLogs();
                mLogDumper = new LogDumper(String.valueOf(android.os.Process.myPid()));   
                mLogDumper.start();
            }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        mProgressHandler.sendEmptyMessageDelayed(1, DELAY_GETSIZE);
    }
    private void onDelayedProcess() {
        if(SystemProperties.getBoolean("persist.sys.log.stop",false)){
            stopRecord();
            return;
            }
        mProgressHandler.sendEmptyMessageDelayed(0, DELAY);
    }	

   	public long getFileSizes(File f) throws Exception{
		    long s=0;
		    try{ 
		    if (f.exists()) {
		        FileInputStream fis = null;
		        fis = new FileInputStream(f);
		        s= fis.available();
                Log.d(TAG,"-----File not exist");
		        } else {
		        f.createNewFile();
		        }
		        return s;
		        }
		    catch(Exception e){
				return -1;
			}
        }
}
