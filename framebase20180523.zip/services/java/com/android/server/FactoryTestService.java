package com.android.server;

import android.app.FactoryTestManager;
import android.app.IFactoryTestService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.IPackageDeleteObserver;
import android.content.pm.IPackageInstallObserver;
import android.net.RouteInfo;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.NetworkUtils;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiConfiguration.AuthAlgorithm;
import android.net.wifi.WifiConfiguration.IpAssignment;
import android.net.wifi.WifiConfiguration.KeyMgmt;
import android.net.wifi.WifiInfo;
import android.net.wifi.ScanResult;
import android.os.Binder;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.net.InetAddress;

class FactoryTestService extends IFactoryTestService.Stub {
    private static final String TAG = "FactoryTestService";
    private static final boolean DEBUG = true;

    private static final String PROPDIR = ".factory-test";
    private static final String PROPNAME = "factory-test.properties";
    private static final String TAG_COMMAND = "Command";
    private static final String TAG_INSTALL_APPS_INFO = "InstallAppsInfo";
    private static final String TAG_WIFI_AP_INFO = "WifiApInfo";
    private static final String TAG_CALL_APP_INFO = "CallAppInfo";
    private static final String CTT_INSTALL_APP = "InstallApp";
    private static final String CTT_CONFIG_WIFI = "ConfigWifi";
    private static final String CTT_CALL_APP = "CallApp";
    
    private static final String APP_INSTALLED = "Installed";
    private static final String APP_UNINSTALL = "Uninstall";

    private static final String WIFI_DHCP = "dhcp";
    private static final String WIFI_STATIC = "static";
    private static final String SECURITY_NONE = "NONE";
    private static final String SECURITY_WEP = "WEP";
    private static final String SECURITY_PSK = "PSK";
    private static final String SECURITY_EAP = "EAP";

    private static final int MEDIA_MOUNTED = 1;
    private static final int MASTER_CLEAR = 2;
    private static final int DELAY_TIME = 1000;

    private final Context mContext;
    private PackageManager mPM;
    private WifiManager mWM;
    private WifiManager.ActionListener mConnectListener;
    private Handler mHandler;
    private String mRootPath = null;
    private ArrayList<String> mCommands = new ArrayList<String>();
    private ArrayList<String> mInstallAppTags = new ArrayList<String>();
    private ArrayList<AppSimpleInfo> mInstallApps = new ArrayList<AppSimpleInfo>();
    private AppSimpleInfo mCallAppInfo = null;
    private WifiSimpleInfo mWifiInfo = null;

    /**
     * @hide
     */
    public FactoryTestService(Context context) {
        super();

        mContext = context;
        mHandler = new FTHandler();
        mRootPath = null;
        mPM = mContext.getPackageManager();
        clear();

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_MEDIA_MOUNTED);
        filter.addAction(Intent.ACTION_MEDIA_EJECT);
        filter.addDataScheme("file");
        mContext.registerReceiver(mMountReceiver, filter);
        
        IntentFilter mfilter = new IntentFilter();
        mfilter.addAction(FactoryTestManager.ACTION_FACTORYTEST_MASTER_CLEAR);
        mfilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        mContext.registerReceiver(mMainReceiver, mfilter);
        if (DEBUG) Log.d(TAG, "Factory Test Service Init!");
    }

    private void clear() {
        mCommands.clear();
        mInstallAppTags.clear();
        mInstallApps.clear();
        mCallAppInfo = null;
        mWifiInfo = null;
    }

    private File getFile(String path) {
        if(DEBUG) Log.d(TAG, "getFile: " + path);
        try {
            File file = new File(path);
            if (file.exists()) {
                return file;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private Properties loadProperties(File file) {
        Properties properties = new Properties();

        try {
            FileInputStream input = new FileInputStream(file);
            properties.load(input);
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return properties;
    }
    
    private void parserProperties(Properties prop) {
        int i = 0;
        if (prop == null) {
            Log.w(TAG, "parserProperties prop is null!");
            return;
        }

        clear();

        String commands = prop.getProperty(TAG_COMMAND, null);
        if (commands != null) {
            String[] strs = commands.split("\\|");
            for (i=0; i<strs.length; i++) {
                mCommands.add(strs[i]);
                if (CTT_INSTALL_APP.equals(strs[i])) {
                    parserInstallAppsInfo(prop);
                    installApp();
                } else if (CTT_CALL_APP.equals(strs[i])) {
                    parserCallAppInfo(prop);
                    callApp();
                } else if (CTT_CONFIG_WIFI.equals(strs[i])) {
                    parserConfigWifi(prop);
                    configWifi();
                } else {
                    Log.w(TAG, strs[i] + " is not define!");
                }
            }
        }
        if (DEBUG) Log.d(TAG, "Parser properties end!");
    }
    
    private void parserInstallAppsInfo(Properties prop) {
        int i = 0;
        String tags = prop.getProperty(TAG_INSTALL_APPS_INFO, null);
        if (tags != null) {
            String[] strs = tags.split("\\|");
            for (i=0; i<strs.length; i++) {
                mInstallAppTags.add(strs[i]);
                String appinfo = prop.getProperty(strs[i], null);
                if (appinfo != null) {
                    String[] appstrs = appinfo.split("\\|");
                    if (appstrs.length == 3) {
                        AppSimpleInfo mAppInfo = new AppSimpleInfo();
                        mAppInfo.mPackageName = appstrs[0];
                        mAppInfo.mMainActivity = appstrs[1];
                        mAppInfo.mPath = new String(mRootPath + "/" + PROPDIR + appstrs[2]);
                        boolean installed = checkAppInstalled(mAppInfo.mPackageName);
                        mAppInfo.mState = installed ? APP_INSTALLED : APP_UNINSTALL;
                        mInstallApps.add(mAppInfo);
                    } else {
                        Log.w(TAG, "Install apps: " + appinfo + " is error!");
                    }
                }
            }
        }
    }

    private void parserCallAppInfo(Properties prop) {
        String appinfo = prop.getProperty(TAG_CALL_APP_INFO, null);
        if (appinfo != null) {
            String[] appstrs = appinfo.split("\\|");
            if (appstrs.length == 3) {
                mCallAppInfo = new AppSimpleInfo();
                mCallAppInfo.mPackageName = appstrs[0];
                mCallAppInfo.mMainActivity = appstrs[1];
                mCallAppInfo.mPath = new String(mRootPath + "/" + PROPDIR + appstrs[2]);
                boolean installed = checkAppInstalled(mCallAppInfo.mPackageName);
                mCallAppInfo.mState = installed ? APP_INSTALLED : APP_UNINSTALL;
            } else {
                Log.w(TAG, "Call app: " + appinfo + " is error!");
            }
        }
    }

    private void parserConfigWifi(Properties prop) {
        String apinfo = prop.getProperty(TAG_WIFI_AP_INFO, null);
        if (apinfo != null) {
            String[] apstrs = apinfo.split("\\|");
            if (apstrs.length == 2) {
                mWifiInfo = new WifiSimpleInfo();
                mWifiInfo.mSSID = apstrs[0];
                mWifiInfo.mPWD = apstrs[1];
                mWifiInfo.mMode = WIFI_DHCP;
            } else if (apstrs.length == 6) {
                mWifiInfo = new WifiSimpleInfo();
                mWifiInfo.mSSID = apstrs[0];
                mWifiInfo.mPWD = apstrs[1];
                mWifiInfo.mMode = WIFI_STATIC;
                mWifiInfo.mIP = apstrs[2];
                mWifiInfo.mMask = apstrs[3];
                mWifiInfo.mGW = apstrs[4];
                mWifiInfo.mDNS = apstrs[5];
            } else {
                Log.w(TAG, "Config wifi: " + apinfo + " is error!");
            }
        }
    }

    private void closeWifi() {
        if (mWM == null) {
            mWM = (WifiManager)mContext.getSystemService(Context.WIFI_SERVICE);
        }
        if (mWM != null) {
            if (mWM.isWifiEnabled()) {
                WifiInfo mConWifiInfo = mWM.getConnectionInfo();
                if (mConWifiInfo != null) {
                    String ssid = mConWifiInfo.getSSID();
                    int networkId = mConWifiInfo.getNetworkId();
                    Log.d(TAG, "getConnectionInfo ssid: " + ssid + " networkid: " + networkId);
                    mWM.forget(networkId, new WifiManager.ActionListener() {
                        @Override
                        public void onSuccess() {
                            Log.w(TAG, "Wifi ap forget successed!");
                        }

                        @Override
                        public void onFailure(int reason) {
                            Log.w(TAG, "Wifi ap forget failed, reason: " + reason);
                        }
                    });
                }
                mWM.setWifiEnabled(false);
            }
        }
    }

    private void deleteInstallApps(String packagename) {
        List<PackageInfo> packages = mPM.getInstalledPackages(0);
        ArrayList<String> installpkgs = new ArrayList<String>();
        boolean setlistLast = false;
        int i = 0;

        int count = (packages != null) ? packages.size(): 0;
        for(i=0; i<count; i++) {
            PackageInfo packageInfo = packages.get(i);
            if (packageInfo != null) {
                Log.d(TAG, "Installed package name: " + packageInfo.packageName);
                if((packageInfo.applicationInfo != null) && (packageInfo.packageName != null) &&
                        ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0)) {
                    if (!packageInfo.packageName.equals(packagename)) {
                        installpkgs.add(packageInfo.packageName);
                    } else {
                        setlistLast = true;
                    }
                }
            }
        }
        if (setlistLast) {
            installpkgs.add(packagename);
        }

        //delete installed apps
        ApkHandleTask apkHandler = new ApkHandleTask();
        count = installpkgs.size();
        for(i=0; i<count; i++) {
            String pkgName = installpkgs.get(i);
            if (pkgName != null) {
                apkHandler.uninstallAppImpl(pkgName);
            }
        }
    }

    private class ApkHandleTask {
        private class PackageInstallObserver extends IPackageInstallObserver.Stub {
            public void packageInstalled(String packageName, int returnCode) {
                synchronized(this) {
                    if (DEBUG) Log.d(TAG, "Install packageName: " + packageName + ", packageInstalled: " + returnCode);
                    if(returnCode == PackageManager.INSTALL_SUCCEEDED) {
                        Log.w(TAG, "Install packageName: " + packageName + " successed!");
                        int i = 0;
                        int len = mInstallApps.size();
                        if (mCallAppInfo != null) {
                            if ((packageName != null) && packageName.equals(mCallAppInfo.mPackageName)) {
                                mCallAppInfo.mState = APP_INSTALLED;
                                callAppImpl(mCallAppInfo.mPackageName, mCallAppInfo.mMainActivity);
                            }
                        }
                        for (i=0; i<len; i++) {
                            AppSimpleInfo appinfo = mInstallApps.get(i);
                            if ((packageName != null) && packageName.equals(appinfo.mPackageName)) {
                                appinfo.mState = APP_INSTALLED;
                                return;
                            }
                        }
                    } else {
                        Log.w(TAG, "Install packageName: " + packageName + " failed!");
                    }
                }
            }
        }

        private class PackageDeleteObserver extends IPackageDeleteObserver.Stub {
            public void packageDeleted(String packageName, int returnCode) {
                synchronized (this) {
                    if (DEBUG) Log.d(TAG, "Delete packageName: " + packageName + ", packageInstalled: " + returnCode);
                    if(returnCode == PackageManager.DELETE_SUCCEEDED) {
                        Log.w(TAG, "Delete packageName: " + packageName + " successed!");
                    }
                }
            }
        }

        public void installAppImpl(String app_path) {
            if (app_path == null) {
                Log.w(TAG, "installAppImpl: app_path is null!");
                return;
            }
            File mFile = getFile(app_path);
            if (mFile == null) {
                Log.w(TAG, "installAppImpl: File: " + app_path + " is not exists!");
                return;
            }
            PackageInstallObserver observer = new PackageInstallObserver();
            mPM.installPackage(Uri.fromFile(mFile), observer, 0, null);
        }

        public void uninstallAppImpl(String packagename) {
            if (packagename == null) {
                Log.w(TAG, "uninstallAppImpl: packagename is null!");
                return;
            }
            Log.d(TAG, "delete " + packagename);
            PackageDeleteObserver observer = new PackageDeleteObserver();
            mPM.deletePackage(packagename, observer, 0);
        }
    }

    private boolean checkAppInstalled(String packageName) {
        if(DEBUG) Log.d(TAG, "checkAppInstalled: " + packageName);
        try {
            PackageInfo info = mPM.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS);
            if(info != null) {
                return true;
            }
        } catch (Exception e) {				
            e.printStackTrace();
        }
        return false;
    }
    
    private void installApp() {
        ApkHandleTask apkHandler = new ApkHandleTask();
        int i = 0;
        int len = mInstallApps.size();
        for (i=0; i<len; i++) {
            AppSimpleInfo appinfo = mInstallApps.get(i);
            if (APP_UNINSTALL.equals(appinfo.mState)) {
                apkHandler.installAppImpl(appinfo.mPath);
            }
        }
    }

    private void callApp() {
        if (mCallAppInfo != null) {
            if (APP_UNINSTALL.equals(mCallAppInfo.mState)) {
                ApkHandleTask apkHandler = new ApkHandleTask();
                apkHandler.installAppImpl(mCallAppInfo.mPath);
            } else {
                callAppImpl(mCallAppInfo.mPackageName, mCallAppInfo.mMainActivity);
            }
        }
    }

    private String getSecurity(ScanResult result) {
        if ((result == null) || (result.capabilities == null)) {
            Log.w(TAG, "getSecurity result or result.capabilities is null!");
            return SECURITY_NONE;
        }
        if (result.capabilities.contains("WEP")) {
            return SECURITY_WEP;
        } else if (result.capabilities.contains("PSK")) {
            return SECURITY_PSK;
        } else if (result.capabilities.contains("EAP")) {
            return SECURITY_EAP;
        }
        return SECURITY_NONE;
    }

    private String convertToQuotedString(String string) {
        return "\"" + string + "\"";
    }

    private StringBuffer toBin(int x) {
        StringBuffer result = new StringBuffer();
        result.append(x%2);
        x/=2;
        while(x > 0){
            result.append(x%2);
            x/=2;
        }
        return result;
    }

    private int getNetMask(String netmarks) {
        StringBuffer sbf;
        String str;
        int inetmask = 0, len1 = 0, len2 = 0;
        String[] ipList = netmarks.split("\\.");
        len1 = ipList.length;
        for(int n = 0; n < len1; n++) {
            sbf = toBin(Integer.parseInt(ipList[n]));
            str = sbf.reverse().toString();
            len2 = str.length();
            for(int i=0; i<len2; i++) {
                char ch = str.charAt(i);
                if (ch != '1') return inetmask;
                inetmask++;
            }
        }
        return inetmask;
    }

    private void validateIpConfigFields(LinkProperties linkProperties) {
        if (mWifiInfo == null) {
            Log.w(TAG, "validateIpConfigFields mWifiInfo is null!");
            return;
        }
        if (TextUtils.isEmpty(mWifiInfo.mIP)) {
            Log.w(TAG, "IP: " + mWifiInfo.mIP + " is invalid!");
            return;
        }

        InetAddress inetAddr = null;
        try {
            inetAddr = NetworkUtils.numericToInetAddress(mWifiInfo.mIP);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return;
        }

        int networkPrefixLength = -1;
        try {
            networkPrefixLength = getNetMask(mWifiInfo.mMask);
            if (networkPrefixLength < 0 || networkPrefixLength > 32) {
                Log.w(TAG, "Mask: " + mWifiInfo.mMask + " is invalid!");
                return;
            }

            linkProperties.addLinkAddress(new LinkAddress(inetAddr, networkPrefixLength));
            linkProperties.addRoute(new RouteInfo(new LinkAddress(inetAddr, networkPrefixLength)));
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return;
        }

        if (TextUtils.isEmpty(mWifiInfo.mGW)) {
            Log.w(TAG, "GW: " + mWifiInfo.mGW + " is invalid!");
            return;
        }

        InetAddress gatewayAddr = null;
        try {
            gatewayAddr = NetworkUtils.numericToInetAddress(mWifiInfo.mGW);
            linkProperties.addRoute(new RouteInfo(gatewayAddr));
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return;
        }

        InetAddress dnsAddr = null;
        if (TextUtils.isEmpty(mWifiInfo.mDNS)) {
            Log.w(TAG, "Dns: " + mWifiInfo.mDNS + " is invalid!");
            return;
        }
        try {
            dnsAddr = NetworkUtils.numericToInetAddress(mWifiInfo.mDNS);
            linkProperties.addDns(dnsAddr);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return;
        }
    }

    private void scanAP() {
        List<WifiConfiguration> configs = (mWM != null) ? mWM.getConfiguredNetworks() : null;
        if ((mWifiInfo != null) && (configs != null)) {
            for (WifiConfiguration config : configs) {
                if (DEBUG) Log.d(TAG, config.SSID + "/" + mWifiInfo.mSSID);
                if ((config.SSID != null) && (mWifiInfo.mSSID != null)
                        && config.SSID.equals(convertToQuotedString(mWifiInfo.mSSID))) {
                    Log.w(TAG, config.SSID + " is config!");
                    return;
                }
            }
        }

        List<ScanResult> results = (mWM != null) ? mWM.getScanResults() : null;
        if ((mWifiInfo != null) && (results != null)) {
            for (ScanResult result : results) {
                if (result.SSID == null || result.SSID.length() == 0 ||
                        result.capabilities.contains("[IBSS]")) {
                    continue;
                }
                if (DEBUG) Log.d(TAG, "scanAP ssid: " + result.SSID + ", bssid: " + result.BSSID);
                if (result.SSID.equals(mWifiInfo.mSSID)) {
                    mWifiInfo.mSecurity = getSecurity(result);
                    configImpl();
                    return;
                }
            }
            Log.w(TAG, "scanAP not find ssid: " + mWifiInfo.mSSID);
        }
    }

    private void configImpl() {
        if ((mWifiInfo == null) || (mWifiInfo.mSSID == null) || (mWifiInfo.mPWD == null)) {
            Log.w(TAG, "configImpl mWifiInfo, mWifiInfo.mSSID or mWifiInfo.mPWD is null!");
            return;
        }
        WifiConfiguration config = new WifiConfiguration();
        LinkProperties mLinkProperties = new LinkProperties();

        config.SSID = convertToQuotedString(mWifiInfo.mSSID);
        if (SECURITY_NONE.equals(mWifiInfo.mSecurity)) {
            config.allowedKeyManagement.set(KeyMgmt.NONE);
        } else if (SECURITY_WEP.equals(mWifiInfo.mSecurity)) {
            config.allowedKeyManagement.set(KeyMgmt.NONE);
            config.allowedAuthAlgorithms.set(AuthAlgorithm.OPEN);
            config.allowedAuthAlgorithms.set(AuthAlgorithm.SHARED);
            int length = mWifiInfo.mPWD.length();
            if ((length == 10 || length == 26 || length == 58) &&
                    mWifiInfo.mPWD.matches("[0-9A-Fa-f]*")) {
                config.wepKeys[0] = mWifiInfo.mPWD;
            } else {
                config.wepKeys[0] = '"' + mWifiInfo.mPWD + '"';
            }
            if (DEBUG) Log.d(TAG, "WEP password: " + config.wepKeys[0]);
        } else if (SECURITY_PSK.equals(mWifiInfo.mSecurity)) {
            config.allowedKeyManagement.set(KeyMgmt.WPA_PSK);
            if (mWifiInfo.mPWD.matches("[0-9A-Fa-f]{64}")) {
                config.preSharedKey = mWifiInfo.mPWD;
            } else {
                config.preSharedKey = '"' + mWifiInfo.mPWD + '"';
            }
            if (DEBUG) Log.d(TAG, "PSK password: " + config.preSharedKey);
        } else {
            config.allowedKeyManagement.set(KeyMgmt.NONE);
            Log.w(TAG, "Security mode: " + mWifiInfo.mSecurity + " is not support!");
        }

        if (WIFI_DHCP.equals(mWifiInfo.mMode)) {
            config.ipAssignment = IpAssignment.DHCP;
        } else if (WIFI_STATIC.equals(mWifiInfo.mMode)) {
            config.ipAssignment = IpAssignment.STATIC;
            validateIpConfigFields(mLinkProperties);
        } else {
            config.ipAssignment = IpAssignment.DHCP;
            Log.w(TAG, "configImpl mode: " + mWifiInfo.mMode + " is not support!");
        }
        config.linkProperties = new LinkProperties(mLinkProperties);

        mWM.connect(config, mConnectListener);
    }

    private void configWifi() {
        if (mWM == null) {
            mWM = (WifiManager)mContext.getSystemService(Context.WIFI_SERVICE);
        }
        if (mConnectListener == null) {
            mConnectListener = new WifiManager.ActionListener() {
                @Override
                public void onSuccess() {
                    Log.w(TAG, "Wifi ap connect successed!");
                }

                @Override
                public void onFailure(int reason) {
                    Log.w(TAG, "Wifi ap connect failed, reason: " + reason);
                }
            };
        }
        if (mWifiInfo != null) {
            if (!mWM.isWifiEnabled()) {
                mWM.setWifiEnabled(true);
            } else {
                WifiInfo mConWifiInfo = mWM.getConnectionInfo();
                if (DEBUG && (mConWifiInfo != null)) Log.d(TAG, "getConnectionInfo ssid: " + mConWifiInfo.getSSID());
                if ((mWifiInfo.mSSID != null) && (mConWifiInfo != null) && (mConWifiInfo.getSSID() != null)
                        && mConWifiInfo.getSSID().equals(convertToQuotedString(mWifiInfo.mSSID))) {
                    Log.w(TAG, mWifiInfo.mSSID + " is connected!");
                } else {
                    scanAP();
                }
            }
        }
    }

    private void callAppImpl(String packageName, String activityname) {
        if (DEBUG) Log.d(TAG, "callAppImpl " + packageName + "/" + activityname);
        try {
            Intent mintent = new Intent();
            ComponentName componentName = new ComponentName(packageName, activityname);
            mintent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            mintent.setComponent(componentName); 
            mContext.startActivity(mintent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class FTHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MEDIA_MOUNTED:
                    String path = (String)msg.obj;
                    File propFile = getFile(path + "/" + PROPDIR + "/" + PROPNAME);
                    if (propFile != null) {
                        mRootPath = path;
                        Properties mProp = loadProperties(propFile);
                        try {
                            parserProperties(mProp);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case MASTER_CLEAR:
                    String pkgName = (String)msg.obj;
                    closeWifi();
                    deleteInstallApps(pkgName);
                    break;
            }
        }
    }

    private BroadcastReceiver mMainReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (DEBUG) Log.d(TAG, "action: " + action);

            if (action == null)
                return;

            if (action.equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
                WifiInfo mConWifiInfo = (mWM != null) ? mWM.getConnectionInfo() : null;
                if (DEBUG && (mConWifiInfo != null)) Log.d(TAG, "getConnectionInfo ssid: " + mConWifiInfo.getSSID());
                if ((mWifiInfo != null) && (mWifiInfo.mSSID != null)
                        && (mConWifiInfo != null) && (mConWifiInfo.getSSID() != null)
                        && mConWifiInfo.getSSID().equals(convertToQuotedString(mWifiInfo.mSSID))) {
                    Log.w(TAG, mWifiInfo.mSSID + " is connected!");
                } else {
                    scanAP();
                }
            } else if (action.equals(FactoryTestManager.ACTION_FACTORYTEST_MASTER_CLEAR)) {
                String pkgName = intent.getStringExtra("PackageName");
                Log.d(TAG, "send broadcast package is " + pkgName);
                mHandler.removeMessages(MASTER_CLEAR);
                Message msg = Message.obtain();
                msg.what = MASTER_CLEAR;
                msg.obj = pkgName;
                mHandler.sendMessageDelayed(msg, DELAY_TIME);
            }
        }
    };

    private BroadcastReceiver mMountReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            Uri uri = intent.getData();
            String path = (uri != null) ? uri.getPath() : null;
            if (DEBUG) Log.d(TAG, "action: " + action + ", path: " + path);

            if ((action == null) || (path == null))
                return;
            if (action.equals(Intent.ACTION_MEDIA_EJECT)) {
                if (path.equals(mRootPath)) {
                    if (DEBUG) Log.d(TAG, mRootPath + " is remounted!");
                    clear();
                    mHandler.removeMessages(MEDIA_MOUNTED);
                    mRootPath = null;
                }
            } else if (action.equals(Intent.ACTION_MEDIA_MOUNTED)) {
                if (mRootPath != null) {
                    Log.w(TAG, path + " is mount, but " + mRootPath + " has factory-test.properties");
                    return;
                }
                Message msg = Message.obtain();
                msg.what = MEDIA_MOUNTED;
                msg.obj = path;
                mHandler.sendMessageDelayed(msg, DELAY_TIME);
            }
        }
    };

    @Override
    protected void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        if (mContext.checkCallingOrSelfPermission(android.Manifest.permission.DUMP)
                != PackageManager.PERMISSION_GRANTED) {
            pw.println("Permission Denial: can't dump factory_test from from pid="
                    + Binder.getCallingPid()
                    + ", uid=" + Binder.getCallingUid());
            return;
        }

        pw.println("Factory Test (dumpsys factory_test)\n");
        int i = 0;
        int cmdlen = mCommands.size();
        int apptaglen = mInstallAppTags.size();
        int applen = mInstallApps.size();
        
        pw.println("RootPath: " + mRootPath);
        for (i=0; i<cmdlen; i++) {
            pw.println("Command: " + mCommands.get(i));
        }
        if (cmdlen > 0)
            pw.println("\n");

        for (i=0; i<apptaglen; i++) {
            pw.println("Tag: " + mInstallAppTags.get(i));
        }
        if (apptaglen > 0)
            pw.println("\n");

        for (i=0; i<applen; i++) {
            AppSimpleInfo appinfo = mInstallApps.get(i);
            pw.println("Install App pkg:      " + appinfo.mPackageName);
            pw.println("        App activity: " + appinfo.mMainActivity );
            pw.println("        App path:     " + appinfo.mPath);
            pw.println("        App state:    " + appinfo.mState + "\n");
        }
            
        if (mCallAppInfo != null) {
            pw.println("Call App pkg:      " + mCallAppInfo.mPackageName);
            pw.println("     App activity: " + mCallAppInfo.mMainActivity);
            pw.println("     App path:     " + mCallAppInfo.mPath);
            pw.println("     App state:    " + mCallAppInfo.mState + "\n");
        }

        if (mWifiInfo != null) {
            pw.println("Wifi ssid:      " + mWifiInfo.mSSID);
            pw.println("     pwd:       " + mWifiInfo.mPWD);
            pw.println("     mode:      " + mWifiInfo.mMode);
            pw.println("     mSecurity: " + mWifiInfo.mSecurity);
            pw.println("     ip:        " + mWifiInfo.mIP);
            pw.println("     mask:      " + mWifiInfo.mMask);
            pw.println("     gw:        " + mWifiInfo.mGW);
            pw.println("     dns:       " + mWifiInfo.mDNS + "\n");
        }
    }

    private class AppSimpleInfo {
        public String mPackageName = null;
        public String mMainActivity = null;
        public String mPath = null;
        public String mState = APP_UNINSTALL;
    }
    
    private class WifiSimpleInfo {
        public String mSSID = null;
        public String mPWD = null;
        public String mMode = WIFI_DHCP;
        public String mSecurity = "NONE";
        public String mIP = null;
        public String mMask = null;
        public String mGW = null;
        public String mDNS = null;
    }
}
