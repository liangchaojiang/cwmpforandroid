package com.android.server;
import java.io.File; 
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.InputStream;  
import java.util.Properties; 
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import android.os.SystemProperties;
import android.os.FileUtils;
import android.util.Log;
import android.util.Slog;
import java.io.IOException;

import android.app.IDevInfoManager;
import android.content.Context;



public class DevInfoManagerService extends IDevInfoManager.Stub {
    private static final String LOG_TAG = "DevInfoManagerService";
    private final Context mContext;
	public Properties properties = null;
	private String mKeyParaPath = "params/keypara.ini";
	private String mKeyParaSrcPath = "/system/etc/keypara.ini";
	native void syncfile();

    public DevInfoManagerService(Context Context){
        mContext = Context;
        File keyParaFile = new File(mKeyParaPath);
        if(!keyParaFile.exists() || keyParaFile.length() == 0L){
            Log.d(LOG_TAG,"file "+mKeyParaPath+" not exists");
            try {
                keyParaFile.createNewFile();
                Log.d(LOG_TAG,"file "+mKeyParaPath+" to creat");
            } catch (IOException e) { 
                e.printStackTrace(); 
            }
            //iniReaderNoSection(mKeyParaSrcPath);
            File sourceFile = new File(mKeyParaSrcPath);
            File destFile = new File(mKeyParaPath);
	     FileUtils.copyFile(sourceFile , destFile);
            //iniSaveConfig(mKeyParaPath);
        }
	 /*
        if(properties==null)
            iniReaderNoSection(mKeyParaPath);
       */
    }
	public void writeToFile(String _sDestFile, String _sContent , String key)
	throws IOException {
		BufferedWriter fw = null;
		BufferedReader reader = null;
		List<String> lists = new ArrayList<String>();
		String line = null;
		boolean haskey = false;
		try {
			//fw = new FileWriter(_sDestFile);
			reader = new BufferedReader(new FileReader(new File(_sDestFile)));
			while ((line = reader.readLine()) != null) {
				lists.add(line);
			}
			reader.close();
			fw =new BufferedWriter(new FileWriter(new File(_sDestFile)));
			for(String strr : lists){
					String[] keyValueAray = null;
          keyValueAray = strr.split("=");
          if(null != keyValueAray && keyValueAray.length > 0 && keyValueAray[0].equals(key)){
					Log.d(LOG_TAG , "read key and value is : "+strr);
					strr = strr.replaceAll(strr, _sContent);
					haskey = true;
				}
				fw.write(strr+"\n");
			}
			if(!haskey)
				fw.write(_sContent+"\n");
			fw.flush();
			fw.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fw != null) {
				
				fw.close();
				fw = null;
			}
		}
	}
	
	public String readFromFile(String fileName , String key) {
			File file = new File(fileName);
			BufferedReader reader = null;
			String value = null;
			String[] keyValueAray = null;
			try {
				reader = new BufferedReader(new FileReader(file));
				String tempString = null;
				while ((tempString = reader.readLine()) != null) {
					keyValueAray = tempString.split("=");
					for(int i = 0;i < keyValueAray.length ; i++){
						if(keyValueAray[i].equals(key) && keyValueAray.length > 1){
							Log.d(LOG_TAG , "=="+keyValueAray[i]+"==");
							value = keyValueAray[1];
							break;
						}
					}
					if(null != value)
						break;
				}
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e1) {
					}
				}
			}
			return value;
    }

    public int iniReaderNoSection(String filename) {  
        File file = new File(filename);  
        FileInputStream fin = null;
        try {  
            properties = new Properties();
            fin = new FileInputStream(file);
            properties.load(fin);
            fin.close();  
        } catch (Exception ex) {  
            ex.printStackTrace();  
        }  
        return 0;
    }

    public void iniSaveConfig(String file) {  
        try {  
            FileOutputStream s = new FileOutputStream(file, false);  
            //properties.store(s, "");
	        FileUtils.sync(s); 
            s.close();
        } catch (Exception e){  
            e.printStackTrace();  
        }
    }
	
    public String getIniKey(String key) {  
        /*if (properties.containsKey(key) == false) { 
			Log.d(LOG_TAG,"get ini key : "+key+" not catains");
            return null;  
        }  

		Log.d(LOG_TAG,"get ini key  : "+key+" return value : "+String.valueOf(properties.get(key)));
        return String.valueOf(properties.get(key));*/
        String value = readFromFile(mKeyParaPath , key);
        Log.d(LOG_TAG , "get value is : "+value);
        syncfile();
        return value;
    }
  
    public int setIniKey(String key,String value){
        //if(properties.containsKey(key) == false)
        //    return -1;
        //Log.d(LOG_TAG,"set ini key : "+key+" value is "+value);
        StringBuilder newKeyVal = new StringBuilder();
        newKeyVal.append(key);
	 newKeyVal.append("=");
	 if(value == null || value=="")
	 	return -1;
	 else
	 	newKeyVal.append(value);
	 Log.d(LOG_TAG,"set ini key and value : "+newKeyVal.toString());
        //properties.put(key,value);
        try {
        	writeToFile(mKeyParaPath , newKeyVal.toString() , key);
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
        //iniSaveConfig(mKeyParaPath);
        syncfile();
        return 0;
    }
 
    public String getValue(String name) {
        Log.d(LOG_TAG,"xxxxxxxxx get value name :"+name);
		if (name == null){
            return "";
        }
		/*
		if(properties==null)
            iniReaderNoSection(mKeyParaPath);
            */
        if(0 == "MobilePhoneNumber".compareTo(name))
        {
            return getIniKey("MobilePhoneNumber");
        }
        else if(0 == "ServicePassword".compareTo(name))
        {
            return getIniKey("ServicePassword");
        }
        else if(0 == "Account".compareTo(name))
        {
            return getIniKey("Account");
        }
        else if(0 == "AccountPassword".compareTo(name))
        {
            return getIniKey("AccountPassword");
        }
        else if(0 == "STBMAC".compareTo(name))
        {
            return SystemProperties.get("ro.mac");
        }
        else if(0 == "STBSN".compareTo(name))
        {
            return SystemProperties.get("ro.serialno");
        }
        else if(0 == "PlatformURL".compareTo(name))
        {
            return getIniKey("PlatformURL");           
        }
        else if(0 == "PlatformURLBackup".compareTo(name))
        {
            return getIniKey("PlatformURLBackup");
        }
        else if(0 == "CMSURL".compareTo(name))
        {
            return getIniKey("CMSURL");
        }
        else if(0 == "CMSURLBackup".compareTo(name))
        {
            return getIniKey("CMSURLBackup");
        }
        else if(0 == "HDCRURL".compareTo(name))
        {
            return getIniKey("HDCRURL");
        }
        else if(0 == "EPGAddress".compareTo(name))
        {
            return getIniKey("EPGAddress");
        }
        else if(0 == "CDNAddress".compareTo(name))
        {
            return getIniKey("CDNAddress");
        }
        else if(0 == "BackupCDNAddress".compareTo(name))
        {
            return getIniKey("BackupCDNAddress");
        }
        else if(0 == "TVID".compareTo(name))
        {
            return getIniKey("TVID");
        }
        else if(0 == "ModelName".compareTo(name))
        {
            return SystemProperties.get("ro.model");
        }
        else if(0 == "FirmwareVersion".compareTo(name))
        {
            return SystemProperties.get("ro.version");
        }

        return null;
    }

    public int update(String name,String value, int attribute) {
		
        if(name==null || value==null){                                                                                                                            
            return -1;                                                                                                                                
        }
		/*
		if(properties==null){
			iniReaderNoSection(mKeyParaPath);
		}
		*/
        if(0 == "MobilePhoneNumber".compareTo(name))                                                                                                  
        {
             setIniKey("MobilePhoneNumber",value);                                                                                                                                            
        }                                                                                                                                             
        else if(0 == "ServicePassword".compareTo(name))                                                                                               
        { 
        
		setIniKey("ServicePassword",value);																																			 
        }                                                                                                                                             
        else if(0 == "Account".compareTo(name))                                                                                                       
        {  
        
		setIniKey("Account",value);																																			 
        }                                                                                                                                             
        else if(0 == "AccountPassword".compareTo(name))                                                                                               
        {     
        
		setIniKey("AccountPassword",value);																																			 
        }                                                                                                                                             
        else if(0 == "STBMAC".compareTo(name))                                                                                                        
        {  
        
		setIniKey("STBMAC",value);																																			 
        }                                                                                                                                             
        else if(0 == "STBSN".compareTo(name))                                                                                                         
        {    
        
		setIniKey("STBSN",value);																																			 
        }                                                                                                                                             
        else if(0 == "PlatformURL".compareTo(name))                                                                                                   
        {   
        
		setIniKey("PlatformURL",value);																																			 
        }                                                                                                                                             
        else if(0 == "PlatformURLBackup".compareTo(name))                                                                                             
        {  
        
		setIniKey("PlatformURLBackup",value);																																			 
        }                                                                                                                                             
        else if(0 == "CMSURL".compareTo(name))                                                                                                        
        {   
        
		setIniKey("CMSURL",value);																																			 
        }                                                                                                                                             
        else if(0 == "CMSURLBackup".compareTo(name))                                                                                                  
        {  
        
		setIniKey("CMSURLBackup",value);																																			 
        }                                                                                                                                             
        else if(0 == "HDCRURL".compareTo(name))                                                                                                       
        { 
        
		setIniKey("HDCRURL",value);																																			 
        }                                                                                                                                             
        else if(0 == "EPGAddress".compareTo(name))                                                                                                    
        {   
        
		setIniKey("EPGAddress",value);																																			 
        }                                                                                                                                             
        else if(0 == "CDNAddress".compareTo(name))                                                                                                    
        {          
        
		setIniKey("CDNAddress",value);																																			 
        }                                                                                                                                             
        else if(0 == "BackupCDNAddress".compareTo(name))                                                                                              
        {  
        
		setIniKey("BackupCDNAddress",value);																																			 
        }                                                                                                                                             
        else if(0 == "TVID".compareTo(name))                                                                                                          
        {         
        
		setIniKey("TVID",value);																																			 
        }                                                                                                                                             
        else if(0 == "ModelName".compareTo(name))                                                                                                     
        {   
        
		setIniKey("ModelName",value);																																			 
        }                                                                                                                                             
        else if(0 == "FirmwareVersion".compareTo(name))                                                                                               
        {      
        
		setIniKey("FirmwareVersion",value);																																			 
        }
        //iniSaveConfig(mKeyParaPath);                                                                                                                                             
        return 0;
    }
}

