package com.android.server;

import android.content.Context;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.app.IOverlayView;
import android.view.Surface;

public class OverlayViewService extends IOverlayView.Stub
{
    private static final String mTag = "OverlayViewService";
    private Context mContext = null;

    public OverlayViewService(Context context)
    {
        mContext = context;
    }

    private boolean getOverlayViewEnable() {
        boolean ret = false;
        ret = SystemProperties.getBoolean("ro.app.overlayviewE",false);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public void init(int source, int sourceType, boolean isFullscreen, boolean isRecording) throws RemoteException {
        // TODO Auto-generated method stub

        if(true == getOverlayViewEnable())
            _init(source, sourceType, isFullscreen, isRecording);
    }

    /**
     * @hide
     */
    @Override
    public void deinit(boolean isRecording) throws RemoteException {

        if(true == getOverlayViewEnable())
            _deinit(isRecording);
    }

    /**
     * @hide
     */
    @Override
    public int displayHdmi() throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _displayHdmi();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int displayAndroid() throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _displayAndroid();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int displayPip(int x, int y, int width, int height) throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _displayPip(x, y, width, height);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int getHActive() throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _getHActive();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int getVActive() throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _getVActive();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public String getInputSize() throws RemoteException {
        String ret = "";
        if (true == getOverlayViewEnable())
            ret = _getInputSize();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean isDvi() throws RemoteException {
        // TODO Auto-generated method stub
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _isDvi();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean isPowerOn() throws RemoteException {
        // TODO Auto-generated method stub
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _isPowerOn();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean isEnable() throws RemoteException {
        // TODO Auto-generated method stub
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _isEnable();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean isInterlace() throws RemoteException {
        // TODO Auto-generated method stub
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _isInterlace();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean hdmiPlugged() throws RemoteException {
        // TODO Auto-generated method stub
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _hdmiPlugged();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean hdmiSignal() throws RemoteException {
        // TODO Auto-generated method stub
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _hdmiSignal();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int enableAudio(int flag) throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _enableAudio(flag);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public void startMonitorUsbHostBusThread() throws RemoteException {
        // TODO Auto-generated method stub
        if(true == getOverlayViewEnable())
            _startMonitorUsbHostBusThread();
    }

    /**
     * @hide
     */
    @Override
    public int handleAudio() throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _handleAudio();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int setAmaudioMusicGain(int gain) throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _setAmaudioMusicGain(gain);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int setAmaudioLeftGain(int gain) throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _setAmaudioLeftGain(gain);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int setAmaudioRightGain(int gain) throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _setAmaudioRightGain(gain);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public void setAudioOutputRecord(boolean start) throws RemoteException {
        // TODO Auto-generated method stub
        if(true == getOverlayViewEnable())
            _setAudioOutputRecord(start);
    }

    /**
     * @hide
     */
    @Override
    public void setStart(boolean start) throws RemoteException {
        // TODO Auto-generated method stub
        if(true == getOverlayViewEnable())
            _setStart(start);
    }

    /**
     * @hide
     */
    @Override
    public int setSourceType() throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _setSourceType();
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean isSurfaceAvailable(Surface surface) {
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _isSurfaceAvailable(surface);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public boolean setPreviewWindow(Surface surface) {
        boolean ret = false;
        if(true == getOverlayViewEnable())
            ret = _setPreviewWindow(surface);
        return ret;
    }

    /**
     * @hide
     */
    @Override
    public int setCrop(int x, int y, int width, int height) throws RemoteException {
        // TODO Auto-generated method stub
        int ret = -1;
        if(true == getOverlayViewEnable())
            ret = _setCrop(x, y, width, height);
        return ret;
    }

    /**
     * @hide
     */
    public void startMov() {
        if(true == getOverlayViewEnable())
            _startMov();
    }

    /**
     * @hide
     */
    public void stopMov() {
        if(true == getOverlayViewEnable())
            _stopMov();
    }

    /**
     * @hide
     */
    public void pauseMov() {
        if(true == getOverlayViewEnable())
            _pauseMov();
    }

    /**
     * @hide
     */
    public void resumeMov() {
        if(true == getOverlayViewEnable())
            _resumeMov();
    }

    /**
     * @hide
     */
    public void startVideo() {
        if(true == getOverlayViewEnable())
            _startVideo();
    }

    /**
     * @hide
     */
    public void stopVideo() {
        if(true == getOverlayViewEnable())
            _stopVideo();
    }

    private native void _init(int source, int sourceType, boolean isFullscreen, boolean isRecording);
    private native void _deinit(boolean isRecording);
    private native int _displayHdmi();
    private native int _displayAndroid();
    private native int _displayPip(int x, int y, int width, int height);
    private native int _getHActive();
    private native int _getVActive();
    private native String _getInputSize();
    private native boolean _isDvi();
    private native boolean _isPowerOn();
    private native boolean _isEnable();
    private native boolean _isInterlace();
    private native boolean _hdmiPlugged();
    private native boolean _hdmiSignal();
    private native int _enableAudio(int flag);
    private native void _startMonitorUsbHostBusThread();
    private native int _handleAudio();
    private native int _setAmaudioMusicGain(int gain);
    private native int _setAmaudioLeftGain(int gain);
    private native int _setAmaudioRightGain(int gain);
    private native void _setAudioOutputRecord(boolean start);
    private native void _setStart(boolean start);
    private native int _setSourceType();
    private native boolean _isSurfaceAvailable(Surface surface);
    private native boolean _setPreviewWindow(Surface surface);
    private native int _setCrop(int x, int y, int width, int height);
    private native void _startMov();
    private native void _stopMov();
    private native void _pauseMov();
    private native void _resumeMov();
    private native void _startVideo();
    private native void _stopVideo();
}
