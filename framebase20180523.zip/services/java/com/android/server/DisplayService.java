/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.server;

import android.content.Context;
import android.content.Intent;
import android.app.SystemWriteManager;
import android.os.Handler;
import android.os.Message;
import android.os.SystemProperties;
import android.os.display.IDisplayService;
import android.os.UserHandle;
import android.util.SparseArray;
import android.util.Log;
import android.util.Slog;
import android.view.Display;
import android.view.WindowManagerPolicy;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.display.DisplayManager;
import android.provider.Settings;
import android.app.MboxOutputModeManager;


/**
 * Manages the properties of attached displays.
 * <p>s
 * Get an instance of this class by calling
 * {@link android.content.Context#getSystemService(java.lang.String)
 * Context.getSystemService()} with the argument
 * {@link android.content.Context#DISPLAY_SERVICE}.
 * </p>
 */
public class DisplayService extends IDisplayService.Stub{
    private static final String TAG = "DisplayService";
    private static final boolean DEBUG = true;
	
    private final Context mContext;
	
    private final static String CONFIG_PATH = "/sys/class/amhdmitx/amhdmitx0/disp_cap";
    private final static String mCurrentResolution = "/sys/class/display/mode";
    private final static String PpscalerRectFile = "/sys/class/ppmgr/ppscaler_rect";
	private static final String UpdateFreescaleFb0File = "/sys/class/graphics/fb0/update_freescale";
	private static final String HDMI_EDID_PATH = "/sys/class/amhdmitx/amhdmitx0/rawedid";
	
    private final static String sel_480ioutput_x = "ubootenv.var.480i_x";
    private final static String sel_480ioutput_y = "ubootenv.var.480i_y";
    private final static String sel_480ioutput_width = "ubootenv.var.480i_w";
    private final static String sel_480ioutput_height = "ubootenv.var.480i_h";
    private final static String sel_480poutput_x = "ubootenv.var.480p_x";
    private final static String sel_480poutput_y = "ubootenv.var.480p_y";
    private final static String sel_480poutput_width = "ubootenv.var.480p_w";
    private final static String sel_480poutput_height = "ubootenv.var.480p_h";
    private final static String sel_576ioutput_x = "ubootenv.var.576i_x";
    private final static String sel_576ioutput_y = "ubootenv.var.576i_y";
    private final static String sel_576ioutput_width = "ubootenv.var.576i_w";
    private final static String sel_576ioutput_height = "ubootenv.var.576i_h";
    private final static String sel_576poutput_x = "ubootenv.var.576p_x";
    private final static String sel_576poutput_y = "ubootenv.var.576p_y";
    private final static String sel_576poutput_width = "ubootenv.var.576p_w";
    private final static String sel_576poutput_height = "ubootenv.var.576p_h";
    private final static String sel_720poutput_x = "ubootenv.var.720p_x";
    private final static String sel_720poutput_y = "ubootenv.var.720p_y";
    private final static String sel_720poutput_width = "ubootenv.var.720p_w";
    private final static String sel_720poutput_height = "ubootenv.var.720p_h";
    private final static String sel_1080ioutput_x = "ubootenv.var.1080i_x";
    private final static String sel_1080ioutput_y = "ubootenv.var.1080i_y";
    private final static String sel_1080ioutput_width = "ubootenv.var.1080i_w";
    private final static String sel_1080ioutput_height = "ubootenv.var.1080i_h";
    private final static String sel_1080poutput_x = "ubootenv.var.1080p_x";
    private final static String sel_1080poutput_y = "ubootenv.var.1080p_y";
    private final static String sel_1080poutput_width = "ubootenv.var.1080p_w";
    private final static String sel_1080poutput_height = "ubootenv.var.1080p_h";

    private final static String sel_4k2koutput_x = "ubootenv.var.4k2k_x";
    private final static String sel_4k2koutput_y = "ubootenv.var.4k2k_y";
    private final static String sel_4k2koutput_width = "ubootenv.var.4k2k_w";
    private final static String sel_4k2koutput_height = "ubootenv.var.4k2k_h";
    
    private final static String sel_4k2ksmpteoutput_x = "ubootenv.var.4k2ksmpte_x";
    private final static String sel_4k2ksmpteoutput_y = "ubootenv.var.4k2ksmpte_y";
    private final static String sel_4k2ksmpteoutput_width = "ubootenv.var.4k2ksmpte_w";
    private final static String sel_4k2ksmpteoutput_height = "ubootenv.var.4k2ksmpte_h";

    private static final int OUTPUT480_FULL_WIDTH = 720;
    private static final int OUTPUT480_FULL_HEIGHT = 480;
    private static final int OUTPUT576_FULL_WIDTH = 720;
    private static final int OUTPUT576_FULL_HEIGHT = 576;
    private static final int OUTPUT720_FULL_WIDTH = 1280;
    private static final int OUTPUT720_FULL_HEIGHT = 720;
    private static final int OUTPUT1080_FULL_WIDTH = 1920;
    private static final int OUTPUT1080_FULL_HEIGHT = 1080;

    private static final int OUTPUT4k2k_FULL_WIDTH = 3840;
    private static final int OUTPUT4k2k_FULL_HEIGHT = 2160;
    private static final int OUTPUT4k2ksmpte_FULL_WIDTH = 4096;
    private static final int OUTPUT4k2ksmpte_FULL_HEIGHT = 2160;

	//20170925,colorspace start
	private static final String HDMI_10bitSUPPORT_LIST_SYSFS = "/sys/class/amhdmitx/amhdmitx0/dc_cap";
	private static final String HDMI_SUPPORT_LIST_SYSFS = CONFIG_PATH;
	private static final int COLOR_SPACE_UNKNOWN = 0;
	private static final int COLOR_SPACE_YUV_444_8BIT = 1;
	private static final int COLOR_SPACE_YUV_422_8BIT = 2;
	private static final int COLOR_SPACE_YUV_420_8BIT = 3;
	private static final int COLOR_SPACE_YUV_444_10BIT = 4;
	private static final int COLOR_SPACE_YUV_422_10BIT = 5;
	private static final int COLOR_SPACE_YUV_420_10BIT = 6;
	private static final int COLOR_SPACE_YUV_444_12BIT = 7;
	private static final int COLOR_SPACE_YUV_422_12BIT = 8;
	private static final int COLOR_SPACE_YUV_420_12BIT = 9;
	private static final int COLOR_SPACE_RGB_8BIT = 10;
	private static final int COLOR_SPACE_RGB_10BIT = 11;
	private static final int COLOR_SPACE_RGB_12BIT = 12;
	private static final int COLOR_SPACE_AUTO = 13;

    private static final String DEFAULT_OUTPUT_MODE = "720p60hz";
    private static final String DEFAULT_COLORSPACE_MODE = "  Y420 10bit";
    private static final String COLORSPACE_MODE_Y420_8BIT = "  Y420 8bit";
    private static final String COLORSPACE_MODE_Y444_8BIT = "  Y444 8bit";
    private static final String COLORSPACE_MODE_Y420_10BIT = "  Y420 10bit";
    private static final String  HDMI_MODE_2160P50HZ = "2160p50hz";
    private static final String  HDMI_MODE_2160P60HZ = "2160p60hz";
    private static final String  HDMI_MODE_2160P50HZ420 = "2160p50hz420";
    private static final String  HDMI_MODE_2160P60HZ420 = "2160p60hz420";
    private static final String  HDMI_MODE_2160P50HZ42010BIT = "2160p50hz42010bit";
    private static final String  HDMI_MODE_2160P60HZ42010BIT = "2160p60hz42010bit";
    private static final String  HDMI_MODE_2160P50HZ42212BIT = "2160p50hz42212bit";
    private static final String  HDMI_MODE_2160P60HZ42212BIT = "2160p60hz42212bit";
	private String[] filterModesAray = null;
    //

    private static final String HDMI_MODE_PROP = "ubootenv.var.hdmimode";
    private static final String STR_OUTPUT_VAR = "ubootenv.var.outputmode";
    private static final String CVBS_MODE_PROP = "ubootenv.var.cvbsmode";
    private final static String FreescaleFb0File = "/sys/class/graphics/fb0/free_scale";
    private final static String FreescaleFb1File = "/sys/class/graphics/fb1/free_scale";
    private static final String window_axis = "/sys/class/graphics/fb0/window_axis";
    private final static String fb0_blank = "sys/class/graphics/fb0/blank";
    private static final String VideoAxisFile = "/sys/class/video/axis";
    private final String PASSTHROUGH_PROPERTY = "ubootenv.var.digitaudiooutput";
    private final String SYS_DEVICES = "/sys/devices/";
    private final String DigitalRawFile = "/sys/class/audiodsp/digital_raw";
    private final String HDMI_AUIDO_SWITCH = "/sys/class/amhdmitx/amhdmitx0/config";
    private final String mAudoCapFile = "/sys/class/amhdmitx/amhdmitx0/aud_cap";
    private final String TV_SUPPORT_CEC = "/sys/class/amhdmitx/amhdmitx0/tv_support_cec";
	
    private static boolean ifModeSetting = false;
    /*private String ls = "";
    private String ts = "";
    private String rs = "";
    private String bs = "";*/
    private int l_gap = 0;//as margin unit
    private int t_gap = 0;//as margin unit
    private int r_gap = 0;//as margin unit
    private int b_gap = 0;//as margin unit

    private static float zoomStepWidth = 0f;
    private String curOutputmode = "";

    public final static int DISPLAY_STANDARD_1080P_60 = 0; 
    public final static int DISPLAY_STANDARD_1080P_50 = 1; 
    public final static int DISPLAY_STANDARD_1080P_30 = 2; 
    public final static int DISPLAY_STANDARD_1080P_25 = 3; 
    public final static int DISPLAY_STANDARD_1080P_24 = 4; 
    public final static int DISPLAY_STANDARD_1080I_60 = 5;
    public final static int DISPLAY_STANDARD_1080I_50 = 6; 
    public final static int DISPLAY_STANDARD_720P_60 = 7; 
    public final static int DISPLAY_STANDARD_720P_50 = 8; 
    public final static int DISPLAY_STANDARD_576P_50 = 9; 
    public final static int DISPLAY_STANDARD_480P_60 = 10; 
    public final static int DISPLAY_STANDARD_PAL = 11; 
    public final static int DISPLAY_STANDARD_NTSC = 12;

    public final static int DISPLAY_STANDARD_3840_2160P_24 = 0x100;
    public final static int DISPLAY_STANDARD_3840_2160P_25 = 0x101;
    public final static int DISPLAY_STANDARD_3840_2160P_30 = 0x102;
    public final static int DISPLAY_STANDARD_3840_2160P_60 = 0x103;
    public final static int DISPLAY_STANDARD_4096_2160P_24 = 0x200;
    public final static int DISPLAY_STANDARD_4096_2160P_25 = 0x201;
    public final static int DISPLAY_STANDARD_4096_2160P_30 = 0x202;
    public final static int DISPLAY_STANDARD_4096_2160P_60 = 0x203;
	
    public final static int margin_init_2 = 2;
    public final static int margin_init_5 = 5;

    private static final String[] outputmode_array = {
        "1080p60hz" , "1080p50hz" , "1080p30hz" ,"1080p25hz" ,"1080p24hz" , "1080i60hz" , "1080i50hz" ,
        "720p60hz" , "720p50hz" ,
        "576p50hz" ,"480p60hz", "576i" ,
        "480i",
        "2160p24hz", "2160p25hz", "2160p30hz", "2160p60hz420",
        "smpte24hz", "smpte25hz", "smpte30hz","smpte60hz420"};

    final Object mLock = new Object[0];
    private HandlerThread thr;
    private Handler mProgressHandler;
    private static int DELAY = 1*200;
    private static int SAVE_PARAMETER = 0;
    private static int MSG_HDMI_MODE_CHANGE = 100011;
    private MboxOutputModeManager mMboxOutputModeManager = null;
    private SystemWriteManager sw;

    private class DelayedHandler extends Handler {
        public DelayedHandler(Looper looper){
            super(looper);
        }
        @Override
        public void handleMessage(Message msg) {
            int what = msg.what;
            super.handleMessage(msg);
            if (what == DisplayService.SAVE_PARAMETER){
                //int tmpwaxis[] = {0, 0, 0, 0};
                //tmpwaxis = getScreenMargin();
                //savePosition(tmpwaxis[0], tmpwaxis[1], tmpwaxis[2], tmpwaxis[3]);
                savePosition(l_gap, t_gap, r_gap, b_gap);
            }else if (what == DisplayService.MSG_HDMI_MODE_CHANGE){
                Intent intent = new Intent(WindowManagerPolicy.ACTION_HDMI_MODE_CHANGED);
                intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
                intent.putExtra(WindowManagerPolicy.EXTRA_HDMI_MODE, (String)msg.obj);
                mContext.sendStickyBroadcastAsUser(intent, UserHandle.OWNER);
            }
        }
    }
    
    private void debug(String debug){
        if (DEBUG){
            Log.d(TAG, debug);
        }
    }
	/** @hide */
    public DisplayService(Context context) {
        super();
        mContext = context;
        sw = (SystemWriteManager)mContext.getSystemService("system_write");
        String filterModes = getPropertyString("ro.platform.filter.modes", null);
        Slog.i(TAG, "filterModes: " + filterModes);
        if(filterModes != null) {
            filterModesAray = filterModes.split(",");
        }
        thr = new HandlerThread("DisplayServiceThread");
        thr.start();
        mProgressHandler = new DelayedHandler(thr.getLooper());
    }

    /* * * * 
    *@param standard 
    * {@link #DISPLAY_STANDARD_1080P_60} 
    * {@link #DISPLAY_STANDARD_1080P_50} 
    * {@link #DISPLAY_STANDARD_1080P_30} 
    * {@link #DISPLAY_STANDARD_1080P_25} 
    * {@link #DISPLAY_STANDARD_1080P_24} 
    * {@link #DISPLAY_STANDARD_1080I_60} 
    * {@link #DISPLAY_STANDARD_1080I_50} 
    * {@link #DISPLAY_STANDARD_720P_60} 
    * {@link #DISPLAY_STANDARD_720P_50}
    * {@link #DISPLAY_STANDARD_576P_50} 
    * {@link #DISPLAY_STANDARD_480P_60}
    * {@link #DISPLAY_STANDARD_PAL}
    * {@link #DISPLAY_STANDARD_NTSC}
    * @return
    */
    public boolean isSupportStandard(int standard) {
	  boolean isSupportSmpte = SystemProperties.getBoolean("sys.support.smpte", true);
	  debug("isSupportStandard----->standard =" + standard + "  isSupportSmpte:" + isSupportSmpte);
	  
        if(!isHDMIPlugged() && (11 == standard || 12 == standard)){
		return true;
	 }
        try {
            BufferedReader rd = new BufferedReader(new FileReader(CONFIG_PATH));
            try {
                String line = null;
                ArrayList<String> sys = new ArrayList<String>();
                while((line = rd.readLine()) != null) {
                    debug("isSupportStandard----->current device support mode: " + line);
                    sys.add(line);
                }
                int count = sys.size();
                for(int i=0; i<count; i++) {
                    String ids = sys.get(i);
                    if(null != ids && (ids).contains("480")) {
                        if(DISPLAY_STANDARD_480P_60 == standard || DISPLAY_STANDARD_NTSC == standard)
                            return true;
                    }
                    else if(null != ids && (ids).contains("576")) {
                        if(DISPLAY_STANDARD_576P_50 == standard || DISPLAY_STANDARD_PAL == standard)
                            return true;
                    }
                    else if(null != ids && (("720p").equals(ids) || ("720p*").equals(ids)|| ids.contains("720p50hz"))) {
                        if(DISPLAY_STANDARD_720P_50 == standard)
                            return true;
                    }
                    else if(null != ids && (("720p60hz").equals(ids) || ("720p60hz*").equals(ids))) {
                        if(DISPLAY_STANDARD_720P_60 == standard)
                            return true;
                    }
                    else if(null != ids && (("1080i50hz").equals(ids) || ("1080i50hz*").equals(ids))) {
                        if(DISPLAY_STANDARD_1080I_50 == standard)
                            return true;
                    }
                    else if(null != ids && (("1080i").equals(ids) || ("1080i*").equals(ids) || ids.contains("1080i60hz"))) {
                        if(DISPLAY_STANDARD_1080I_60 == standard)
                            return true;
                    }
                    else if(null != ids && (("1080p").equals(ids) || ("1080p*").equals(ids) || ids.contains("1080p50hz"))) {
                        if(DISPLAY_STANDARD_1080P_50 == standard)
                            return true;
                    }
                    else if(null != ids && (("1080p60hz").equals(ids) || ("1080p60hz*").equals(ids))) {
                        if(DISPLAY_STANDARD_1080P_60 == standard)
                            return true;
                    }else if(null != ids && (("1080p30hz").equals(ids) || ids.contains("1080p30hz"))) {
                        if(DISPLAY_STANDARD_1080P_30 == standard)
                            return true;
                    }
                    else if(null != ids && (("1080p25hz").equals(ids) || ids.contains("1080p25hz"))) {
                        if(DISPLAY_STANDARD_1080P_25 == standard)
                            return true;
                    }else if(null != ids && (("1080p24hz").equals(ids) || ids.contains("1080p24hz"))) {
                        if(DISPLAY_STANDARD_1080P_24 == standard)
                            return true;
                    }
                    else if (null != ids && (("2160p24hz").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_3840_2160P_24 == standard)) {
                        return true;
                    }
                    else if (null != ids && (("2160p25hz").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_3840_2160P_25 == standard)) {
                        return true;
                    }
                    else if (null != ids && (("2160p30hz").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_3840_2160P_30 == standard)) {
                        return true;
                    }
                    else if (null != ids && (("2160p60hz420").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_3840_2160P_60 == standard)) {
                        return true;
                    }
                    else if (isSupportSmpte && null != ids && (("smpte24hz").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_4096_2160P_24 == standard)) {
                        return true;
                    }
                    else if (isSupportSmpte && null != ids && (("smpte25hz").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_4096_2160P_25 == standard)) {
                        return true;
                    }
                    else if (isSupportSmpte && null != ids && (("smpte30hz").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_4096_2160P_30 == standard)) {
                        return true;
                    }
                    else if (isSupportSmpte && null != ids && (("smpte60hz420").equalsIgnoreCase(ids)) && (DISPLAY_STANDARD_4096_2160P_60 == standard)) {
                        return true;
                    }
                }
            }finally {
                rd.close();
            }
        }catch (FileNotFoundException e1) {
            debug("isSupportDolbyD FileNotFoundException");
            return false;
        }catch(Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }
	
    private boolean isHDMIPlugged() {	
		String status = readSysfs("/sys/class/amhdmitx/amhdmitx0/hpd_state");
		Slog.i(TAG, "hpd_state:" + status);
		if ("1".equals(status))			   
			return true; 	   
		else 		  
			return false;	   
   }

   private boolean isTVStandby() {
		String status = readSysfs("/sys/class/switch/hdmi_rxsense/state");
		String tv_power = readSysfs("/sys/class/amhdmitx/amhdmitx0/tv_power_status");
		Slog.i(TAG, "hdmi_rxsense:" + status);
		Slog.i(TAG, "tv_power:" + tv_power);

		if("0".equals(status)){
			try {
				Thread.sleep(1000);
				status = readSysfs("/sys/class/switch/hdmi_rxsense/state");
				Slog.i(TAG, "retry hdmi_rxsense:" + status);
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		}

		if (isHDMIPlugged() && ("0".equals(status) ||
			(("1".equals(tv_power) || "3".equals(tv_power)) && isTvSupportCec())))
			return true; 	   
		else 		  
			return false;	   
   }

    public int[] getcvbsSupportStandards(){ 	   
		debug("=========getcvbsSupportStandards");	   
		int Standards[]={};	   
		Standards = new int[2];	   
		Standards[0] = 11;//480cvbs	   
		Standards[1] = 12;//576cvbs	   
		return Standards;	
    }

    public int[] getAllSupportStandards() {
        debug("getAllSupportStandards----->start");
        ArrayList<Integer> Standards = new ArrayList<Integer>();
	  boolean isSupportSmpte = SystemProperties.getBoolean("sys.support.smpte", true);
        int[] StandardArr = null;
	 if(isHDMIPlugged()){
        try {
            BufferedReader rd = new BufferedReader(new FileReader(CONFIG_PATH));
            ArrayList<String> sys = new ArrayList<String>();
            String line = null;
            try {
                while((line = rd.readLine()) != null) {
                    debug("getAllSupportStandards----->current device support mode :" + line);
                    sys.add(line);
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            for (int i = 0; i < outputmode_array.length; i++) {
                for(int j = 0 ; j < sys.size() ; j++){
//                    if (sys.get(j).equalsIgnoreCase(outputmode_array[i]) || sys.get(j).equalsIgnoreCase(outputmode_array[i] + "*")) {
                    if (sys.get(j).toLowerCase().contains(outputmode_array[i])){

                        if("jiangxi".equalsIgnoreCase(SystemProperties.get("sys.proj.tender.type"))){
                            if (outputmode_array[i].equalsIgnoreCase("1080p24hz")
                                || outputmode_array[i].equalsIgnoreCase("1080p30hz")
                                ){
                                    continue ;
                            }
                        }

                        if (outputmode_array[i].equalsIgnoreCase("2160p24hz")){
                            Standards.add(DISPLAY_STANDARD_3840_2160P_24);
                        }else if (outputmode_array[i].equalsIgnoreCase("2160p25hz")){
                            Standards.add(DISPLAY_STANDARD_3840_2160P_25);
                        }else if (outputmode_array[i].equalsIgnoreCase("2160p30hz")){
                            Standards.add(DISPLAY_STANDARD_3840_2160P_30);
                        }else if (outputmode_array[i].equalsIgnoreCase("2160p60hz420")){
                            Standards.add(DISPLAY_STANDARD_3840_2160P_60);
                        }else if (isSupportSmpte && outputmode_array[i].equalsIgnoreCase("smpte24hz")){
                            Standards.add(DISPLAY_STANDARD_4096_2160P_24);
                        }else if (isSupportSmpte && outputmode_array[i].equalsIgnoreCase("smpte25hz")){
                            Standards.add(DISPLAY_STANDARD_4096_2160P_25);
                        }else if (isSupportSmpte && outputmode_array[i].equalsIgnoreCase("smpte30hz")){
                            Standards.add(DISPLAY_STANDARD_4096_2160P_30);
                        }else if (isSupportSmpte && outputmode_array[i].equalsIgnoreCase("smpte60hz420")){
                            Standards.add(DISPLAY_STANDARD_4096_2160P_60);
                        }else{
                            Standards.add(i);
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        StandardArr = new int[Standards.size()];
        for(int index = 0; index < Standards.size(); index++){
            StandardArr[index] = Standards.get(index).intValue();
            debug("getAllSupportStandards----->" + StandardArr[index]);
        }
        return StandardArr;
    	}else{
		return getcvbsSupportStandards();
	 }
    }

    public void setDisplayStandard(int standard) {
        debug("setDisplayStandard----->standard=" + standard);
		int tmp_unit = 1;
        synchronized (mLock) {
            if(!isSupportStandard(standard)){
                debug("setDisplayStandard----->current device doesn't support standard:" + standard);
                return;
            }else{
                String mode=null;
                switch(standard){
                    case 0:
                        mode = "1080p60hz";//1080p
                        tmp_unit = 2;
                        break;
                    case 1:
                        mode = "1080p50hz";//1080p
                        tmp_unit = 2;
                        break;
                    case 2:
                        mode = "1080p30hz";//1080p
                        tmp_unit = 2;
                        break;
                    case 3:
                        mode = "1080p25hz";//1080p
                        tmp_unit = 2;
                        break;
                    case 4:
                        mode = "1080p24hz";//1080p
                        tmp_unit = 2;
                        break;
                    case 5:
                        mode = "1080i60hz";//1080p
                        tmp_unit = 2;
                        break;
                    case 6:
                        mode = "1080i50hz";//1080i
                        tmp_unit = 2;
                        break;
                    case 7:
                        mode = "720p60hz";//720p
                        tmp_unit = 1;
                        break;
                    case 8:
                        mode = "720p50hz";//720p
                        tmp_unit = 1;
                        break;
                    case 9:
                        mode="576p50hz";//576p
                        tmp_unit = 1;
                        break;
                    case 10:
                        mode="480p60hz";//480p
                        tmp_unit = 1;
                        break;
                    case 11:
                        if(isHDMIPlugged())
                        {
                            mode="576i50hz";//576i;
                        }    
                        else
                        {
                            mode="576cvbs";
                        }
                        tmp_unit = 1;
                        break;
                    case 12:
                        if(isHDMIPlugged())
                        {
                            mode="480i60hz";//480i
                        }					
                        else
                        {
                            mode="480cvbs";
                        }
                        tmp_unit = 1;
                        break;
                    case DISPLAY_STANDARD_3840_2160P_24:
                        mode = "2160p24hz";
                        tmp_unit = 5;
                        break;
                    case DISPLAY_STANDARD_3840_2160P_25:
                        mode = "2160p25hz";
                        tmp_unit = 5;
                        break;
                    case DISPLAY_STANDARD_3840_2160P_30:
                        mode = "2160p30hz";
                        tmp_unit = 5;
                        break;
                    case DISPLAY_STANDARD_3840_2160P_60:
                        mode = "2160p60hz420";
                        tmp_unit = 5;
                        break;
                    case DISPLAY_STANDARD_4096_2160P_24:
                        mode = "smpte24hz";
                        tmp_unit = 5;
                        break;
                    case DISPLAY_STANDARD_4096_2160P_25:
                        mode = "smpte25hz";
                        tmp_unit = 5;
                        break;
                    case DISPLAY_STANDARD_4096_2160P_30:
                        mode = "smpte30hz";
                        tmp_unit = 5;
                        break;
                    case DISPLAY_STANDARD_4096_2160P_60:
                        mode = "smpte60hz420";
                        tmp_unit = 5;
                        break;
                    default:
                        break;
                 }
                 String curMode = readSysfs(mCurrentResolution);
                 String newMode = mode;
                 //switch colorspace
                 debug("===,checkColorSpaceMode,newMode:"+newMode);
                 checkColorSpaceMode(newMode);
                 String cmode = switchColorSpaceMode(newMode);
                 debug("===,switchColorSpaceMode,newMode:"+newMode+",cmode:"+cmode);
                 if(cmode != null){
                     newMode = cmode;
                     debug("===,switchColorSpaceMode,newMode:"+newMode);
                 }
                 //

                 if(curMode == null || curMode.length() < 4){
                     debug("setDisplayStandard----->curMode wrong!!!");
                     curMode =  "720p";
                 }
                 debug("setDisplayStandard----->change mode from oldMode =" + curMode + "to new mode = " + newMode);
                 if(newMode.equals(curMode)){
                     return ;
                 }

                 shadowScreen(curMode);
                 writeSysfs(mCurrentResolution, newMode);

                 int[] curPosition = getPosition(newMode);
                 int[] oldPosition = getPosition(curMode);
                 int axis[] = {0, 0, 0, 0};
				 	
                 String axisStr = readSysfs(VideoAxisFile);
                 String[] axisArray = axisStr.split(" ");
				 
                 for(int i=0; i<axisArray.length; i++) {
                     if(i == axis.length){
                         break;
                     }
                     try {
                         axis[i] = Integer.parseInt(axisArray[i]);
                     }
                     catch (Exception e) {
                         e.printStackTrace();
                     }
                 }
				 
                 int[] curWightAndHeight =  getWightAndHeight(newMode);
                 int left = curPosition[0] > 100*tmp_unit ? 100*tmp_unit : curPosition[0];
                 int top = curPosition[1] > 100*tmp_unit ? 100*tmp_unit : curPosition[1];
                 int right = (curWightAndHeight[0]-(curPosition[0]+curPosition[2])) > 100*tmp_unit ? curWightAndHeight[0]-100*tmp_unit-1 : curPosition[0]+curPosition[2];
                 int bottom = (curWightAndHeight[1]-(curPosition[1]+curPosition[3])) >100*tmp_unit ? curWightAndHeight[1]-100*tmp_unit-1 : curPosition[1]+curPosition[3];
                 
                 if(left < 0){
                     left = 0 ;
                 }
                 if(top < 0){
                     top = 0;
                 }
                 
                 if((curWightAndHeight[0]-(curPosition[0]+curPosition[2])) < 0) 
                 {
                     right = curWightAndHeight[0] - 1;
                     debug("right positon < 0,then make it max!-----> =" + right);
                 }
                 if((curWightAndHeight[1]-(curPosition[1]+curPosition[3])) < 0)
                 {
                     bottom = curWightAndHeight[1] - 1;
                     debug("bottom positon < 0,then make it max!-----> =" + right);
                 }
				 	
                 String mWinAxis = left+" "+top+" "+right+" "+bottom;
                 debug("mWinAxis----->mWinAxis =" + mWinAxis);

                 if(getPropertyBoolean("ro.platform.has.realoutputmode", false)){
                     if (SystemProperties.get("ubootenv.var.uimode", "720p").equals("1080p")) {
                         if(newMode.contains("4k2k")){
                             //open freescale ,  scale up from 1080p to 4k
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1919 1079");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if(newMode.contains("1080")){
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1919 1079");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             if (curPosition[0] == 0 && curPosition[1] == 0)
                                 writeSysfs("/sys/class/graphics/fb0/free_scale","0");
                             else
                                 writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if(newMode.contains("720")){
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1919 1079");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if(newMode.contains("576")){
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1919 1079");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if(newMode.contains("480")){

                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1919 1079");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if (newMode.contains("2160")){    //for 4K ?
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1919 1079");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if (newMode.contains("smpte")){    //for 4K ?
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1919 1079");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else{
                             debug("setDisplayStandard---else-->can't support this mode : " + newMode);
                             return;
                         }
                     }else {
                         if(newMode.contains("1080")){
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1279 719");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if(newMode.contains("720")){
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1279 719");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");

                         }else if(newMode.contains("576")){
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1279 719");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
							 
                         }else if(newMode.contains("480")){

                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1279 719");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");

                         }else if (newMode.contains("2160")){    //for 4K ?
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1279 719");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else if (newMode.contains("smpte")){    //for 4K ?
                             writeSysfs("/sys/class/graphics/fb0/freescale_mode","1");
                             writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1279 719");
                             writeSysfs("/sys/class/graphics/fb0/window_axis",mWinAxis);
                             writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
                         }else{
                             debug("setDisplayStandard--if--->can't support this mode :" + newMode);
                             return;
                         }
                     }
				     
                     int oldX = oldPosition[0];
                     int oldY = oldPosition[1];
                     int oldWidth = oldPosition[2];
                     int oldHeight = oldPosition[3];
                     int curX = curPosition[0];
                     int curY = curPosition[1];
                     int curWidth = curPosition[2];
                     int curHeight = curPosition[3];
                     int temp1 = curX;
                     int temp2 = curY;
                     int temp3 = curWidth;
                     int temp4 = curHeight;
                     if (DEBUG){
                         Log.d(TAG, "setOutputModeNowLocked, old is: "
                                 + oldX + " " + oldY + " " + oldWidth + " " + oldHeight);
                         Log.d(TAG, "setOutputModeNowLocked, new is: "
                                 + curX + " " + curY + " " + curWidth + " " + curHeight);
                         Log.d(TAG, "setOutputModeNowLocked, axis is: "
                                 + axis[0] + " " + axis[1] + " " + axis[2] + " " + axis[3]);
                     }
                     if(!((axis[0] == 0) && (axis[1] == 0) && (axis[2] == -1) && (axis[3] == -1))
                             && !((axis[0] == 0) && (axis[1] == 0) && (axis[2] == 0) && (axis[3] == 0))) {
                         temp1 = (axis[0] - oldX) * curWidth / oldWidth + curX;
                         temp2 = (axis[1] - oldY) * curHeight / oldHeight + curY;
                         temp3 = (axis[2] - axis[0] + 1) * curWidth / oldWidth;
                         temp4 = (axis[3] - axis[1] + 1) * curHeight / oldHeight;
                     }
                     String mVideoAxis = temp1 + " " + temp2 + " " + (temp3 + temp1 - 1) + " " + (temp4 + temp2 - 1);
                     debug("setDisplayStandard----->changed axis is: " + mVideoAxis);
                     writeSysfs(VideoAxisFile, mVideoAxis);

                     /* String mDisplayAxis = curPosition[0] + " "+ curPosition[1] +
                      * getDisplayAxisByMode(newMode)+ curPosition[0]+ " " + curPosition[1]+ " " + 18+ " " + 18;
                      * writeSysfs(OutputAxisFile, mDisplayAxis);
                      */

                 }else {
                     String value = curPosition[0] + " " + curPosition[1]
                             + " " + (curPosition[2] + curPosition[0] )
                             + " " + (curPosition[3] + curPosition[1] )+ " " + 0;
                     setM6FreeScaleAxis(newMode);
                     writeSysfs(mCurrentResolution,newMode);
                     writeSysfs(PpscalerRectFile, value);
                     writeSysfs(UpdateFreescaleFb0File, "1");
                 }
                 setProperty(STR_OUTPUT_VAR, newMode);
                 saveNewMode2Prop(newMode);
                 notifyModeChanged(newMode);
                 if(null == mMboxOutputModeManager)
				 mMboxOutputModeManager = (MboxOutputModeManager) mContext.getSystemService(Context.MBOX_OUTPUTMODE_SERVICE);
                 if (!(newMode.contains("cvbs"))){
				 Log.d(TAG , "==start hdcpAuthenticate==");
				 mMboxOutputModeManager.StarthdcpAuthenticate();
                 }
  /**
                 Intent intent = new Intent(WindowManagerPolicy.ACTION_HDMI_MODE_CHANGED);
                 intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
                 intent.putExtra(WindowManagerPolicy.EXTRA_HDMI_MODE, newMode);
//                 mContext.sendStickyBroadcastAsUser(intent, UserHandle.ALL);
                 mContext.sendBroadcast(intent);
                 */
            }
        }
    }

    public void setDisplayStandardWithSettingRestart(int standard) {
        String curMode = readSysfs(mCurrentResolution);
        if(curMode.contains("720"))
            return;
        writeSysfs(fb0_blank,"1");
        try {
            Runtime.getRuntime().exec("am start -S net.sunniwell.app.swsettings.chinamobile/net.sunniwell.app.swsettings.chinamobile.SWSettingsActivity");
        }catch (IOException e1){
            Log.e(TAG,"restart setting fail");
        }
        setDisplayStandard(standard);
   }

    private void setM6FreeScaleAxis(String mode){
        writeSysfs("/sys/class/graphics/fb0/free_scale_axis","0 0 1279 719");
        writeSysfs("/sys/class/graphics/fb0/free_scale","0x10001");
   }

   private void saveNewMode2Prop(String newMode){
        if((newMode != null) && newMode.contains("cvbs")){
            setProperty(CVBS_MODE_PROP, newMode);
        }
        else{
            setProperty(HDMI_MODE_PROP, newMode);
        }
   }

    private void shadowScreen(final String mode){
        writeSysfs(fb0_blank, "1");
        Thread task = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ifModeSetting = true;
                    Thread.sleep(1000);
                    writeSysfs(fb0_blank, "0");
                    ifModeSetting = false;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
    	    }
        });
        task.start();
    }


    private int[] getWightAndHeight(String mode) {
		int[] curWightHeight = { 1280, 720 };
        int index = 7; // 720p
        index = getCurrentStandard();
        switch (index) {
            case 0://1080p
            case 1://1080p50hz
            case 2://1080p30hz
            case 3://1080p25hz
            case 4://1080p24hz
            case 5://1080i
            case 6://1080i50hz
                curWightHeight[0] = 1920;
                curWightHeight[1] = 1080;
                break;
            case 9: // 576p
                curWightHeight[0] = 720;
                curWightHeight[1] = 576;
                break;
            case 10: // 480p
                curWightHeight[0] = 720;
                curWightHeight[1] = 480;
                break;
            case 11: // 576i
                curWightHeight[0] = 720;
                curWightHeight[1] = 576;
                break;

            case 12: // 480i
                curWightHeight[0] = 720;
                curWightHeight[1] = 480;
                break;
            case DISPLAY_STANDARD_3840_2160P_24:
            case DISPLAY_STANDARD_3840_2160P_25:
            case DISPLAY_STANDARD_3840_2160P_30:
            case DISPLAY_STANDARD_3840_2160P_60:
                curWightHeight[0] = 3840;
                curWightHeight[1] = 2160;
                break;
            case DISPLAY_STANDARD_4096_2160P_24:
            case DISPLAY_STANDARD_4096_2160P_25:
            case DISPLAY_STANDARD_4096_2160P_30:
            case DISPLAY_STANDARD_4096_2160P_60:
                curWightHeight[0] = 4096;
                curWightHeight[1] = 2160;
                break;
            default://720p&720p50hz
                curWightHeight[0] = 1280;
                curWightHeight[1] = 720;
                break;
        }
        debug("curWightHeight------>curWightHeight[0]=" + curWightHeight[0] + ", curWightHeight[1]=" + curWightHeight[1]);
        return curWightHeight;
		
	}
	
    private int[] getPosition(String mode) {
        int[] curPosition = { 0, 0, 1280, 720 };
        int index = 7; // 720p
        int width = 1280;
        int height = 720;
		
        debug("getPosition-----> mode=" + mode);
       if ("480cvbs".equalsIgnoreCase(mode)) {
           mode = "480i";
       } else if ("576cvbs".equalsIgnoreCase(mode)) {
           mode = "576i";
       }
       else if ("480i60hz".equalsIgnoreCase(mode)) {
           mode = "480i";
       }
       else if ("576i50hz".equalsIgnoreCase(mode)) {
           mode = "576i";
       }
       else if ("2160p50hz42010bit".equalsIgnoreCase(mode)) {
           mode = "2160p30hz";
       }
       else if ("2160p60hz42010bit".equalsIgnoreCase(mode)) {
           mode = "2160p60hz420";
       }
       else if ("2160p50hz42212bit".equalsIgnoreCase(mode)) {
           mode = "2160p30hz";
       }
       else if ("2160p60hz42212bit".equalsIgnoreCase(mode)) {
           mode = "2160p60hz420";
       }			
       
        if(mode.contains("0p") && (!mode.contains("hz")))
            mode = mode + "50hz";

        for (int i = 0; i < outputmode_array.length; i++) {
            if (mode.equalsIgnoreCase(outputmode_array[i]))
                if (outputmode_array[i].equalsIgnoreCase("2160p24hz")){
                    index = DISPLAY_STANDARD_3840_2160P_24;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p25hz")){
                    index = DISPLAY_STANDARD_3840_2160P_25;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p30hz")){
                    index = DISPLAY_STANDARD_3840_2160P_30;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p60hz420")){
                    index = DISPLAY_STANDARD_3840_2160P_60;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte24hz")){
                    index = DISPLAY_STANDARD_4096_2160P_24;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte25hz")){
                    index = DISPLAY_STANDARD_4096_2160P_25;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte30hz")){
                    index = DISPLAY_STANDARD_4096_2160P_30;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte60hz420")){
                    index = DISPLAY_STANDARD_4096_2160P_60;
                }else {
                    index = i;
                }
        }
        
        debug("getPosition------>l_gap=" + l_gap + ", t_gap=" + t_gap + ", l_gap=" +l_gap +", b_gap=" + b_gap);
        debug("getPosition-----> index=" + index);
        //index = getCurrentStandard();
         switch (index){
             case 0://1080p
             case 1://1080p50hz
             case 2://1080p30hz
             case 3://1080p25hz
             case 4://1080p24hz
             case 5://1080i
             case 6://1080i50hz
             width = 1920;
             height = 1080;
             curPosition[0] = l_gap*margin_init_2;
             curPosition[1] = t_gap*margin_init_2 ;
             curPosition[2] = width - r_gap*margin_init_2 - l_gap*margin_init_2-1;
             curPosition[3] = height - t_gap*margin_init_2 - b_gap*margin_init_2-1;
             break;
             case 7: // 720p
             case 8:
             width = 1280;
             height = 720;
             curPosition[0] = l_gap;
             curPosition[1] = t_gap ;
             curPosition[2] = width - r_gap - l_gap-1;
             curPosition[3] = height - t_gap - b_gap-1;			 
             break;
             case 9: // 576p
             width = 720;
             height = 576;
             curPosition[0] = l_gap;
             curPosition[1] = t_gap ;
             curPosition[2] = width - r_gap - l_gap-1;
             curPosition[3] = height - t_gap - b_gap-1;			 
             break;
             case 10: // 480p
             width = 720;
             height = 480;
             curPosition[0] = l_gap;
             curPosition[1] = t_gap ;
             curPosition[2] = width - r_gap - l_gap-1;
             curPosition[3] = height - t_gap - b_gap-1;			 
             break;
             case 11: // 576i
             width = 720;
             height = 576;
             curPosition[0] = l_gap;
             curPosition[1] = t_gap ;
             curPosition[2] = width - r_gap - l_gap-1;
             curPosition[3] = height - t_gap - b_gap-1;			 
             break;
             case 12: // 480i
             width = 720;
             height = 480;
             curPosition[0] = l_gap;
             curPosition[1] = t_gap ;
             curPosition[2] = width - r_gap - l_gap-1;
             curPosition[3] = height - t_gap - b_gap-1;			 			 
             break;
             case DISPLAY_STANDARD_3840_2160P_24:
             case DISPLAY_STANDARD_3840_2160P_25:
             case DISPLAY_STANDARD_3840_2160P_30:
             case DISPLAY_STANDARD_3840_2160P_60:
             width = 3840;
             height = 2160;
             curPosition[0] = l_gap*margin_init_5;
             curPosition[1] = t_gap*margin_init_5 ;
             curPosition[2] = width - r_gap*margin_init_5 - l_gap*margin_init_5-1;
             curPosition[3] = height - t_gap*margin_init_5 - b_gap*margin_init_5-1;			 
             break;
             case DISPLAY_STANDARD_4096_2160P_24:
             case DISPLAY_STANDARD_4096_2160P_25:
             case DISPLAY_STANDARD_4096_2160P_30:
             case DISPLAY_STANDARD_4096_2160P_60:
             width = 4096;
             height = 2160;
             curPosition[0] = l_gap*margin_init_5;
             curPosition[1] = t_gap*margin_init_5 ;
             curPosition[2] = width - r_gap*margin_init_5 - l_gap*margin_init_5-1;
             curPosition[3] = height - t_gap*margin_init_5 - b_gap*margin_init_5-1;			 			 
             break;
             default:
             curPosition[0] = l_gap*width/OUTPUT480_FULL_WIDTH;
             curPosition[1] = t_gap*height/OUTPUT480_FULL_HEIGHT ;
             curPosition[2] = width - r_gap*width/OUTPUT480_FULL_WIDTH - l_gap*width/OUTPUT480_FULL_WIDTH-1;
             curPosition[3] = height - t_gap*height/OUTPUT480_FULL_HEIGHT - b_gap*height/OUTPUT480_FULL_HEIGHT-1;
             break;
         }
		 
        debug("getPosition------>curPosition[0]=" + curPosition[0] + ", curPosition[1]=" + curPosition[1] + ", curPosition[2]=" +
                curPosition[2] +", curPosition[3]=" + curPosition[3]);
        return curPosition;
    }

    public int getCurrentStandard() {
        int index = 7;
        String mCurMode = getCurrentOutputResolution();
        if(mCurMode.contains("0p") && (!mCurMode.contains("hz")))
            mCurMode = mCurMode + "50hz";
		
        for (int i = 0 ;i < (outputmode_array.length); i++) {
            if(mCurMode.toLowerCase().contains(outputmode_array[i])){
                if (outputmode_array[i].equalsIgnoreCase("2160p24hz")){
                    index = DISPLAY_STANDARD_3840_2160P_24;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p25hz")){
                    index = DISPLAY_STANDARD_3840_2160P_25;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p30hz")){
                    index = DISPLAY_STANDARD_3840_2160P_30;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p60hz420")){
                    index = DISPLAY_STANDARD_3840_2160P_60;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte24hz")){
                    index = DISPLAY_STANDARD_4096_2160P_24;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte25hz")){
                    index = DISPLAY_STANDARD_4096_2160P_25;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte30hz")){
                    index = DISPLAY_STANDARD_4096_2160P_30;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte60hz420")){
                    index = DISPLAY_STANDARD_4096_2160P_60;
                }else {
                    index = i;
                }
                return index;
            }
        }
        return index;
    }
    /**
    public int getCurrentStandard() {
        int index = 7;
        String mCurMode = getCurrentOutputResolution();
        if(mCurMode.contains("0p") && (!mCurMode.contains("hz")))
            mCurMode = mCurMode + "50hz";
        else if(mCurMode.contains("720p60hz"))
            mCurMode = new String("720p50hz");
        else if(mCurMode.contains("1080p60hz"))
            mCurMode = new String("1080p50hz");
        else if(mCurMode.contains("2160p60hz"))
            mCurMode = new String("2160p60hz");
        else if (mCurMode.contains("smpte"))
            mCurMode = new String("smpte");
        for (int i = (outputmode_array.length -1); i >= 0; i--) {
            if(outputmode_array[i].contains(mCurMode)){
                if (outputmode_array[i].equalsIgnoreCase("2160p24hz")){
                    index = DISPLAY_STANDARD_3840_2160P_24;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p25hz")){
                    index = DISPLAY_STANDARD_3840_2160P_25;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p30hz")){
                    index = DISPLAY_STANDARD_3840_2160P_30;
                }else if (outputmode_array[i].equalsIgnoreCase("2160p60hz")){
                    index = DISPLAY_STANDARD_3840_2160P_60;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte24hz")){
                    index = DISPLAY_STANDARD_4096_2160P_24;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte25hz")){
                    index = DISPLAY_STANDARD_4096_2160P_25;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte30hz")){
                    index = DISPLAY_STANDARD_4096_2160P_30;
                }else if (outputmode_array[i].equalsIgnoreCase("smpte60hz420")){
                    index = DISPLAY_STANDARD_4096_2160P_60;
                }else {
                    index = i;
                }
                return index;
            }
        }
        debug("getCurrentStandard----->current standard=" + index);
        return index;
    }
    */
/*    public void setScreenMargin(int left, int top, int right, int bottom) {
		Log.d(TAG,"=========setScreenMargin, left:" + left + ", top:" + top + ", right:" + right + ", bottom:" + bottom);
		String str = "";
		int width = 1280;
		int height = 720;
		curOutputmode = getCurrentOutputResolution();
		Log.d(TAG,"=========setScreenMargin, curOutputmode: " + curOutputmode);
		initStep(curOutputmode);
		Log.d(TAG,"=========setScreenMargin, zoonstepWidth: " + zoomStepWidth);
		if(left < 0){
			left = 0 ;
		}
		if(top < 0){
			top = 0;
		}
		else if(top >= 210)
			top = 209;
		if(curOutputmode.contains("480")){
			if(right > (720 + (int)(5*zoomStepWidth))){
				right = (720 + (int)(5*zoomStepWidth)) ;
			}
			if(bottom > (480+5)){
				bottom = (480+5) ;
			}
			width = 720;
			height = 480;
		}else if(curOutputmode.contains("576")){
			if(right > (720+(int)(5*zoomStepWidth))){
				right = (720+(int)(5*zoomStepWidth)) ;
			}
			if(bottom > (576+5)){
				bottom = (576+5) ;
			}
			width = 720;
			height = 576;
		}else if(curOutputmode.contains("720")){
			if(right > (1280+(int)(5*zoomStepWidth))){
				right = (1280+(int)(5*zoomStepWidth)) ;
			}
			if(bottom > (720+5)){
				bottom = (720+5) ;
			}
			width = 1280;
			height = 720;
		}else if(curOutputmode.contains("1080")){
			if(right > (1920+(int)(5*zoomStepWidth))){
				right = (1920+(int)(5*zoomStepWidth)) ;
			}
			if(bottom > (1080+5)){
				bottom = (1080+5) ;
			}
			width = 1920;
			height = 1080;
		}
		str = left + " " + top + " " + (width-right-1) + " " + (height-bottom-1) + " " + 0;

        synchronized (mLock) {
		    if(getPropertyBoolean("ro.platform.has.realoutputmode", false)){
		            writeSysfs(window_axis,left+" "+top+" "+(right-1)+" "+(bottom-1));
		            writeSysfs(FreescaleFb0File,"0x10001");
        	    }
		    else{
			    writeSysfs(PpscalerRectFile, str);
			    writeSysfs(UpdateFreescaleFb0File, "1");
		    }
        }
		
		ls = String.valueOf(left);
		ts = String.valueOf(top);
		rs = String.valueOf(width-right-left);
		bs = String.valueOf(height-bottom-top);
		//savePosition(ls, ts, rs, bs);
		
    }*/

    public void setScreenMargin(int left, int top, int right, int bottom) {
        Log.d(TAG,"setScreenMargin----->start, left=" + left + ", top=" + top + ", right=" + right + ", bottom=" + bottom);
        String str = "";
        int width = 1280;
        int height = 720;
        curOutputmode = getCurrentOutputResolution();
        initStep(curOutputmode);
        if(left < 0){
            left = 0 ;
        }
        else if(left > 100)
        {
           top = 100;
        }
        if(top < 0){
            top = 0;
        }
        else if(top > 100){
            top = 100;
        }
        
        if(right < 0){
            right = 0;
        }
        else if(right > 100){
            right = 100;
        }
        
        if(bottom < 0){
            bottom = 0;
        }
        else if(bottom > 100){
            bottom = 100;
        }
		
        if(curOutputmode.contains("480")){
            if(right > (720 + (int)(5*zoomStepWidth))){
                right = (720 + (int)(5*zoomStepWidth)) ;
            }
            if(bottom > (480+5)){
                bottom = (480+5) ;
            }
            width = 720;
            height = 480;
            str = left + " " + top + " " + (width-right-1) + " " + (height-bottom-1) + " " + 0;
			
        }else if(curOutputmode.contains("576")){
            if(right > (720+(int)(5*zoomStepWidth))){
                right = (720+(int)(5*zoomStepWidth)) ;
            }
            if(bottom > (576+5)){
                bottom = (576+5) ;
            }
            width = 720;
            height = 576;
            str = left + " " + top + " " + (width-right-1) + " " + (height-bottom-1) + " " + 0;
			
        }else if(curOutputmode.contains("720")){
            if(right > (1280+(int)(5*zoomStepWidth))){
                right = (1280+(int)(5*zoomStepWidth)) ;
            }
            if(bottom > (720+5)){
                bottom = (720+5) ;
            }
            width = 1280;
            height = 720;
            str = left + " " + top + " " + (width-(right)-1) + " " + (height-(bottom)-1) + " " + 0;
			
        }else if(curOutputmode.contains("1080")){
            if(right > (1920+(int)(5*zoomStepWidth))){
                right = (1920+(int)(5*zoomStepWidth)) ;
            }
            if(bottom > (1080+5)){
                bottom = (1080+5) ;
            }
            width = 1920;
            height = 1080;
            str = left*margin_init_2 + " " + top*margin_init_2 + " " + (width-(right*margin_init_2)-1) + " " + (height-(bottom*margin_init_2)-1) + " " + 0;
			
        }else if (curOutputmode.contains("2160")){
            //what should i do there?
            if(right > (3840+(int)(5*zoomStepWidth))){
                right = (3840+(int)(5*zoomStepWidth)) ;
            }
            if(bottom > (2160+5)){
                bottom = (2160+5) ;
            }
            width = 3840;
            height = 2160;
            str = left*margin_init_5 + " " + top*margin_init_5 + " " + (width-(right*margin_init_5)-1) + " " + (height-(bottom*margin_init_5)-1) + " " + 0;

        }else if (curOutputmode.contains("smpte")){
            //what should i do there?
            if(right > (4096+(int)(5*zoomStepWidth))){
                right = (4096+(int)(5*zoomStepWidth)) ;
            }
            if(bottom > (2160+5)){
                bottom = (2160+5) ;
            }
            width = 4096;
            height = 2160;
            str = left*margin_init_5 + " " + top*margin_init_5 + " " + (width-(right*margin_init_5)-1) + " " + (height-(bottom*margin_init_5)-1) + " " + 0;
        }
        else
        {
            str = left*width/OUTPUT480_FULL_WIDTH + " " + top*height/OUTPUT480_FULL_HEIGHT + " " + (width-(right*width/OUTPUT480_FULL_WIDTH)-1) + " " + (height-(bottom*height/OUTPUT480_FULL_HEIGHT)-1) + " " + 0;
        }

		
        debug("str====================" + str);
        synchronized (mLock) {
            if(getPropertyBoolean("ro.platform.has.realoutputmode", false)){				
                writeSysfs(window_axis,str);
                //writeSysfs(FreescaleFb0File,"0x10001");
            }
            else{
                writeSysfs(PpscalerRectFile, str);
                writeSysfs(UpdateFreescaleFb0File, "1");
            }
        }
	 
	 if ("mobile".equals(SystemProperties.get("sys.proj.type", "false"))) {
		if(right > 100)
			right = left;
		if(bottom > 100)
			bottom = top;
		Log.d(TAG,"[new mobile]setScreenMargin----->start, left=" + left + ", top=" + top + ", right=" + right + ", bottom=" + bottom);
	  }
		
        l_gap = left;
        t_gap = top;
        r_gap = right;
        b_gap = bottom;
        //savePosition(ls, ts, rs, bs);
        saveParams();
    }

    public void saveParams() {
        debug("saveParams----->start, left=" + l_gap + ", top=" + t_gap + ", right=" + r_gap + ", bottom=" + b_gap);
        mProgressHandler.removeMessages(SAVE_PARAMETER);
        mProgressHandler.sendEmptyMessageDelayed(SAVE_PARAMETER, DELAY);
	}

    public void notifyModeChanged(String newMode){
        Message msg = Message.obtain();
        msg.what = MSG_HDMI_MODE_CHANGE;
        msg.obj = newMode;
        mProgressHandler.removeMessages(MSG_HDMI_MODE_CHANGE);
        mProgressHandler.sendMessage(msg);
    }
	
    private void savePosition(int l, int t, int r, int b) {
        int curoutputmode = getCurrentStandard();
		
        String x = "";
        String y = "";
        String w = "";
        String h = "";


		//curPosition[0] = l_gap*width/OUTPUT480_FULL_WIDTH;
		//curPosition[1] = t_gap*height/OUTPUT480_FULL_HEIGHT ;

        debug("savePosition----->start, left=" + l + ", top=" + t + ", right=" + r + ", bottom=" + b);
        switch (curoutputmode) {
            case 0://1080p
            case 1://1080p50hz
            case 2://1080p30hz
            case 3://1080p25hz*1
            case 4://1080p24hz
                x = String.valueOf(l*margin_init_2);
                y = String.valueOf(t*margin_init_2);
                w = String.valueOf(1920-((l+r)*margin_init_2)-1);
                h = String.valueOf(1080-((t+b)*margin_init_2)-1);
                setProperty(sel_1080poutput_x, x);
                setProperty(sel_1080poutput_y, y);
                setProperty(sel_1080poutput_width, w);
                setProperty(sel_1080poutput_height, h);
                break;
            case 5://1080i
            case 6://1080i50hz
                x = String.valueOf(l*margin_init_2);
                y = String.valueOf(t*margin_init_2);
                w = String.valueOf(1920-((l+r)*margin_init_2)-1);
                h = String.valueOf(1080-((t+b)*margin_init_2)-1);
                setProperty(sel_1080ioutput_x, x);
                setProperty(sel_1080ioutput_y, y);
                setProperty(sel_1080ioutput_width, w);
                setProperty(sel_1080ioutput_height, h);
                break;
            case 7: // 720p
            case 8:
                x = String.valueOf(l);
                y = String.valueOf(t);
                w = String.valueOf(1280-((l+r))-1);
                h = String.valueOf(720-((t+b))-1);				
                setProperty(sel_720poutput_x, x);
                setProperty(sel_720poutput_y, y);
                setProperty(sel_720poutput_width, w);
                setProperty(sel_720poutput_height, h);
                break;
            case 9: // 576p
                x = String.valueOf(l);
                y = String.valueOf(t);
                w = String.valueOf(720-(l+r)-1);
                h = String.valueOf(576-(t+b)-1);		
                setProperty(sel_576poutput_x, x);
                setProperty(sel_576poutput_y, y);
                setProperty(sel_576poutput_width, w);
                setProperty(sel_576poutput_height, h);
                break;
            case 10: // 480p
                x = String.valueOf(l);
                y = String.valueOf(t);
                w = String.valueOf(720-(l+r)-1);
                h = String.valueOf(480-(t+b)-1);		
                setProperty(sel_480poutput_x, x);
                setProperty(sel_480poutput_y, y);
                setProperty(sel_480poutput_width, w);
                setProperty(sel_480poutput_height, h);
                break;
            case 11: // 576i
                x = String.valueOf(l);
                y = String.valueOf(t);
                w = String.valueOf(720-(l+r)-1);
                h = String.valueOf(576-(t+b)-1);
                setProperty(sel_576ioutput_x, x);
                setProperty(sel_576ioutput_y, y);
                setProperty(sel_576ioutput_width, w);
                setProperty(sel_576ioutput_height, h);
                break;
            case 12: // 480i
                x = String.valueOf(l);
                y = String.valueOf(t);
                w = String.valueOf(720-(l+r)-1);
                h = String.valueOf(480-(t+b)-1);	
                setProperty(sel_480ioutput_x, x);
                setProperty(sel_480ioutput_y, y);
                setProperty(sel_480ioutput_width, w);
                setProperty(sel_480ioutput_height, h);
                break;
            case DISPLAY_STANDARD_3840_2160P_24:
            case DISPLAY_STANDARD_3840_2160P_25:
            case DISPLAY_STANDARD_3840_2160P_30:
            case DISPLAY_STANDARD_3840_2160P_60:
                x = String.valueOf(l*margin_init_5);
                y = String.valueOf(t*margin_init_5);
                w = String.valueOf(3840-((l+r)*margin_init_5)-1);
                h = String.valueOf(2160-((t+b)*margin_init_5)-1);	
                setProperty(sel_4k2koutput_x, x);
                setProperty(sel_4k2koutput_y, y);
                setProperty(sel_4k2koutput_width, w);
                setProperty(sel_4k2koutput_height, h);
                break;
            case DISPLAY_STANDARD_4096_2160P_24:
            case DISPLAY_STANDARD_4096_2160P_25:
            case DISPLAY_STANDARD_4096_2160P_30:
            case DISPLAY_STANDARD_4096_2160P_60:
                x = String.valueOf(l*margin_init_5);
                y = String.valueOf(t*margin_init_5);
                w = String.valueOf(4096-((l+r)*margin_init_5)-1);
                h = String.valueOf(2160-((t+b)*margin_init_5)-1);	
                setProperty(sel_4k2ksmpteoutput_x, x);
                setProperty(sel_4k2ksmpteoutput_y, y);
                setProperty(sel_4k2ksmpteoutput_width, w);
                setProperty(sel_4k2ksmpteoutput_height, h);
                break;
        }

    }


/*	public void saveParams() {
		Log.d(TAG,"=========saveParams, left:" + ls + ", top:" + ts + ", right:" + rs + ", bottom: " + bs);        
		mProgressHandler.removeMessages(SAVE_PARAMETER);        
		mProgressHandler.sendEmptyMessageDelayed(SAVE_PARAMETER, DELAY);
	}

	 private class DelayedHandler extends Handler {
	    @Override
	        public void handleMessage(Message msg) {
	            super.handleMessage(msg);
	            switch(msg.what){
				case 0:
					savePosition(ls, ts, rs, bs); 
					break;
				default:
					break;
	            }
	            
	            }
					
	    }

	private void savePosition(String x, String y, String w, String h) {
			int index = 4; // 720p
			String mCurMode = getCurrentOutputResolution();
			for (int i = 0; i < outputmode_array.length; i++) {
				if (mCurMode.equalsIgnoreCase(outputmode_array[i])) {
					index = i;
				}
			}
	
			switch (index) {
				case 0://1080p
				case 1://1080p50hz
				case 2://1080p30hz
				case 3://1080p25hz
				case 4://1080p24hz
					setProperty(sel_1080poutput_x, x);
					setProperty(sel_1080poutput_y, y);
					setProperty(sel_1080poutput_width, w);
					setProperty(sel_1080poutput_height, h);
					break;
				case 5://1080i
				case 6://1080i50hz
					setProperty(sel_1080ioutput_x, x);
					setProperty(sel_1080ioutput_y, y);
					setProperty(sel_1080ioutput_width, w);
					setProperty(sel_1080ioutput_height, h);
					break;
				case 7: // 720p
				case 8:
					setProperty(sel_720poutput_x, x);
					setProperty(sel_720poutput_y, y);
					setProperty(sel_720poutput_width, w);
					setProperty(sel_720poutput_height, h);
					break;
				case 9: // 576p
					setProperty(sel_576poutput_x, x);
					setProperty(sel_576poutput_y, y);
					setProperty(sel_576poutput_width, w);
					setProperty(sel_576poutput_height, h);
					break;
				case 10: // 480p
					setProperty(sel_480poutput_x, x);
					setProperty(sel_480poutput_x, y);
					setProperty(sel_480poutput_width, w);
					setProperty(sel_480poutput_height, h);
					break;
				case 11: // 576i
					setProperty(sel_576ioutput_x, x);
					setProperty(sel_576ioutput_y, y);
					setProperty(sel_576ioutput_width, w);
					setProperty(sel_576ioutput_height, h);
					break;
				case 12: // 480i
					setProperty(sel_480ioutput_x, x);
					setProperty(sel_480ioutput_y, y);
					setProperty(sel_480ioutput_width, w);
					setProperty(sel_480ioutput_height, h);
					break;
									
			}
    }
*/
    public int[] getScreenMargin() {
		int width = 1280;
        int height = 720;
        int waxis[] = {0, 0, 0, 0};
		
        String waxisStr = readSysfs(window_axis);
        String[] waxisArray = waxisStr.split(" ");
        for (int i=0; i<waxisArray.length; i++) {
            if(i == waxis.length){
                break;
            }
            try {
                waxis[i] = Integer.parseInt(waxisArray[i]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }	

		int curoutputmode = getCurrentStandard();
        switch (curoutputmode) {
            case 0://1080p
            case 1://1080p50hz
            case 2://1080p30hz
            case 3://1080p25hz
            case 4://1080p24hz
            case 5://1080i
            case 6://1080i50hz
                width = 1920;
                height = 1080;
                l_gap = waxis[0]/margin_init_2;
                t_gap = waxis[1]/margin_init_2;
                r_gap = (width - waxis[2]-1)/margin_init_2;
                b_gap = (height - waxis[3]-1)/margin_init_2;
                break;
            case 7: // 720p
            case 8:
                width = 1280;
                height = 720;
                l_gap = waxis[0];
                t_gap = waxis[1];
                r_gap = (width - waxis[2]-1);
                b_gap = (height - waxis[3]-1);				
                break;
            case 9: // 576p
                width = 720;
                height = 576;
                l_gap = waxis[0];
                t_gap = waxis[1];
                r_gap = (width - waxis[2]-1);
                b_gap = (height - waxis[3]-1);				
                break;
            case 10: // 480p
                width = 720;
                height = 480;
                l_gap = waxis[0];
                t_gap = waxis[1];
                r_gap = (width - waxis[2]-1);
                b_gap = (height - waxis[3]-1);				
                break;
            case 11: // 576i
                width = 720;
                height = 576;
                l_gap = waxis[0];
                t_gap = waxis[1];
                r_gap = (width - waxis[2]-1);
                b_gap = (height - waxis[3]-1);				
                break;
            case 12: // 480i
                width = 720;
                height = 480;
                l_gap = waxis[0];
                t_gap = waxis[1];
                r_gap = (width - waxis[2]-1);
                b_gap = (height - waxis[3]-1);				
                break;
            case DISPLAY_STANDARD_3840_2160P_24:
            case DISPLAY_STANDARD_3840_2160P_25:
            case DISPLAY_STANDARD_3840_2160P_30:
            case DISPLAY_STANDARD_3840_2160P_60:
                width = 3840;
                height = 2160;
                l_gap = waxis[0]/margin_init_5;
                t_gap = waxis[1]/margin_init_5;
                r_gap = (width - waxis[2]-1)/margin_init_5;
                b_gap = (height - waxis[3]-1)/margin_init_5;				
                break;
            case DISPLAY_STANDARD_4096_2160P_24:
            case DISPLAY_STANDARD_4096_2160P_25:
            case DISPLAY_STANDARD_4096_2160P_30:
            case DISPLAY_STANDARD_4096_2160P_60:
             	width = 4096;
             	height = 2160;
                l_gap = waxis[0]/margin_init_5;
                t_gap = waxis[1]/margin_init_5;
                r_gap = (width - waxis[2]-1)/margin_init_5;
                b_gap = (height - waxis[3]-1)/margin_init_5;				
                break;
            default:
                l_gap = waxis[0]*OUTPUT480_FULL_WIDTH/width;
                t_gap = waxis[1]*OUTPUT480_FULL_HEIGHT/height;
                r_gap = (width - waxis[2]-1)*OUTPUT480_FULL_WIDTH/width;
                b_gap = (height - waxis[3]-1)*OUTPUT480_FULL_HEIGHT/height;
				break;
        }


        debug("current postion : left=" + waxis[0]+", top="+ waxis[1]+", rigth=" + waxis[2]+",bottom="+waxis[3]);
        debug("current postion : l_gap=" + l_gap+", t_gap="+ t_gap+", r_gap=" + r_gap+",b_gap="+b_gap);
        return new int[] {l_gap , t_gap, r_gap, b_gap};
    }



   public boolean isTVSupport3D() {
	String status = readSysfs("/sys/class/amhdmitx/amhdmitx0/support_3d");		  
	if (null == status || "1".equals(status))			   
		return true; 	   
	else 		  
		return false;	   
   }

//20170925,colorspace start
    public void checkColorSpaceMode(String new_mode){

        String color_mode = getColorspaceMode();

        if(isColorSpaceSupport(new_mode, color_mode) == false){
            color_mode = getAutoColorMode(new_mode);
            Slog.d(TAG , "don't support current color mode ,  switch to : " + color_mode);
            if (!Settings.Secure.putString(mContext.getContentResolver(), Settings.Secure.COLOR_SPACE_MODE, color_mode)) {
                Slog.e(TAG, "Settings.Secure.putInt(color_space_mode) error!  " + color_mode);
            }
        }

    }

    public boolean isColorSpaceSupport(String hdmimode, String mode){

        if(mode == null || isTvSupportColor(mode) == false){
            Slog.d(TAG , "isColorSpaceSupport dont't support: " + mode);
            return false;
        }

        Boolean boolSupport = false;
        String curMode = hdmimode;
		int type = convertColorSpace(mode);
            switch (type){
	        case COLOR_SPACE_YUV_420_8BIT:
            case COLOR_SPACE_YUV_420_10BIT:
                 if(curMode.equals(HDMI_MODE_2160P50HZ420) ||
                       curMode.equals(HDMI_MODE_2160P60HZ420) ||
                       curMode.equals(HDMI_MODE_2160P50HZ42010BIT) ||
                       curMode.equals(HDMI_MODE_2160P60HZ42010BIT) ){
                       boolSupport = true;
                       break;
                 }
                 break;
            case COLOR_SPACE_YUV_444_8BIT:
                 if(curMode.equals(HDMI_MODE_2160P50HZ420) ||
                       curMode.equals(HDMI_MODE_2160P60HZ420) ||
                       curMode.equals(HDMI_MODE_2160P50HZ42010BIT) ||
                       curMode.equals(HDMI_MODE_2160P60HZ42010BIT) ){
                       boolSupport = false;
                       break;
                 }
                 boolSupport = true;
                 break;
            case COLOR_SPACE_YUV_422_12BIT:
                 if(curMode.equals(HDMI_MODE_2160P50HZ) ||
                       curMode.equals(HDMI_MODE_2160P60HZ) ||
                       curMode.equals(HDMI_MODE_2160P50HZ42212BIT) ||
                       curMode.equals(HDMI_MODE_2160P60HZ42212BIT) ){
                       boolSupport = true;
                       break;
                 }
                 boolSupport = false;
				 break;
            case COLOR_SPACE_AUTO:
                 boolSupport = true;
                 break;
			default:
			        break;
        }

        Slog.d(TAG , "hdmimode:" + curMode + " ,isColorSpaceSupport: " + mode + " ,boolSupport:" + boolSupport);

        return boolSupport;
    }

    public boolean isTvSupportColor(String mode){
        Slog.d(TAG , "isColorSpaceSupport: " + mode);
        if(mode == null)
            return false;

        if(mode.contains(COLORSPACE_MODE_Y420_8BIT) ||
            mode.contains(COLORSPACE_MODE_Y444_8BIT) ||
            mode.contains("Auto")){
            return true;
        }

        ArrayList<String> mOutput10bitModeList = read10bitList();
        int size = mOutput10bitModeList.size();
        for (int index = 0; index < size; index++) {
             String output10bitcolor = mOutput10bitModeList.get(index);
             Slog.d(TAG , "output10bitcolor is : "+output10bitcolor);
             if(output10bitcolor.contains(mode)){
                 Slog.d(TAG , "Support : " + mode);
                 return true;
             }
        }

        return false;

    }

    public String getColorspaceMode(){
        String colorMode = null;
        colorMode = Settings.Secure.getString(mContext.getContentResolver(), Settings.Secure.COLOR_SPACE_MODE);
        Slog.i(TAG, "getColorspaceMode: " + colorMode);
        return colorMode;
   }

    private  String getAutoColorMode(String mode){

	    String colormode = COLORSPACE_MODE_Y444_8BIT;

        Slog.e(TAG, "getCurrent_AutoSpaceMode HDMI mode :" + mode);

        if(mode.contains("2160p50") || mode.contains("2160p60")){
            if(isColorSpaceSupport(mode, COLORSPACE_MODE_Y420_10BIT)){
                colormode = COLORSPACE_MODE_Y420_10BIT;
            }else if(isColorSpaceSupport(mode, COLORSPACE_MODE_Y420_8BIT)){
                colormode = COLORSPACE_MODE_Y420_8BIT;
            }
	    }

        Slog.e(TAG, "getCurrent_AutoSpaceMode color space mode :" + colormode);

        return colormode;

    }

    private int convertColorSpace(String color_mode){
	   int type = COLOR_SPACE_UNKNOWN;
	   Slog.d(TAG,"convertColorSpace orig:" + color_mode);
	   if(color_mode == null)
	       return type;

	   if(color_mode.contains("Y444 10bit")){
           type = COLOR_SPACE_YUV_444_10BIT;
	   }else if(color_mode.contains("Y422 10bit")){
           type = COLOR_SPACE_YUV_422_10BIT;
	   }else if(color_mode.contains("Y420 10bit")){
           type = COLOR_SPACE_YUV_420_10BIT;
	   }else if(color_mode.contains("Y444 12bit")){
           type = COLOR_SPACE_YUV_444_12BIT;
	   }else if(color_mode.contains("Y422 12bit")){
           type = COLOR_SPACE_YUV_422_12BIT;
	   }else if(color_mode.contains("Y420 12bit")){
           type = COLOR_SPACE_YUV_420_12BIT;
	   }else if(color_mode.contains("Y444 8bit")){
           type = COLOR_SPACE_YUV_444_8BIT;
	   }else if(color_mode.contains("Y422 8bit")){
           type = COLOR_SPACE_YUV_422_8BIT;
	   }else if(color_mode.contains("Y420 8bit")){
           type = COLOR_SPACE_YUV_420_8BIT;
	   }else if(color_mode.contains("RGB 10bit")){
           type = COLOR_SPACE_RGB_10BIT;
	   }else if(color_mode.contains("RGB 12bit")){
           type = COLOR_SPACE_RGB_12BIT;
	   }else if(color_mode.contains("RGB 8bit")){
           type = COLOR_SPACE_RGB_8BIT;
	   }else if(color_mode.contains("Auto")){
           type = COLOR_SPACE_AUTO;
	   }

       Slog.d(TAG,"convertColorSpace final:" + type);
       return type;

   }

    private ArrayList<String> read10bitList() {
        String str = null;
	 boolean support422 = false;
	 int index = -1 , size = -1;
        ArrayList<String> mOutput10bitModeList = new ArrayList<String>();
	 ArrayList<OutputMode> mOutputModeList = readSupportList();
        try {
            FileReader fr = new FileReader(HDMI_10bitSUPPORT_LIST_SYSFS);
            BufferedReader br = new BufferedReader(fr);
            try {
                while ((str = br.readLine()) != null) {
                    if(str != null){
                        /*if(DEBUG) */Slog.i(TAG, "DeepColor: " + str);
			    mOutput10bitModeList.add(str);
                    }
                }
                fr.close();
                br.close();
		 size = mOutput10bitModeList.size();
		 if(null != mOutputModeList && null != mOutput10bitModeList){
			for (index = 0; index < size; index++) {
				String colormode = mOutput10bitModeList.get(index);
				if (colormode.contains("Y422")){
					for(int i  = 0 ; i < mOutputModeList.size() ; i++){
						OutputMode getmode = mOutputModeList.get(i);
						if(getmode.mode.equals("2160p60hz") || getmode.mode.equals("2160p50hz")){
							support422 = true;
							break;
						}
					}
					if(support422)
						break;
					else{
						mOutput10bitModeList.remove(index);
						index =  index -1;
						size = mOutput10bitModeList.size();
					}
				}
			}
		 }
		 if(getPropertyBoolean("sys.color.supportdebug" , false)){
			for(int i = 0 ; i < mOutput10bitModeList.size() ; i++){
				Slog.d(TAG , "== in read10bitList=="+mOutput10bitModeList.get(i));
			}
		 }
                return mOutput10bitModeList;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    private ArrayList<OutputMode> readSupportList() {
        String str = null;
        ArrayList<OutputMode> mOutputModeList = new ArrayList<OutputMode>();
        try {
            FileReader fr = new FileReader(HDMI_SUPPORT_LIST_SYSFS);
            BufferedReader br = new BufferedReader(fr);
            try {
                while ((str = br.readLine()) != null) {
                    if(str != null){
                        //if(DEBUG) Slog.i(TAG, "Output: " + str);
                        OutputMode output = new OutputMode();
                        if(str.contains("null edid")) {
                            Slog.w(TAG, "readSupportList error, disp_cap: " + str);
                            return null;
                        }
                        if(str.contains("*")) {
                            output.mode = new String(str.substring(0, str.length()-1));
                            output.isBestMode = true;
                        } else {
                            output.mode = new String(str);
                            output.isBestMode = false;
                        }
                        //if(DEBUG) Slog.i(TAG, "readSupportList, Output: " + output.mode + ", isBestMode: " + output.isBestMode);
                        if(isOutputFilter(output.mode)) {
                            Slog.w(TAG, "readSupportList, filter this mode: " + output.mode);
                        } else {
                            mOutputModeList.add(output);
                        }
                    }
                };
                fr.close();
                br.close();
                return mOutputModeList;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean isOutputFilter(String mode) {
        if(filterModesAray != null) {
            int size = filterModesAray.length;
            for(int i=0; i<size; i++) {
                if((filterModesAray[i] != null) && (filterModesAray[i].equals(mode)))
                    return true;
            }
        }
        return false;
    }

    //switchcolorspacemode
    private String switchColorSpaceMode(String curMode){

     if(curMode == null){
         return null;
     }

	 String switch_mode = null;
	 String color_mode = getColorspaceMode();
	 Slog.i(TAG, "getColorspaceMode color_mode : " + color_mode);

        if(color_mode != null  && color_mode.contains("Auto")){
          color_mode = getAutoColorMode(curMode);
          Slog.i(TAG, "getColorspaceMode Auto switch to:" + color_mode);
	 }

     if(getPropertyBoolean("sys.output.10bit" , false) && isColorSpaceSupport(curMode, color_mode)){
	     int type = convertColorSpace(color_mode);
            switch (type){
	     case COLOR_SPACE_YUV_420_8BIT:
                    if(curMode.contains("2160p50")){
                         switch_mode = "2160p50hz420";
                    }else if(curMode.contains("2160p60")){
                         switch_mode = "2160p60hz420";
                    }
		 break;
            case COLOR_SPACE_YUV_420_10BIT:
                    if(curMode.contains("10bit")){
                         Slog.w(TAG, "curMode use : " + curMode);
                         switch_mode =  curMode;
                    }else if(curMode.contains("2160p50")){
                         switch_mode =  "2160p50hz42010bit";
                    }else if(curMode.contains("2160p60")){
                         switch_mode =   "2160p60hz42010bit";
                    }
                break;
            case COLOR_SPACE_YUV_422_12BIT:
                    if(curMode.contains("12bit")){
                         Slog.w(TAG, "curMode use : " + curMode);
                         switch_mode =  curMode;
                    }else if(curMode.contains("2160p50")){
                         switch_mode =  "2160p50hz42212bit";
                    }else if(curMode.contains("2160p60")){
                         switch_mode =  "2160p60hz42212bit";
                    }
                break;
            case COLOR_SPACE_YUV_444_8BIT:
                    if(curMode.contains("2160p50")){
                        switch_mode = "2160p50hz";
                    }else if(curMode.contains("2160p60")){
                        switch_mode = "2160p60hz";
                    }
                    if (!isSupported(switch_mode)){
                        switch_mode = null;
                    }

                    break;
            case COLOR_SPACE_AUTO:
                    Slog.e(TAG,"COLOR_SPACE_AUTO Code error.\n");
                    break;
            }

	}

      Slog.d(TAG,"switchColorSpaceMode : " + switch_mode);

      return switch_mode;
   }

    public boolean isSupported(String mode){
        ArrayList<OutputMode> mOutputModeList = readSupportList();
        int size = mOutputModeList.size();
        for (int index = 0; index < size; index++) {
            OutputMode output = mOutputModeList.get(index);
            if (mode != null && output.mode.equals(mode)){
                Slog.i(TAG, "supported :: " + mode);
                return true;
             }
        }
        return false;
    }

    private class OutputMode {
        public String mode;
        public boolean isBestMode;
    }
//

    public void setHDMIPassThrough(int mode) {
	  Log.d(TAG,"[setHDMIPassThrough] mode: " + mode);
	  if(DisplayManager.DISPLAY_HDMI_MODE_PCM == mode){
	  	setDigitalVoiceValueMode("HDMI Only PCM");
	  }else if(DisplayManager.DISPLAY_HDMI_MODE_RAW == mode) {
	  	setDigitalVoiceValueMode("HDMI Only Passthrough");
	  }else if(DisplayManager.DISPLAY_HDMI_MODE_AUTO == mode) {
	  	setDigitalVoiceValueMode("HDMI Only Auto");
	  }
    }


    public void setSPDFPassThrough(int mode) {
	  Log.d(TAG,"[setSPDFPassThrough] mode: " + mode);
	  /*String originalValue = getProperty(PASSTHROUGH_PROPERTY);
	  if("HDMI Only Auto".equals(originalValue))
	  	return;
	  if(DisplayManager.DISPLAY_SPDIF_MODE_PCM == mode) {
	  	if("HDMI Only PCM".equals(originalValue))
			setDigitalVoiceValueMode("PCM");
	  }else if(DisplayManager.DISPLAY_SPDIF_MODE_RAW == mode) {
	  	if("HDMI Only Passthrough".equals(originalValue))
			setDigitalVoiceValueMode("HDMI&SPDIF Passthrough");
		else
			setDigitalVoiceValueMode("SPDIF passthrough");
	  }*/
    }

   /** @return  -99 CEC or HotPlug TV not	`t support
   *                 -1  hdmi not connect
   *                 0    TV is on Standby
   *                 1     Tv is boot
   */
    public int getTVState() {
        if (isTvSupportCec()) {
            if(!isHDMIPlugged())
                return -1;
            else {
                if (isTVStandby()) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if(!isHDMIPlugged())
                return -1;
            else {
                if (isTVStandby()) {
                    return 0;
                } else {
                    return -99;
                }
            }
        }
    }

    public byte[] getTVEDID() {
        byte[] edids = null;

        try {
            edids = toByteArray(HDMI_EDID_PATH);
        }catch (Exception ex) {
            ex.printStackTrace();
        }
	
	    return edids;
    }

  private static byte[] toByteArray(String filename) throws IOException {  
  
        File f = new File(filename);  
        if (!f.exists()) {  
            throw new FileNotFoundException(filename);  
        }  
  
        ByteArrayOutputStream bos = new ByteArrayOutputStream((int) f.length());
        BufferedInputStream in = null;
        try {  
            in = new BufferedInputStream(new FileInputStream(f));
            int buf_size = 1024;  
            byte[] buffer = new byte[buf_size];  
            int len = 0;  
            while (-1 != (len = in.read(buffer, 0, buf_size))) {  
                bos.write(buffer, 0, len);  
            }  
            return bos.toByteArray();  
        } catch (IOException e) {  
            e.printStackTrace();  
            throw e;  
        } finally {  
            try {  
                in.close();  
            } catch (IOException e) {  
                e.printStackTrace();  
            }  
            bos.close();  
        }  
    }  

    private void setDigitalVoiceValueMode(String value) {
        // value: 
        // "HDMI Only PCM", "HDMI Only Passthrough"
        // "SPDIF Only PCM", "SPDIF Only Passthrough"
        // "HDMI&SPDIF PCM", "HDMI&SPDIF Passthrough"
        // "HDMI&SPDIF Mute", "HDMI Only Auto"
        setProperty(PASSTHROUGH_PROPERTY, value);
        String spdif_node = get_spdif_node();

        if ("HDMI Only PCM".equals(value)) {
            writeSysfs(DigitalRawFile, "0");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
            writeSysfs(spdif_node, "spdif_mute");
        } else if ("HDMI Only Passthrough".equals(value)) {
            writeSysfs(DigitalRawFile, "2");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
            writeSysfs(spdif_node, "spdif_mute");
        } else if ("SPDIF Only PCM".equals(value)) {
            writeSysfs(DigitalRawFile, "0");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_off");
            writeSysfs(spdif_node, "spdif_unmute");
        } else if ("SPDIF Only Passthrough".equals(value)) {
            writeSysfs(DigitalRawFile, "1");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_off");
            writeSysfs(spdif_node, "spdif_unmute");
        } else if ("HDMI&SPDIF PCM".equals(value)) {
            writeSysfs(DigitalRawFile, "0");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
            writeSysfs(spdif_node, "spdif_unmute");
        } else if ("HDMI&SPDIF Passthrough".equals(value)) {
            writeSysfs(DigitalRawFile, "1");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
            writeSysfs(spdif_node, "spdif_unmute");
        } else if ("HDMI&SPDIF Mute".equals(value)) {
            writeSysfs(DigitalRawFile, "0");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_off");
            writeSysfs(spdif_node, "spdif_mute");
        } else if ("HDMI Only Auto".equals(value)) {
            String mAudioCapInfo = readSysfs(mAudoCapFile);
            if(mAudioCapInfo.contains("Dobly_Digital+")) {
                writeSysfs(DigitalRawFile, "2");
                writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
                writeSysfs(spdif_node, "spdif_mute");
            } else if(mAudioCapInfo.contains("AC-3")) {
                writeSysfs(DigitalRawFile, "1");
                writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
                writeSysfs(spdif_node, "spdif_unmute");
            } else {
                writeSysfs(DigitalRawFile, "0");
                writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
                writeSysfs(spdif_node, "spdif_mute");
            }
        } else {
            setDigitalVoiceValueCommon(value);
        }
    }

    private String get_spdif_node(){
	  File dir = new File(SYS_DEVICES);
	  File[] files = dir.listFiles(); 
	  for(int i = 0; i < files.length; i++) {
   		if(files[i].getName().contains("spdif")){
       		Slog.i(TAG, "find spdif:" + files[i]);
       		return SYS_DEVICES + files[i].getName() + "/spdif_mute";
   		}
	  }
	  return "none";
    }
	
    private void setDigitalVoiceValueCommon(String value) {
        // value: "PCM", "RAW", "SPDIF passthrough", "HDMI passthrough"
        setProperty(PASSTHROUGH_PROPERTY, value);
        String spdif_node = get_spdif_node();

        if ("PCM".equals(value)) {
            writeSysfs(DigitalRawFile, "0");
            writeSysfs(spdif_node, "spdif_unmute");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
        } else if ("RAW".equals(value)) {
            writeSysfs(DigitalRawFile, "1");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_off");
            writeSysfs(spdif_node, "spdif_unmute");
        } else if ("SPDIF passthrough".equals(value)) {
            writeSysfs(DigitalRawFile, "1");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_off");
            writeSysfs(spdif_node, "spdif_unmute");
        } else if ("HDMI passthrough".equals(value)) {
            writeSysfs(DigitalRawFile, "2");
            writeSysfs(spdif_node, "spdif_mute");
            writeSysfs(HDMI_AUIDO_SWITCH, "audio_on");
        }
    }

    public boolean isTvSupportCec() {
        String status = sw.readSysfs(TV_SUPPORT_CEC);//"/sys/class/amhdmitx/amhdmitx0/tv_support_cec";
        Slog.i(TAG, "tv_support_cec:" + status);
        if ("1".equals(status) || !isHDMIPlugged())
            return true;
        else
            return false;
    }
	
    private void initStep(String mode) {
        /**
        if(mode.contains("480")){
            zoomStepWidth = 1.25f;
        }else  if(mode.contains("576")){
//            zoomStepWidth = 1.25f ;
            zoomStepWidth = 1.5f
        }else  if(mode.contains("720")){
//            zoomStepWidth = 1.78f ;
            zoomStepWidth = 1.75f ;
        }else  if(mode.contains("1080")){
//            zoomStepWidth = 1.78f ;
            zoomStepWidth = 2.0f ;
        }else if (mode.contains("2160")){
            // there should set value
//            zoomStepWidth = 1.80f;
            zoomStepWidth = 2.25f ;
        }else if (mode.contains("smpte")){
            zoomStepWidth = 2.5f;
        }
        */
        zoomStepWidth = 1.5f;
    }

     private String getCurrentOutputResolution() {
         String mode = readSysfs(mCurrentResolution);

         if ("480cvbs".equalsIgnoreCase(mode)) {
             mode = "480i";
         } else if ("576cvbs".equalsIgnoreCase(mode)) {
             mode = "576i";
         }
         return mode;
    }

    private String getProperty(String key){
        return SystemProperties.get(key);
    }

    private String getPropertyString(String key,String def){
        return SystemProperties.get(key,def);
    }

    private int getPropertyInt(String key,int def){
        return SystemProperties.getInt(key,def);
    }

    private long getPropertyLong(String key,long def){
        return SystemProperties.getLong(key,def);
    }
     
    private boolean getPropertyBoolean(String key,boolean def){
        return SystemProperties.getBoolean(key,def);
    }    
     
    private void setProperty(String key, String value){
        SystemProperties.set(key,value);
    }
     
    private String readSysfs(String path) {
        if (!new File(path).exists()) {
            debug("readSysfs----->File not found: " + path);
            return null; 
        }

        String str = null;
        StringBuilder value = new StringBuilder();
        try {
            FileReader fr = new FileReader(path);
            BufferedReader br = new BufferedReader(fr);
            try {
                while ((str = br.readLine()) != null) {
                    if(str != null){
                        value.append(str);
                    }
                };
                fr.close();
                br.close();
                if(value != null){
                    return value.toString();
                }
                else {
                    return null;
                }
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean writeSysfs(String path, String value) {
        if (!new File(path).exists()) {
            debug("writeSysfs---->File not found: " + path);
            return false; 
        }
        
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(path), 64);
            try {
                writer.write(value);
            } finally {
                writer.close();
            }           
            return true;

        } catch (IOException e) { 
            debug("writeSysfs----->IO Exception when write: " + path +"exction :" + e);
            return false;
        }
    }
}
