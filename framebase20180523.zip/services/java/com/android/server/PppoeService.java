/*
 * Copyright (C) 2009 The Android-x86 Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Author: Yi Sun <beyounn@gmail.com>
 */

package com.android.server;

import java.net.UnknownHostException;
import android.net.pppoe.PppoeNative;
import android.net.pppoe.IPppoeManager;
import android.net.pppoe.PppoeManager;
import android.net.pppoe.PppoeStateTracker;
import android.net.pppoe.PppoeDevInfo;
import android.provider.Settings;
import android.util.Slog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.PowerManager;
import android.os.SystemProperties;
import android.os.Handler;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import android.net.DhcpInfo;

public class PppoeService<syncronized> extends IPppoeManager.Stub{
    private Context mContext;
    private PppoeStateTracker mTracker;
    private String[] DevName;
    private static final String TAG = "PppoeService";
    private int isPppoeEnabled ;
    private int mPppoeState= PppoeManager.PPPOE_STATE_UNKNOWN;
    private PowerManager.WakeLock mWakeLock = null;
    private Handler mDelayedHandler; 

    public PppoeService(Context context, PppoeStateTracker Tracker){
        mTracker = Tracker;
        mContext = context;
        mWakeLock = ((PowerManager)mContext.getSystemService(Context.POWER_SERVICE)).newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, TAG);
        wakeLock();
        isPppoeEnabled = getPersistedState();
        Slog.i(TAG,"Pppoe dev enabled " + isPppoeEnabled );
        getDeviceNameList();
        setPppoeState(isPppoeEnabled);
        registerForBroadcasts();
        Slog.i(TAG, "Trigger the pppoe monitor");
        mTracker.StartPolling();
        mDelayedHandler = new Handler();  
    }

    public boolean isPppoeConfigured() {
        final ContentResolver cr = mContext.getContentResolver();
        int x = Settings.Secure.getInt(cr, Settings.Secure.PPPOE_CONF,0);
        if (x == 0) {
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_IP, "0.0.0.0");
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_DNS1, "0.0.0.0");
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_DNS2, "0.0.0.0");
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_MASK, "255.255.255.0");
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_ROUTE, "0.0.0.0");

            Slog.i(TAG, "@@@@@@NO CONFIG. set default");
            Settings.Secure.putInt(cr, Settings.Secure.PPPOE_CONF, 1);
        }
        x = Settings.Secure.getInt(cr, Settings.Secure.PPPOE_CONF,0);
        if (x == 1)
            return true;
        return false;
    }

    public synchronized PppoeDevInfo getSavedPppoeConfig() {
        if (isPppoeConfigured() ) {
            final ContentResolver cr = mContext.getContentResolver();
            PppoeDevInfo info = new PppoeDevInfo();
            info.setIfName(Settings.Secure.getString(cr, Settings.Secure.PPPOE_ITF));
            info.setAccount(Settings.Secure.getString(cr, Settings.Secure.PPPOE_USR));
            info.setPassword(Settings.Secure.getString(cr, Settings.Secure.PPPOE_PWD));
            info.setWifissid(Settings.Secure.getString(cr, Settings.Secure.PPPOE_SSID));
            info.setIpAddress(Settings.Secure.getString(cr, Settings.Secure.PPPOE_IP));
            info.setDns1Addr(Settings.Secure.getString(cr, Settings.Secure.PPPOE_DNS1));
            info.setDns2Addr(Settings.Secure.getString(cr, Settings.Secure.PPPOE_DNS2));
            info.setNetMask(Settings.Secure.getString(cr, Settings.Secure.PPPOE_MASK));
            info.setRouteAddr(Settings.Secure.getString(cr, Settings.Secure.PPPOE_ROUTE));
            info.setDialMode(Settings.Secure.getString(cr, Settings.Secure.PPPOE_AUTOD));
            Slog.i(TAG, "getSavedPppoeConfig, info is " + info.toString());
            return info;
        }
        return null;
    }

    public synchronized void setPppoeMode(String mode) {
        final ContentResolver cr = mContext.getContentResolver();
        Slog.i(TAG,"Set pppoe mode " + DevName + " mode " + mode);
    }

    public synchronized void UpdatePppoeDevInfo(PppoeDevInfo info) {
        Slog.i(TAG, "UpdatePppoeDevInfo, info is " + info.toString());
        final ContentResolver cr = mContext.getContentResolver();
        Settings.Secure.putInt(cr, Settings.Secure.PPPOE_CONF, 1);
        if(info.getIfName() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_ITF, info.getIfName());
        if(info.getAccount() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_USR, info.getAccount());
        if(info.getPassword() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_PWD, info.getPassword());
        if(info.getWifissid() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_SSID, info.getWifissid());
        if(info.getIpAddress() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_IP, info.getIpAddress());
        if(info.getDns1Addr() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_DNS1, info.getDns1Addr());
        if(info.getDns2Addr() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_DNS2, info.getDns2Addr());
        if(info.getRouteAddr() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_ROUTE, info.getRouteAddr());
        if(info.getNetMask() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_MASK,info.getNetMask());
        if(info.getDialMode() != null)
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_AUTOD, info.getDialMode());
    }

    public synchronized void connect(String username, String password, String ifaceName, String dialmode) {
        final ContentResolver cr = mContext.getContentResolver();
        if((username == null) || (password == null) || (ifaceName == null) || (dialmode == null)) {
            Slog.w(TAG, "connect() username, password, ifaceName or dialmode is null!");
        }

        if(!username.equals(Settings.Secure.getString(cr, Settings.Secure.PPPOE_USR))
                || !password.equals(Settings.Secure.getString(cr, Settings.Secure.PPPOE_PWD))
                || !ifaceName.equals(Settings.Secure.getString(cr, Settings.Secure.PPPOE_ITF))
              || !dialmode.equals(Settings.Secure.getString(cr, Settings.Secure.PPPOE_AUTOD))) {
            mTracker.disconnect(Settings.Secure.getString(cr, Settings.Secure.PPPOE_ITF));
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_USR, username);
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_PWD, password);
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_ITF, ifaceName);
            Settings.Secure.putString(cr, Settings.Secure.PPPOE_AUTOD, dialmode);
            if("eth0".equals(ifaceName)) {
                Settings.Secure.putString(cr, Settings.Secure.ETH_MODE, "pppoe");
            } 
        }
        mTracker.connect(username, password, ifaceName);
    }

    public synchronized void disconnect(String ifaceName) {
        if(ifaceName == null) {
            Slog.w(TAG, "disconnect() ifaceName is null!");
        }
        mTracker.disconnect(ifaceName);
    }

    public synchronized void terminate() {
        mTracker.terminate();
    }

    public synchronized int status() {
        return mTracker.status();
    }

    private void registerForBroadcasts() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        mContext.registerReceiver(mReceiver, intentFilter);
    }

    public int getTotalInterface() {
        return PppoeNative.getInterfaceCnt();
    }

    private int scanPppoeDevice() {
        int i = 0,j;
        if ((i = PppoeNative.getInterfaceCnt()) != 0) {
            Slog.i(TAG, "total found "+i+ " net devices");
            DevName = new String[i];
        }
        else
            return i;

        for (j = 0; j < i; j++) {
            DevName[j] = PppoeNative.getInterfaceName(j);
            if (DevName[j] == null)
                break;
            Slog.i(TAG,"device " + j + " name " + DevName[j]);
        }

        return i;
    }

    public String[] getDeviceNameList() {
        return (scanPppoeDevice() > 0 ) ? DevName : null;
    }

    private int getPersistedState() {
        final ContentResolver cr = mContext.getContentResolver();
        try {
            return Settings.Secure.getInt(cr, Settings.Secure.PPPOE_ON);
        } catch (Settings.SettingNotFoundException e) {
            return PppoeManager.PPPOE_STATE_UNKNOWN;
        }
    }

    private synchronized void persistPppoeEnabled(boolean enabled) {
        final ContentResolver cr = mContext.getContentResolver();
        Settings.Secure.putInt(cr, Settings.Secure.PPPOE_ON,
        enabled ? PppoeManager.PPPOE_STATE_ENABLED : PppoeManager.PPPOE_STATE_DISABLED);
    }
    
    private void pppoeConnect(String IfName) {
        PppoeDevInfo info = getSavedPppoeConfig();
        String usr = info.getAccount();
        String pwd = info.getPassword();
        String ifname = info.getIfName();
        String dialmode = info.getDialMode();
        Slog.i(TAG, "pppoeConnecting....., ifname: " + IfName);
        Slog.i(TAG, "Username:[" + usr + "], Password:[" + pwd 
            + "], ifname:[" + ifname + "], dialmode:[" + dialmode + "]");
        if ((IfName == null) || !IfName.equals(ifname)) {
            Slog.w(TAG, "INVALID IFNAME");
        } else if ((usr == null || usr.equals("")) || (pwd == null || pwd.equals(""))) {
            Slog.w(TAG, "INVALID USERNAME OR PASSWORD");
        } else if(!PppoeDevInfo.PPPOE_DIAL_MODE_AUTO.equals(dialmode)) {
            Slog.i(TAG, "not auto dial: " + dialmode);
        } else {
            mTracker.connect(usr, pwd, ifname);
        }
    }

    private final Runnable mResetInterface = new Runnable() {
        public void run() {
            try {
                mTracker.resetInterface();
                PppoeDevInfo info = getSavedPppoeConfig();
                pppoeConnect(info.getIfName());
            } catch (UnknownHostException e) {
                Slog.e(TAG, "Wrong pppoe configuration");
            }
        }
    };

    private final Runnable mUnlockTimeout = new Runnable() {
        public void run() {
            PppoeDevInfo info = getSavedPppoeConfig();
            String ifname = info.getIfName();
            if("wlan0".equals(ifname))
                mTracker.disconnect("wlan0");
            mDelayedHandler.postDelayed(mWakeUnlock, 1000);
        }
    };

    private final Runnable mWakeUnlock = new Runnable() {
        public void run() {
            mTracker.stopInterface(false);
            wakeUnlock();
        }
    };

    private void wakeLock() {
        if(!mWakeLock.isHeld())
            mWakeLock.acquire();
    }
    
    private void wakeUnlock() {
        if(mWakeLock.isHeld())
            mWakeLock.release();
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(Intent.ACTION_SCREEN_ON)) {
                Slog.d(TAG, "ACTION_SCREEN_ON");
                mDelayedHandler.removeCallbacks(mUnlockTimeout);
                if(mWakeLock.isHeld()) {
                    PppoeDevInfo info = getSavedPppoeConfig();
                    mTracker.disconnect(info.getIfName());
                    mTracker.stopInterface(false);
                }
                wakeLock();
                mDelayedHandler.postDelayed(mResetInterface, 500);
            } else if (action.equals(Intent.ACTION_SCREEN_OFF)) {
                int delaytime = SystemProperties.getInt("sys.supend.delaytime", 0);
                Slog.d(TAG, "ACTION_SCREEN_OFF delaytime: " + delaytime);
                mDelayedHandler.postDelayed(mUnlockTimeout, delaytime);
            }
        }
    };

    public synchronized void setPppoeState(int state) {
        Slog.i(TAG, "setPppoeState from " + mPppoeState + " to "+ state);

        if (mPppoeState != state){
            mPppoeState = state;
            if (state == PppoeManager.PPPOE_STATE_DISABLED) {
                persistPppoeEnabled(false);			
                new Thread("stopInterface") {
                    @Override
                    public void run() {
                        mTracker.stopInterface(false);
                    }
                }.start();
            } else {
                persistPppoeEnabled(true);
                if (!isPppoeConfigured()) {
                    // If user did not configure any interfaces yet, pick the first one
                    // and enable it.
                    setPppoeMode(PppoeDevInfo.PPPOE_CONN_MODE_DHCP);
                }
                new Thread("resetInterface") {
                    @Override
                    public void run() {
                        try {
                            mTracker.resetInterface();
                        } catch (UnknownHostException e) {
                            Slog.e(TAG, "Wrong pppoe configuration");
                        }
                    }
                }.start();
            }
        }
    }

    public int getPppoeState( ) {
        return mTracker.getPppoeState();
    }

    public boolean isPppoeDeviceUp( ) {
        try {
            boolean retval = false;
            FileReader fr = new FileReader("/sys/class/net/ppp0/operstate");
            BufferedReader br = new BufferedReader(fr, 32);
            String status = br.readLine();
            if (status != null && status.equals("up")) {
                Slog.d(TAG, "PppoeDevice status:" + status);
                retval = true;
            } else if (status != null && status.equals("down")) {
                Slog.d(TAG, "PppoeDevice status:" + status);
                retval = false;
            } else {
                retval =  false;
            }
            br.close();
            fr.close();
            return retval;
        } catch (IOException e) {
            Slog.d(TAG, "get PppoeDevice status error");
            return false;
        }
    }

    public DhcpInfo getDhcpInfo( ) {
        return mTracker.getDhcpInfo();
    }
}
