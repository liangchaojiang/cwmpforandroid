package android.net.vlan;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

import android.R;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothHeadset;
import android.content.Context;
import android.content.ContentResolver;
import android.content.Intent;
import android.provider.Settings;
import android.net.ConnectivityManager;
import android.net.vlan.VlanManager;
import android.net.ethernet.EthernetManager;
import android.net.ethernet.DualStackManager;
import android.net.pppoe.PppoeManager;
import android.net.DhcpInfo;
import android.net.DhcpInfoInternal;
import android.net.DhcpResults;
import android.net.InterfaceConfiguration;
import android.net.LinkAddress;
import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.net.LinkQualityInfo;
import android.net.NetworkStateTracker;
import android.net.NetworkUtils;
import android.net.NetworkInfo;
import android.net.NetworkInfo.DetailedState;
import android.net.pppoe.PppoeDevInfo;
import android.net.ProxyProperties;
import android.net.RouteInfo;
import android.net.SamplingDataTracker;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.INetworkManagementService;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.util.*;

/**
 * Track the state of Vlanernet connectivity. All event handling is done here,
 * and all changes in connectivity state are initiated here.
 *
 * @hide
 */
public class VlanStateTracker implements NetworkStateTracker {

    private static final String TAG="VlanStateTracker";

    public static final int EVENT_DHCP_START                        = 0;
    public static final int EVENT_INTERFACE_CONFIGURATION_SUCCEEDED = 1;
    public static final int EVENT_INTERFACE_CONFIGURATION_FAILED    = 2;
    public static final int EVENT_HW_CONNECTED                      = 3;
    public static final int EVENT_HW_DISCONNECTED                   = 4;
    public static final int EVENT_HW_PHYCONNECTED                   = 5;
    public static final int EVENT_HW_PHYDISCONNECTED                = 6;
    //temporary event for Settings until this supports multiple interfaces
    public static final int EVENT_HW_CHANGED                        = 7;
    public static final int EVENT_DEVICE_ADDED                      = 8;
    public static final int EVENT_DEVICE_REMOVED                    = 9;
    public static final int EVENT_IP_REMOVED                        = 10;
    public static final int EVENT_REQUEST_RESET                  = 11;
    private VlanManager mVM;
    private PppoeManager mPppoeManager;
    private boolean mServiceStarted;

    private AtomicBoolean mTeardownRequested = new AtomicBoolean(false);
    private AtomicBoolean mPrivateDnsRouteSet = new AtomicBoolean(false);
    private AtomicBoolean mDefaultRouteSet = new AtomicBoolean(false);

    private LinkProperties mLinkProperties;
    private LinkCapabilities mLinkCapabilities;
    private NetworkInfo mNetworkInfo;
    private NetworkInfo.State mLastState = NetworkInfo.State.UNKNOWN;

    private boolean mStackConnected;
    private boolean mHWConnected;
    private boolean mInterfaceStopped;
    private Handler mDhcpTarget;
    private String mInterfaceName = null;
    private DhcpInfoInternal mDhcpInfoInternal;
    private VlanMonitor mMonitor;
    private boolean mStartingDhcp;
    private Handler mTarget;
    private Handler mTrackerTarget;
    private Context mContext;
    private VlanStateMachine mVSM;
    private DhcpResults mDhcpResults = null;
    private boolean mPppoeTerminateDone = false;
    private boolean mVlanEnable = false;
    private Handler mDualStackTarget;
    private boolean mSystemReady = false;
    private boolean mNeedToHandleScreenOn = false;

    public static boolean IFCONFIG = false;//#PD96694

    private final String DEFAULT_ETHER_IFNAME = "eth0.45";
    private final String pppoe_running_flag = "net.pppoe.running";
    private final String pppoe_phyif = "net.pppoe.phyif";

		/** add below variables for fix bug PD#138906 */
    private boolean firstlinkdown = true;
    private boolean fakeDown = false;
    private Thread postNotificationThread ;
		/** end added */		
    private BroadcastReceiver mBroadcastReceiver;
    public VlanStateTracker(int netType, String networkName) {
        Slog.i(TAG,"Starts...");

        mNetworkInfo = new NetworkInfo(netType, 0, networkName, "");
        mLinkProperties = new LinkProperties();
        mLinkCapabilities = new LinkCapabilities();

        mNetworkInfo.setIsAvailable(false);
        setTeardownRequested(false);

        if (VlanNative.initVlanNative() != 0 ) {
            Slog.e(TAG,"Can not init vlan device layers");
            return;
        }
        Slog.i(TAG,"Success");
        mServiceStarted = true;
        mSystemReady = false;

        mMonitor = new VlanMonitor(this);
    }

    public void setTeardownRequested(boolean isRequested) {
        mTeardownRequested.set(isRequested);
    }

    public boolean isTeardownRequested() {
        return mTeardownRequested.get();
    }

    private void pppoeConnect() {
        if (mPppoeManager != null) {
            PppoeDevInfo info = mPppoeManager.getSavedPppoeConfig();
            String usr = info.getAccount();
            String pwd = info.getPassword();
            String ifname = info.getIfName();
            String dialmode = info.getDialMode();
            Slog.i(TAG, "pppoeConnect .....");
            Slog.i(TAG, "Username:[" + usr + "], Password:[" + pwd 
                    + "], ifname:[" + ifname + "], dialmode:[" + dialmode + "]");

            if(!DEFAULT_ETHER_IFNAME.equals(ifname)) {
                Slog.w(TAG, "Fixme: force ifname: " + ifname + "==>" + DEFAULT_ETHER_IFNAME);
                info.setIfName(DEFAULT_ETHER_IFNAME);
                mPppoeManager.UpdatePppoeDevInfo(info);
                ifname = info.getIfName();
            }
            if ((usr == null || usr.equals("")) ||
               (pwd == null || pwd.equals(""))) {
                Slog.w(TAG, "INVALID USERNAME OR PASSWORD");
            } else if(!DEFAULT_ETHER_IFNAME.equals(ifname)) {
                Slog.w(TAG, "INVALID inferface: " + ifname);
            } else if(!PppoeDevInfo.PPPOE_DIAL_MODE_AUTO.equals(dialmode)) {
                Slog.i(TAG, "not auto dial: " + dialmode);
            } else {
                mPppoeManager.connect(usr, pwd, DEFAULT_ETHER_IFNAME, dialmode);
            }
        }
        else {
            Slog.i(TAG, "pppoeConnect faield for mPppoeManager uniinitialized");
        }
    }

    private void pppoeDisconnect() {
        if (mPppoeManager != null) {
            String if_name = DEFAULT_ETHER_IFNAME;
            Slog.i(TAG, "pppoeDisconnect .....");
            if (mInterfaceName != null)
                if_name = mInterfaceName;
            mPppoeManager.disconnect(if_name);
            Slog.i(TAG, "WAIT PPPOE disconnect END");
        }
    }

    public boolean isIpAddress(String ipaddr) {
        if (ipaddr == null) {
            Slog.e(TAG, "isIpAddress, ip addr is null");
            return false;
        }
        String[] ips = ipaddr.split("\\.");
        if (ips.length != 4) {
            Slog.e(TAG, "isIpAddress, ip addr is error, ip addr is " + ipaddr);
            return false;
        }
        for (int i=0; i<4; i++) {
            try {
                int block = Integer.parseInt(ips[i]);
                if ((block > 255) || (block < 0)) {
                    Slog.e(TAG, "isIpAddress, ip addr is error, ips[" + i + "]: " + ips[i]);
                    return false;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    public boolean stopInterface(boolean suspend) {
        if (mVM != null) {
            VlanDevInfo info = mVM.getSavedVlanConfig();
            if (info != null && mVM.vlanConfigured()) {
                mInterfaceStopped = true;
                Slog.i(TAG, "stop dhcp and interface with suspend:" + suspend );
                mStartingDhcp = false;
                mStackConnected = false;

                mDhcpResults = null;
                mLinkProperties = null;
                mVSM.stopDhcp();
                if (mInterfaceName != null) {
                    NetworkUtils.stopDhcp(mInterfaceName);
                    NetworkUtils.resetConnections(mInterfaceName, NetworkUtils.RESET_ALL_ADDRESSES);
                }
                if (!suspend) {
                    //mHWConnected = false;
                    setVlanState(false, EVENT_HW_DISCONNECTED);
                }
            }
        }

        return true;
    }

    public boolean stopInterface_when_suspend() {
        if (mVM != null) {
            VlanDevInfo info = mVM.getSavedVlanConfig();
            if (info != null && mVM.vlanConfigured()) {
                mInterfaceStopped = true;
                Slog.i(TAG, "stop dhcp and interface when suspend" );
                mStartingDhcp = false;
                mStackConnected = false;

                mVSM.stopDhcp();
                if (mInterfaceName != null) {
                    NetworkUtils.stopDhcp(mInterfaceName);
                    NetworkUtils.resetConnections(mInterfaceName, NetworkUtils.RESET_ALL_ADDRESSES);
                }

                mVlanEnable = false;
                mHWConnected = false;
                NetworkUtils.disableInterface(mInterfaceName);
            }
        }

        return true;
    }

    private boolean configureInterfaceStatic(VlanDevInfo info, DhcpInfoInternal dhcpInfoInternal) {
        final String ifname = info.getIfName();
        IBinder b = ServiceManager.getService(Context.NETWORKMANAGEMENT_SERVICE);
        INetworkManagementService netd = INetworkManagementService.Stub.asInterface(b);
        InterfaceConfiguration ifcg = new InterfaceConfiguration();
        ifcg.setLinkAddress(dhcpInfoInternal.makeLinkAddress());
        ifcg.setInterfaceUp();
        try {
            netd.setInterfaceConfig(ifname, ifcg);
            mLinkProperties = dhcpInfoInternal.makeLinkProperties();
            mLinkProperties.setInterfaceName(ifname);
            if (info.hasProxy())
                mLinkProperties.setHttpProxy(new ProxyProperties(info.getProxyHost(),
                    info.getProxyPort(), info.getProxyExclusionList()));
            else
                mLinkProperties.setHttpProxy(null);

            Slog.i(TAG, "LinkProperties " + mLinkProperties.toString());
            mDhcpResults = new DhcpResults(mLinkProperties);

            Slog.v(TAG, "Static IP configuration succeeded");
            return true;
        } catch (RemoteException re) {
            Slog.v(TAG, "Static IP configuration failed: " + re);
            return false;
        } catch (IllegalStateException e) {
            Slog.v(TAG, "Static IP configuration failed: " + e);
            return false;
        }
    }

    private boolean configureInterface(VlanDevInfo info) throws UnknownHostException {
        mInterfaceName = info.getIfName();
        //mStackConnected = false;
        //mHWConnected = false;
        mInterfaceStopped = false;

		Slog.i(TAG, "set " + mInterfaceName + " as current interface. " + info.getConnectMode());
        //Slog.i(TAG, "set " + mInterfaceName + " as current interface");
        mDhcpInfoInternal = new DhcpInfoInternal();

        if (info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_DHCP) ||
                info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_DHCP_AUTH)) {
            if(mInterfaceName != null) {
                /*when configure bridge interface(br0), we cannot getVlanDeviceUp immediately
                after reset operation, so lets take some time to retry */
                int cnt = 10;
                while (!mVM.isVlanDeviceUp(mInterfaceName) &&cnt-- > 0){
                    try {
                        Thread.sleep(200);
                        } catch (Exception e){};
                }
                if (!mVM.isVlanDeviceUp(mInterfaceName)) {
                        Slog.d(TAG, mInterfaceName + " is not up!");
                        return false;
                }
            }

            if (!mStartingDhcp) {
                Slog.i(TAG, "trigger dhcp for device " + info.getIfName());
                mStartingDhcp = true;
                if (mDualStackTarget != null) {
                    Slog.i(TAG, "Send EVENT_IPOE_START to DualStackService");
                    mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_IPOE_START);
                }
                mVSM.startDhcp(info.getIfName());
            }
        } else if (info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_MANUAL)) {
            int event;
            try {
                if (!isIpAddress(info.getIpAddress()) || !isIpAddress(info.getNetMask())) {
                    Slog.e(TAG, "set ip manually error, ip addr is " + info.getIpAddress()
                            + " netmask is " + info.getNetMask());
                    return false;
                } else if (mVM != null && mVM.isVlanDeviceAdded(mInterfaceName)) {
                    mDhcpInfoInternal.ipAddress = info.getIpAddress();

                    InetAddress ia = NetworkUtils.numericToInetAddress(info.getNetMask());
                    mDhcpInfoInternal.prefixLength = NetworkUtils.netmaskIntToPrefixLength(
                            NetworkUtils.inetAddressToInt((Inet4Address)ia));

                    LinkAddress myLinkAddr = new LinkAddress(info.getIpAddress() + "/" 
                            + mDhcpInfoInternal.prefixLength);
                    mDhcpInfoInternal.addRoute(new RouteInfo(myLinkAddr));
                    mDhcpInfoInternal.addRoute(new RouteInfo(
                            NetworkUtils.numericToInetAddress(info.getRouteAddr())));

                    mDhcpInfoInternal.dns1 = info.getDns1Addr();
                    mDhcpInfoInternal.dns2 = info.getDns2Addr();
                    Slog.i(TAG, "set ip manually " + mDhcpInfoInternal.toString());
                    if (info.getIfName() != null)
                        NetworkUtils.resetConnections(info.getIfName(), NetworkUtils.RESET_ALL_ADDRESSES);

                    if (configureInterfaceStatic(info, mDhcpInfoInternal)) {
                        event = EVENT_INTERFACE_CONFIGURATION_SUCCEEDED;
                        Slog.v(TAG, "Static IP configuration succeeded");
                    } else {
                        event = EVENT_INTERFACE_CONFIGURATION_FAILED;
                        Slog.v(TAG, "Static IP configuration failed");
                    }
                    mTrackerTarget.sendEmptyMessage(event);
                } else {
                    Slog.e(TAG, "set ip manually error, mVM is null or vlan is down!");
                    return false;
                }
            } catch (IllegalArgumentException e) {
                event = EVENT_INTERFACE_CONFIGURATION_FAILED;
                Slog.e(TAG, "IllegalArgumentException: " + e);
            }
        } else {
            Slog.w(TAG, "configureInterface, do nothing when mode is " + info.getConnectMode());
        }
        return true;
    }


    private boolean addVlanByName(String ifname) {
        String buff [] = ifname.split("\\.");
        if (buff.length != 2) {
            Slog.e(TAG,"ifname format error, vlan interface name should be ethx.id");
            return false;
        }
        Slog.e(TAG,"vlan dev: "+buff[0] +", vlan id: "+ buff[1]);
        if(!NetworkUtils.addVlan(buff[0],Integer.parseInt(buff[1]))) {
            Slog.e(TAG, "add vlan failed.");
            return false;
        }
         return true;
    }

    public void screen_on() {
        mNeedToHandleScreenOn = true;
    }

    public boolean resetInterface() throws UnknownHostException {
        /* This will guide us to enabled the enabled device */
        if (mVM != null) {
            VlanDevInfo info;
            Slog.e(TAG, "resetInterface: mVM.vlanConfigured is " + mVM.vlanConfigured() + " mInterfaceName is "+mInterfaceName );
            if (mVM.vlanConfigured()) {
                info = mVM.getSavedVlanConfig();
            } else if (mInterfaceName != null) {
                info = new VlanDevInfo();
                info.setIfName(mInterfaceName);
            } else {
                Slog.e(TAG, "VlanConfig is EMPTY and mInterfaceName is EMPTY, !resetInterface");
                return true;
            }

            synchronized (this) {
                mInterfaceName = info.getIfName();
                Slog.i(TAG, "reset device " + mInterfaceName);
                if (mInterfaceName != null) {
                        if (mVM.isVlanDeviceAdded(mInterfaceName)) {
                                Slog.e(TAG, "vlan dev "+mInterfaceName + " is added, dont't need add again.");
                        }
                        else {
                            if (!addVlanByName(mInterfaceName)) {
                                return false;
                            }
                        }
                    if ( NetworkUtils.enableInterface(mInterfaceName) != 0 ) {
                        /* After boot, vlan maybe init earlier than ethernet inited, thus vlan copying an
                         * uninited mac address(0x00000000) from uninited ethernet. In this situation,
                         * vlan interface cannot be up and return an error "SIOCSIFFLAGS: Cannot assign
                         * requested address" . So we remove this TRASHED vlan interface, promising another
                         * adding vlan operation to be done successfully in next try.
                         */
                         Slog.e(TAG, "NetworkUtils.enableInterface failed : cannot up vlan  interface "
                            + mInterfaceName + ", remove it.");
                        if(!NetworkUtils.removeVlan(mInterfaceName))
                                Slog.e(TAG, "remove vlan failed.");
                        return false;
                    }
                    mHWConnected = true;
                    NetworkUtils.resetConnections(mInterfaceName, NetworkUtils.RESET_ALL_ADDRESSES);
                }

                if(!mHWConnected) {
                    Slog.i(TAG, "Vlan is removed, do not configureInterface!");
                    setVlanState( false, EVENT_HW_DISCONNECTED);
                    
                    if(!mVlanEnable) {
                        if (mInterfaceName != null)
                            NetworkUtils.enableInterface(mInterfaceName);
                        mVlanEnable = true;
                    }
                    return true;
                }
                
                if(mStackConnected || mStartingDhcp) {
                    Slog.i(TAG, "resetInterface: stop dhcp");
                    mStackConnected = false;
                    mStartingDhcp = false;
                    if(mInterfaceName != null)
                        NetworkUtils.stopDhcp(mInterfaceName);
                    mVSM.stopDhcp();

                    Slog.i(TAG, "Force the connection disconnected before configuration");
                    setVlanState( false, EVENT_HW_DISCONNECTED);
                }

                configureInterface(info);
            }
        }
        return true;
    }

    public String getTcpBufferSizesPropName() {
        return "net.tcp.buffersize.ethernet";
    }

    public void StartPolling() {
        Slog.v(TAG, "start polling");
        mMonitor.startMonitoring();
    }

    public boolean isAvailable() {
        // Only say available if we have interfaces and user did not disable us.
        return ((mVM.getTotalInterface() != 0) && (mVM.getVlanState() != VlanManager.VLAN_STATE_DISABLED));
    }

    private void printStackTrace() {
    	StackTraceElement st[]= Thread.currentThread().getStackTrace();
    	Slog.v(TAG, "Thread " + Thread.currentThread().getName() +"(#" + Thread.currentThread().getId() + ")");
    	for(int i=2;i<st.length;i++)
    		Slog.v(TAG, i+":"+st[i]);

    	Slog.v(TAG, "\n\n");
    }

    public boolean reconnect() {
        Slog.i(TAG, ">>>reconnect");
         Slog.i(TAG, "$$reconnect() returns DIRECTLY)");

        /*
        try {
            synchronized (this) {
                if (mHWConnected && mStackConnected) {
                    Slog.i(TAG, "$$reconnect() returns DIRECTLY)");
                    return true;
                }
            }
            if (mVM.getVlanState() == VlanManager.VLAN_STATE_UNKNOWN ) {
                return true;
            } else if (mVM.getVlanState() != VlanManager.VLAN_STATE_DISABLED ) {
                // maybe this is the first time we run, so set it to enabled
                mVM.setVlanEnabled(true);
                if (!mVM.vlanConfigured()) {
                    mVM.vlanSetDefaultConf();
                }
                Slog.i(TAG, "$$reconnect call resetInterface()");
                return resetInterface();
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return false;
        */
        return true;

    }

    public boolean setRadio(boolean turnOn) {
        return false;
    }

    public void startMonitoring(Context context, Handler target) {
        Slog.i(TAG, "start to monitor the Vlan devices");
        if (mServiceStarted) {
            mContext = context;
            int state = 0;
            final ContentResolver cr = mContext.getContentResolver();
            mVM = (VlanManager)mContext.getSystemService(Context.VLAN_SERVICE);
            mPppoeManager = (PppoeManager)mContext.getSystemService(Context.PPPOE_SERVICE);
            mTarget = target;
            mTrackerTarget = new Handler(target.getLooper(), mTrackerHandlerCallback);
            mVSM.setTrackerTarget(mTrackerTarget);
            try {
                state = Settings.Secure.getInt(cr, Settings.Secure.VLAN_ON);
            } catch (Settings.SettingNotFoundException e) {}
            //int state = mVM.getVlanState();
            Slog.d(TAG , "startMonitoring state is : "+state);
            /*
			if (state != VlanManager.VLAN_STATE_DISABLED) {
                if (state == VlanManager.VLAN_STATE_UNKNOWN || state == VlanManager.VLAN_STATE_ENABLED){
                    Slog.i(TAG, "maybe this is the first time we run, so set it to enabled");
                    mVM.setVlanEnabled(true);
                } else {
                    Slog.i(TAG, "$$ DISABLE startMonitoring call resetInterface()");
                }
            }
            */
            //Vlan will reconnect after Ethernet connect.
            mBroadcastReceiver = new BroadcastReceiver() {
	            @Override
	            public void onReceive(Context context, Intent intent) {
	                Slog.d(TAG, "onReceive: " + intent.getAction());
	                String mVlanid = SystemProperties.get("dhcp.plus.vlan_id" , null);
	                int vlan_id = 0;
	                try {
	                	vlan_id = Integer.parseInt(mVlanid);
	                } catch(Exception e) {
	                	vlan_id = 0;
	                }
	                Slog.d(TAG , "vlan_id is : "+vlan_id);
	                if(null != intent && intent.getAction().equals(EthernetManager.ETHERNET_STATE_CHANGED_ACTION)){
				int event = intent.getIntExtra(EthernetManager.EXTRA_ETHERNET_STATE, EthernetManager.EVENT_PHY_LINK_DOWN);
	                Slog.d(TAG , "event is "+event);
				if (EthernetManager.EVENT_PHY_LINK_UP == event) {
					Slog.d(TAG, "On received ethernet ETHERNET_STATE_CHANGED_ACTION, reconnect vlan:"+mInterfaceName);
					if(null != mInterfaceName && mNeedToHandleScreenOn) {
                        mNeedToHandleScreenOn = false;
						try{
							resetInterface();
						}catch(Exception e){
							Slog.d(TAG , "resetInterface() Exception");	
						}
					}
				}
	                }else if(null != intent && intent.getAction().equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)){
					NetworkInfo info = null;
					Object obj = intent.getExtra(WifiManager.EXTRA_NETWORK_INFO);
					if (obj instanceof NetworkInfo)
						info = (NetworkInfo)obj;
					else{
						Slog.d(TAG , "receive wifi wifi broadcast,but not contains NetworkInfo:"+obj);
						return;
					}
					NetworkInfo.State state = info.getState();
					if (state == NetworkInfo.State.CONNECTED &&
						(info.getType() == ConnectivityManager.TYPE_WIFI)){
						Slog.d(TAG , "wifi connect success,connect wlan vlan...."+mInterfaceName
							+"vlan prop:"+SystemProperties.get("dhcp.plus.vlan_id"));
						if(null != mInterfaceName && mInterfaceName.contains("wlan0.")
							&& vlan_id > 0)
							reconnect();
					}
	                }
	            }
            };

            IntentFilter filter = new IntentFilter();
            filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
            filter.addAction(EthernetManager.ETHERNET_STATE_CHANGED_ACTION);
            mContext.registerReceiver(mBroadcastReceiver, filter);
        }
    }

    public void setUserDataEnable(boolean enabled) {
        Slog.d(TAG, "ignoring setUserDataEnable(" + enabled + ")");
    }

    public void setPolicyDataEnable(boolean enabled) {
        Slog.d(TAG, "ignoring setPolicyDataEnable(" + enabled + ")");
    }

    /**
     * Check if private DNS route is set for the network
     */
    public boolean isPrivateDnsRouteSet() {
        return mPrivateDnsRouteSet.get();
    }

    /**
     * Set a flag indicating private DNS route is set
     */
    public void privateDnsRouteSet(boolean enabled) {
        mPrivateDnsRouteSet.set(enabled);
    }

    /**
     * Check if default route is set
     */
    public boolean isDefaultRouteSet() {
        return mDefaultRouteSet.get();
    }

    /**
     * Set a flag indicating default route is set for the network
     */
    public void defaultRouteSet(boolean enabled) {
        mDefaultRouteSet.set(enabled);
    }

    /**
     * Fetch NetworkInfo for the network
     */
    public NetworkInfo getNetworkInfo() {
        return new NetworkInfo(mNetworkInfo);
    }

    /**
     * Fetch LinkProperties for the network
     */
    public LinkProperties getLinkProperties() {
        return new LinkProperties(mLinkProperties);
    }

    /**
     * A capability is an Integer/String pair, the capabilities
     * are defined in the class LinkSocket#Key.
     *
     * @return a copy of this connections capabilities, may be empty but never null.
     */
    public LinkCapabilities getLinkCapabilities() {
        return new LinkCapabilities(mLinkCapabilities);
    }

    public boolean teardown() {
        return (mVM != null) ? stopInterface(false) : false;
    }

    public void captivePortalCheckComplete() {
        //TODO
    }

    private void postNotification(int event) {
        if (!mSystemReady) {
            Slog.w(TAG, "postNotification system not ready, event: " + event);
            return;
        }
        if(EVENT_INTERFACE_CONFIGURATION_SUCCEEDED == event){
            IFCONFIG = true;
            Slog.d(TAG,"the interface config completed and the flag is :"+IFCONFIG);
        }  
        Slog.d(TAG, "postNotification, event --> event : " + event);
        /*chinamobile-settings recevice intent with ETHERNET_STATE_CHANGED_ACTION & EXTRA_ETHERNET_STATE only, changed by wei.wang*/
        final Intent intent = new Intent(VlanManager.VLAN_STATE_CHANGED_ACTION);
        intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
        intent.putExtra(VlanManager.EXTRA_VLAN_STATE, getEventForCMoblie(event));
        
        if ("sticky".equals(SystemProperties.get("sys.broadcast.policy"))){
            Slog.d(TAG, "postNotification policy sticy");
            mContext.sendStickyBroadcastAsUser(intent, UserHandle.OWNER);
        }
        else {
            mContext.sendBroadcast(intent);
        }

        /*UGLY code. Vlan interface state change MUST be notified as Ethernet interface*/
        final Intent tmpIntent = new Intent(EthernetManager.ETHERNET_STATE_CHANGED_ACTION);
        tmpIntent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
        tmpIntent.putExtra(EthernetManager.EXTRA_ETHERNET_STATE, getEventForCMoblie(event));

        Slog.d(TAG, "broadcast " + EthernetManager.ETH_STATE_CHANGED_ACTION);
        
        if ("sticky".equals(SystemProperties.get("sys.broadcast.policy"))){
            Slog.d(TAG, "postNotification policy sticy");
            mContext.sendStickyBroadcastAsUser(tmpIntent, UserHandle.OWNER);
        }
        else {
            mContext.sendBroadcast(tmpIntent);
        }
    }

    private String getEventDesc(int event) {
        if ( EVENT_DHCP_START == event ) {
            return "EVENT_DHCP_START";
        } else if ( EVENT_INTERFACE_CONFIGURATION_SUCCEEDED == event ) {
            return "EVENT_IF_CFG_SUCCEEDED";
        } else if ( EVENT_INTERFACE_CONFIGURATION_FAILED == event ) {
            return "EVENT_IF_CFG_FAILED";
        } else if ( EVENT_HW_CONNECTED == event ) {
            return "EVENT_HW_CONNECTED";
        } else if ( EVENT_HW_DISCONNECTED == event ) {
            return "EVENT_HW_DISCONNECTED";
        } else if ( EVENT_HW_PHYCONNECTED == event ) {
            return "EVENT_HW_PHYCONNECTED";
        } else if ( EVENT_HW_PHYDISCONNECTED == event ) {
            return "EVENT_HW_PHYDISCONNECTED";
        } else if ( EVENT_HW_CHANGED == event ) {
            return "EVENT_HW_CHANGED";
        } else if ( EVENT_DEVICE_ADDED == event ) {
            return "EVENT_DEVICE_ADDED";
        } else if ( EVENT_DEVICE_REMOVED == event ) {
            return "EVENT_DEVICE_REMOVED";
        }  else {
            return "EVENT_UNKOWN";
        }
    }


    /*the eth event is redefined by chinamobile ,add by wei.wang*/
    private int getEventForCMoblie(int event){
        String mode = mVM.getVlanMode();
        int invertEvent = event;
        if(event == EVENT_HW_PHYCONNECTED) {
            invertEvent = VlanManager.EVENT_PHY_LINK_UP;
        } else if(event == EVENT_HW_PHYDISCONNECTED) {
            invertEvent = VlanManager.EVENT_PHY_LINK_DOWN;
        } else {
            if(mode.equals(VlanManager.VLAN_CONNECT_MODE_MANUAL)) {
                if((event == EVENT_INTERFACE_CONFIGURATION_SUCCEEDED && mVM.hasVlanDeviceAdded())
                    || event == EVENT_HW_CONNECTED) {
                    invertEvent = VlanManager.EVENT_STATIC_CONNECT_SUCCESSED;
                }else if(event == EVENT_HW_DISCONNECTED) {
                    invertEvent = VlanManager.EVENT_STATIC_DISCONNECT_SUCCESSED;
                }else if(event == EVENT_INTERFACE_CONFIGURATION_FAILED) {
                    invertEvent = VlanManager.EVENT_STATIC_CONNECT_FAILED;
                }
            }else if(mode.equals(VlanManager.VLAN_CONNECT_MODE_DHCP_AUTH)) {
				if((event == EVENT_INTERFACE_CONFIGURATION_SUCCEEDED && mVM.hasVlanDeviceAdded()) 
                    || event == EVENT_HW_CONNECTED) {
		            invertEvent = VlanManager.EVENT_IPOE_CONNECT_SUCCESSED;
				}else if(event == EVENT_HW_DISCONNECTED) {
					invertEvent = VlanManager.EVENT_IPOE_DISCONNECT_SUCCESSED;
				}else if(event == EVENT_INTERFACE_CONFIGURATION_FAILED) {
					invertEvent = VlanManager.EVENT_IPOE_CONNECT_FAILED;
	             }
            } else {
                if((event == EVENT_INTERFACE_CONFIGURATION_SUCCEEDED && mVM.hasVlanDeviceAdded()) 
                        || event == EVENT_HW_CONNECTED) {
                    invertEvent = VlanManager.EVENT_DHCP_CONNECT_SUCCESSED;
                }else if(event == EVENT_HW_DISCONNECTED) {
                    invertEvent = VlanManager.EVENT_DHCP_DISCONNECT_SUCCESSED;
                }else if(event == EVENT_INTERFACE_CONFIGURATION_FAILED) {
                    invertEvent = VlanManager.EVENT_DHCP_CONNECT_FAILED;
                }
            }
        }
        Slog.d(TAG, "postNotification, invertEvent : " + invertEvent);
        return invertEvent;
    }

    private void setVlanState(boolean state, int event) {
        Slog.d(TAG, "setVlanState state=" + mNetworkInfo.isConnected() + "->" + state + 
                    " event=" + getEventDesc(event) + "("+ event +")");
        if((EVENT_HW_DISCONNECTED == event) || (EVENT_HW_PHYDISCONNECTED == event) ) {
            VlanDevInfo info = mVM.getSavedVlanConfig();
            if ((info != null) && info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_PPPOE)
			   && mPppoeManager.getPppoeConnectType().equals(DEFAULT_ETHER_IFNAME)) {
                Slog.d(TAG, "Fixme: EVENT_HW_DISCONNECTED: DO NOT stop pppoe");
                //pppoeDisconnect();
            }
        }
        if (mNetworkInfo.isConnected() != state) {
            if (state) {
                mNetworkInfo.setDetailedState(DetailedState.CONNECTED, null, null);
            } else {
                mNetworkInfo.setDetailedState(DetailedState.DISCONNECTED, null, null);
                if((EVENT_HW_DISCONNECTED == event) || (EVENT_HW_PHYDISCONNECTED == event)) {
                    Slog.d(TAG, "EVENT_HW_DISCONNECTED: StopInterface");
                    stopInterface(true);
                }
            }
            mNetworkInfo.setIsAvailable(state);
            Message msg = mTarget.obtainMessage(EVENT_STATE_CHANGED, mNetworkInfo);
            msg.sendToTarget();
        }
        	postNotification(event);
    }

    public DhcpInfo getDhcpInfo() {
        if(mDhcpResults == null){
            if("mobile".equals(SystemProperties.get("sys.proj.type"))) 
                return null;
            DhcpInfo mDhcpInfo = mDhcpInfoInternal.makeDhcpInfo();
            return mDhcpInfo;
        }
        if (mDhcpResults.linkProperties == null) 
            return null;
        DhcpInfo info = new DhcpInfo();
		
        //Always send null info if mHWConnected=false
        if(!mHWConnected)
            return info;
		
        for (LinkAddress la : mDhcpResults.linkProperties.getLinkAddresses()) {
            InetAddress addr = la.getAddress();
            if (addr instanceof Inet4Address) {
                info.ipAddress = NetworkUtils.inetAddressToInt((Inet4Address)addr);
                break;
            }
        }
        for (RouteInfo r : mDhcpResults.linkProperties.getRoutes()) {
            if (r.isDefaultRoute()) {
                InetAddress gateway = r.getGateway();
                if (gateway instanceof Inet4Address) {
                    info.gateway = NetworkUtils.inetAddressToInt((Inet4Address)gateway);
                }
            } else if (r.hasGateway() == false) {
                LinkAddress dest = r.getDestination();
                if (dest.getAddress() instanceof Inet4Address) {
                    info.netmask = NetworkUtils.prefixLengthToNetmaskInt(
                            dest.getNetworkPrefixLength());
                }
            }
        }
        int dnsFound = 0;
        for (InetAddress dns : mDhcpResults.linkProperties.getDnses()) {
            if (dns instanceof Inet4Address) {
                if (dnsFound == 0) {
                    info.dns1 = NetworkUtils.inetAddressToInt((Inet4Address)dns);
                } else {
                    info.dns2 = NetworkUtils.inetAddressToInt((Inet4Address)dns);
                }
                if (++dnsFound > 1) break;
            }
        }
        InetAddress serverAddress = mDhcpResults.serverAddress;
        if (serverAddress instanceof Inet4Address) {
            info.serverAddress = NetworkUtils.inetAddressToInt((Inet4Address)serverAddress);
        }
        info.leaseDuration = mDhcpResults.leaseDuration;

        if(!mHWConnected){
            info.ipAddress = 0;
            info.netmask = 0;
            info.dns1 = 0;
            info.gateway = 0;
        }
        return info;

    }

    private Handler.Callback mTrackerHandlerCallback = new Handler.Callback() {
        String ifname;
        /** {@inheritDoc} */
        public boolean handleMessage(Message msg) {
            if (mInterfaceName == null) {
                Slog.i(TAG, "mInterfaceName undefined. DISCARD message");
                return true;
            }
            synchronized (this) { //TODO correct 'this' object?
                VlanDevInfo info;
                boolean newNetworkstate = false;
                if (mVM.getVlanState() == VlanManager.VLAN_STATE_DISABLED &&
                    msg.what != EVENT_HW_DISCONNECTED) {
                    Slog.i(TAG, "Vlan is DISABLED. DISCARD message");
                    return true;
                }
                switch (msg.what) {
                case EVENT_DEVICE_ADDED:
                    Slog.i(TAG, "[EVENT_DEVICE_ADDED]");
                    // trigger service to scanVlanDev
                    boolean isServiceAdded = mVM.hasVlanDeviceAdded();
                    Slog.i(TAG, "isServiceAdded " + isServiceAdded);
                    Slog.i(TAG, mInterfaceName + " added, Force to up it to driver dhcp");
                    NetworkUtils.enableInterface(mInterfaceName);
                    break;

                case EVENT_DEVICE_REMOVED:
                    Slog.i(TAG, "[EVENT_DEVICE_REMOVED]");
                    Slog.i(TAG, "post Notification: EVENT_HW_PHYDISCONNECTED");
                    mDhcpResults = null;
                    mLinkProperties = null;
                    postNotification(EVENT_HW_PHYDISCONNECTED);
                    break;

                case EVENT_INTERFACE_CONFIGURATION_SUCCEEDED:
                    Slog.i(TAG, "[EVENT_INTERFACE_CONFIGURATION_SUCCEEDED]");
                    mStackConnected = true;
                    mHWConnected = true;

                    info = mVM.getSavedVlanConfig();
                    if (info != null) {
                        mDhcpResults = (DhcpResults)msg.obj;
                        if(mDhcpResults == null) {
                            Slog.w(TAG, "mDhcpResults is null");
                            mStackConnected = false;
                            return true;
                        }

                        if (mDualStackTarget != null) {
                            if(!info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_DHCP)
                            && !info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_DHCP_AUTH)) {
                            Slog.i(TAG, "Accept it Even if NOT DHCP mode for DualStack enabled");
                            }

                            Slog.i(TAG, "Send EVENT_IPOE_SUCCEEDED to DualStackService");
                            mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_IPOE_SUCCEEDED);
                        }

                        Slog.i(TAG, mDhcpResults.toString() );
                        mLinkProperties = mDhcpResults.linkProperties;
                        mLinkProperties.setInterfaceName(mInterfaceName);
                        if (mVM.vlanConfigured() && info.hasProxy())
                            mLinkProperties.setHttpProxy(new ProxyProperties(info.getProxyHost(),
                                    info.getProxyPort(), info.getProxyExclusionList()));
                        else
                            mLinkProperties.setHttpProxy(null);

                        Slog.d(TAG, "Fixme: DHCP OK. disconnect pppoe");
                        pppoeDisconnect();
                    }
                    
                    if (mVM.isVlanDeviceAdded(mInterfaceName)) {
                        Slog.i(TAG, "Vlan "+ mInterfaceName + " is added" );
                        newNetworkstate = true;
                    }
                    setVlanState(newNetworkstate, msg.what);
                    break;
                case EVENT_INTERFACE_CONFIGURATION_FAILED:
                    Slog.i(TAG, "[EVENT_INTERFACE_CONFIGURATION_FAILED]");
                    mStackConnected = false;
                    setVlanState(newNetworkstate, msg.what);
                    if (mDualStackTarget != null) {
                        Slog.i(TAG, "Send EVENT_IPOE_FAILED to DualStackService");
                        mStartingDhcp = false;
                        mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_IPOE_FAILED);
                    }
                    else {
                        String prop_val = SystemProperties.get("net.dhcp.repeat", "disable");
                        if (prop_val.equals("enabled")) {
                            info = mVM.getSavedVlanConfig();
                            if ((info != null) && (info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_DHCP)
                                    || info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_DHCP_AUTH))) {
                                Message message = new Message();
                                message.what = EVENT_REQUEST_RESET;
                                mTrackerTarget.removeMessages(EVENT_REQUEST_RESET);
                                mTrackerTarget.sendMessageDelayed(message, 3000);
                            }
                        }
                    }

                    break;
                case EVENT_REQUEST_RESET:
		     Slog.d(TAG , "===EVENT_REQUEST_RESET==");
		     info = mVM.getSavedVlanConfig();
		     mVM.updateVlanDevInfo(info);
		     break;
                case EVENT_HW_CONNECTED:
                    Slog.i(TAG, "[EVENT: EVENT_HW_CONNECTED]");
                    mHWConnected = true;
                    if (mVM.isVlanDeviceAdded(mInterfaceName)){
                        Slog.i(TAG, "Vlan " + mInterfaceName + " is added" );
                        newNetworkstate = true;
                    }

                    //setVlanState(newNetworkstate, msg.what);
                    break;
                case EVENT_HW_DISCONNECTED:
                case EVENT_HW_PHYDISCONNECTED:
                    Slog.i(TAG, "[EVENT: vlan(" + (String)msg.obj + ") is removed]");
                    SystemProperties.set("net."+msg.obj+".status", "disconnected");
                    SystemProperties.set("net."+msg.obj+".hw.status", "disconnected");
                    mDhcpResults = null;
                    mLinkProperties = null;
                    mHWConnected = false;
                    mStackConnected = false;
                    setVlanState( false, msg.what);
                    if (mSystemReady) {
                        //Intent intent = new Intent("android.net.ethernet.unplug.cable");
                        //intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT);
                        //mContext.sendBroadcastAsUser(intent, UserHandle.OWNER);
                        //Slog.d(TAG, "android.net.ethernet.unplug.cable!!!!!!!");
                        //mContext.sendBroadcast(intent);
                    }
                    break;
                case EVENT_IP_REMOVED:
                    Slog.i(TAG, "[EVENT: IP is cleared]");

                    mHWConnected = true;
                    setVlanState( false, msg.what);
                    break;
                case EVENT_HW_PHYCONNECTED:
                    ifname = (String) msg.obj;
                    if(mHWConnected &&mVM.hasVlanDeviceUp()&&ifname.equals(mInterfaceName)) {
                        Slog.i(TAG, "Vlan is Link up, do not do again!");
                        return true;
                    }
                    if(!mVM.hasVlanDeviceUp()&&ifname.equals(mInterfaceName)) {
                        Slog.i(TAG, "Vlan is Link down, do not do again!");
                        return true;
                    }
                    mHWConnected = true;
                    newNetworkstate = mNetworkInfo.isConnected();
                    info = mVM.getSavedVlanConfig();
                    if (mVM.isVlanDeviceAdded(mInterfaceName) && (info != null)) {
                        if(info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_MANUAL)) {
                            newNetworkstate = true;
                            Slog.i(TAG, "Vlan is added" );
                            Slog.i(TAG, "Static IP configured, make network connected" );
                        } else if(info.getConnectMode().equals(VlanDevInfo.VLAN_CONN_MODE_PPPOE)) {
                            setVlanState(newNetworkstate, EVENT_HW_PHYCONNECTED);
                            pppoeConnect();
                            return true;
                        }
                    } 
                    if( mVM.getIpv6PersistedState() == VlanManager.IPV6_STATE_ENABLED){
                        mVM.enableIpv6(true);
                        Slog.w(TAG, "configureInterface, enableIpv6");
                    }
                    setVlanState(newNetworkstate, EVENT_HW_PHYCONNECTED);
                    int state = mVM.getVlanState();
                    if (state != VlanManager.VLAN_STATE_DISABLED) {
                        info = mVM.getSavedVlanConfig();
                        Slog.w(TAG," is Configured "+mVM.vlanConfigured() );
                        if (info == null || !mVM.vlanConfigured()) {
                            String ifname = (String)msg.obj;
                            info = new VlanDevInfo();
                            info.setIfName(ifname);
                        }
                        info.setIfName(ifname);
                        //mVM.updateVlanDevInfo(info);
                    }
                    break;
                }
            }
            return true;
        }
    };

    public void notifyPhyConnected(String ifname) {
        Slog.i(TAG, "report interface is up for " + ifname);
        synchronized(this) {
            Message msg = mTrackerTarget.obtainMessage(EVENT_HW_PHYCONNECTED, ifname);
            msg.sendToTarget();
        }
    }

    public void notifyPhyDisConnected(String ifname) {
        Slog.i(TAG, "report interface is down for " + ifname);
        synchronized(this) {
            Message msg = mTrackerTarget.obtainMessage(EVENT_HW_PHYDISCONNECTED, ifname);
            msg.sendToTarget();
        }
    }

    public void notifyDeviceAdded(String ifname) {
        Slog.i(TAG, ifname + " ADDED");
        Slog.i(TAG, "mInterfaceName: " + mInterfaceName);

        if ((mInterfaceName == null) || ifname.equals(mInterfaceName)) {
            if (mInterfaceName == null) mInterfaceName = ifname;
            synchronized(this) {
                Message msg = mTrackerTarget.obtainMessage(EVENT_DEVICE_ADDED, ifname);
                msg.sendToTarget();
            }
        }
    }

    public void notifyDeviceRemoved(String ifname) {
        Slog.i(TAG, ifname + " REMOVED");
        if (ifname.equals(mInterfaceName)) {
            synchronized(this) {
                Message msg = mTrackerTarget.obtainMessage(EVENT_DEVICE_REMOVED, ifname);
                msg.sendToTarget();
            }
        }
    }

    public void notifyIpRemoved(String ifname) {
        Slog.i(TAG, ifname + " IP removed");
        if (ifname.equals(mInterfaceName)) {
            synchronized(this) {
                Message msg = mTrackerTarget.obtainMessage(EVENT_IP_REMOVED, ifname);
                msg.sendToTarget();
            }
        }
    }


    public void notifyStateChange(String ifname, DetailedState state) {
        Slog.v(TAG, "report new state " + state.toString() + " on dev " + ifname + " current=" + mInterfaceName);
//        if (ifname.equals("eth0") || ifname.equals("br0")) {
            Slog.v(TAG, "update network state tracker");
            synchronized(this) {
                int hw_state = state.equals(DetailedState.CONNECTED) ? EVENT_HW_CONNECTED : EVENT_HW_DISCONNECTED;
                Message msg = mTrackerTarget.obtainMessage(hw_state, ifname);
                msg.sendToTarget();
            }
//        }
    }

    public void setDependencyMet(boolean met) {
        // not supported on this network
    }

    /**
     * Informs the state tracker that another interface is stacked on top of it.
     **/
    public void addStackedLink(LinkProperties link){
    }

    /**
     * Informs the state tracker that a stacked interface has been removed.
     **/
    public void removeStackedLink(LinkProperties link){
    }
    
    /*
     * Called once to setup async channel between this and
     * the underlying network specific code.
     */
    public void supplyMessenger(Messenger messenger){
    }

    /*
     * Network interface name that we'll lookup for sampling data
     */
    public String getNetworkInterfaceName(){
        return null;
    }

    /*
     * Save the starting sample
     */
    public void startSampling(SamplingDataTracker.SamplingSnapshot s){
    }

    /*
     * Save the ending sample
     */
    public void stopSampling(SamplingDataTracker.SamplingSnapshot s) {
    }

    @Override
    public void captivePortalCheckCompleted(boolean isCaptivePortal) {
        // not implemented
    }

    
    /**
     * Get interesting information about this network link
     * @return a copy of link information, null if not available
     */
    public LinkQualityInfo getLinkQualityInfo(){
        return null;
    }

    public void setVlanStateMachine(VlanStateMachine esm) {
        mVSM = esm;
    }
    
    public void disconnectDualStackIpoe() {
        Slog.i(TAG, "disconnectDualStackIpoe mStartingDhcp is " + mStartingDhcp);
        if (mStartingDhcp) {
            mStartingDhcp = false;
            if(mInterfaceName != null)
                NetworkUtils.stopDhcp(mInterfaceName);
            if (mVSM != null) mVSM.stopDhcp();
            setVlanState(false, EVENT_HW_DISCONNECTED);
        }
    }


    public void startDualStackIpoe() {
        VlanDevInfo info = mVM.getSavedVlanConfig();
        if (info != null) {
            if (!mStartingDhcp) {
                Slog.i(TAG, "startDualStackIpoe: trigger dhcp for device " + info.getIfName());
                mStartingDhcp = true;
                mVSM.startDhcp(info.getIfName());
                if (mDualStackTarget != null) {
                    Slog.i(TAG, "startDualStackIpoe: Send EVENT_IPOE_START to DualStackService");
                    mDualStackTarget.sendEmptyMessage(DualStackManager.EVENT_IPOE_START);
                }
            } else {
                Slog.w(TAG, "startDualStackIpoe mStartingDhcp is true");
            }
        } else {
            Slog.w(TAG, "startDualStackIpoe info is null!");
        }
    }

    public void setDualStackTarget(Handler target) {
        mDualStackTarget = target;
    }

    public void systemReady() {
        Slog.d(TAG, "systemReady, mHWConnected: " + mHWConnected);
        mSystemReady = true;
        if (!mHWConnected) {
        		if (!"unicom".equals(SystemProperties.get("sys.proj.type"))
							&& !"shandong".equals(SystemProperties.get("sys.proj.tender.type"))) {
								
								postNotification(EVENT_HW_PHYDISCONNECTED);
						}
        }
    }
}
