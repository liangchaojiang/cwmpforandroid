package android.net.vlan;

import java.util.List;

import android.annotation.SdkConstant;
import android.annotation.SdkConstant.SdkConstantType;
import android.net.wifi.IWifiManager;
import android.os.Handler;
import android.os.RemoteException;
import android.util.Slog;
import android.net.DhcpInfo;
import android.net.NetworkUtils;
import android.net.vlan.VlanDevInfo;
public class VlanManager {
    public static final String TAG = "VlanManager";
    public static final int ETH_DEVICE_SCAN_RESULT_READY = 0;
    public static final String VLAN_STATE_CHANGED_ACTION =
            "android.net.vlan.VLAN_STATE_CHANGED";

    public static final String EXTRA_NETWORK_INFO = "networkInfo";
    public static final String EXTRA_VLAN_STATE = "vlan_state";
    public static final int ETHERNET_DEVICE_SCAN_RESULT_READY = 0;
    public static final String IPV6_STATE_CHANGED_ACTION = "android.net.ethernet.IPV6_STATE_CHANGE";
    public static final int ETHERNET_STATE_DISABLED = 0;
    public static final int ETHERNET_STATE_ENABLED = 1;
    public static final int ETHERNET_STATE_UNKNOWN = 2;
    public static final int EVENT_DHCP_CONNECT_SUCCESSED = 10;
    public static final int EVENT_DHCP_CONNECT_FAILED = 11;
    public static final int EVENT_DHCP_DISCONNECT_SUCCESSED = 12;
    public static final int EVENT_DHCP_DISCONNECT_FAILED = 13;
    public static final int EVENT_STATIC_CONNECT_SUCCESSED = 14;
    public static final int EVENT_STATIC_CONNECT_FAILED = 15;
    public static final int EVENT_STATIC_DISCONNECT_SUCCESSED = 16;
    public static final int EVENT_STATIC_DISCONNECT_FAILED = 17;
    public static final int EVENT_PHY_LINK_UP =18;
    public static final int EVENT_PHY_LINK_DOWN = 19;
    public static final int IPV6_STATE_DISABLED = 0;
    public static final int IPV6_STATE_ENABLED = 1;
    public static final int IPV6_STATE_UNKNOWN = 2;
    public static final int IPV6_DHCP_START = 3;
    public static final int IPV6_DHCP_STOP = 4;
    public static final int IPV6_STATIC_START = 5;
    public static final int IPV6_STATIC_STOP = 6;
    public static final int EVENT_DHCPV6_CONNECT_SUCCESSED = 20;
    public static final int EVENT_DHCPV6_CONNECT_FAILED = 21;
    public static final int EVENT_STATIC6_CONNECT_SUCCESSED = 14;
    public static final int EVENT_STATIC6_CONNECT_FAILED = 15;

    /**
      * !!! WARNING !!!
      *  EVENT_IPOE_* MUST BE SAME AS IN EthernetManager.java.
    */
	public static final int EVENT_IPOE_CONNECT_SUCCESSED = 31;
	public static final int EVENT_IPOE_CONNECT_FAILED = 32;
	public static final int EVENT_IPOE_DISCONNECT_SUCCESSED = 33;
	public static final int EVENT_IPOE_DISCONNECT_FAILED = 34;
    /**
       * The vlan interface is configured by dhcp
    */
    public static final String VLAN_CONNECT_MODE_DHCP = "dhcp";

 	public static final String VLAN_CONNECT_MODE_DHCP_AUTH = "dhcp_auth";
   /**
       * The vlan interface is configured manually
    */
    public static final String VLAN_CONNECT_MODE_MANUAL = "manual";
    public static final String EXTRA_PREVIOUS_VLAN_STATE = "previous_vlan_state";

    public static final int VLAN_STATE_UNKNOWN = 0;
    public static final int VLAN_STATE_DISABLED = 1;
    public static final int VLAN_STATE_ENABLED = 2;

    IVlanManager mService;
    Handler mHandler;

    public VlanManager(IVlanManager service, Handler handler) {
        Slog.i(TAG, "Init Vlan Manager");
        mService = service;
        mHandler = handler;
    }

    public boolean isVlanConfigured() {
        try {
            return mService.isVlanConfigured();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not check vlan config state");
        }
        return false;
    }

    public VlanDevInfo getSavedVlanConfig() {
        try {
            return mService.getSavedVlanConfig();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get vlan config");
        }
        return null;
    }

    public void updateVlanDevInfo(VlanDevInfo info) {
        try {
            mService.UpdateVlanDevInfo(info);
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not update vlan device info");
        }
    }

    public String[] getDeviceNameList() {
        try {
            return mService.getDeviceNameList();
        } catch (RemoteException e) {
            return null;
        }
    }

    public String getAuthUsername() {
        try {
            return mService.getAuthUsername();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth username");
        }
        return null;
    }

    public String getAuthPassword() {
        try {
            return mService.getAuthPassword();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth password");
        }
        return null;
    }
    
    public String getAuthVendorid() {
        try {
            return mService.getAuthVendorid();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth vendorid");
        }
        return null;
    }
    
    public boolean getAuthState() {
        try {
            return mService.getAuthState();
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not get auth state");
        }
        return false;
    }
	public boolean getAuthOption125status(){
        try {
            return mService.getAuthOption125status();
        } catch (RemoteException e) {

        }
        return false;
    }
	public boolean setAuthOption125(boolean enable, String option125Info){
        try {
            return mService.setAuthOption125(enable, option125Info);
        } catch (RemoteException e) {

        }
		return false;
	}

    public boolean setAuthState(String username, String password, String vendorid, boolean enable) {
        try {
            return mService.setAuthState(username, password, vendorid, enable);
        } catch (RemoteException e) {
            Slog.i(TAG, "Can not set auth state, username: " + username + ", password" + password
                    + ", vendorid: " + vendorid + ", enable: " + enable);
        }
        return false;
    }

    public void setVlanEnabled(boolean enable) {
        try {
            mService.setVlanState(enable ? VLAN_STATE_ENABLED:VLAN_STATE_DISABLED);
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not set new state");
        }
    }


    public void setVlanDhcp(String ifname, boolean enabled) {
        try {
            mService.setVlanDhcp(ifname, enabled);
        } catch (RemoteException e) {
            Slog.i(TAG,"Can not set Vlan Dhcp");
        }
    }

    public int getVlanState( ) {
        try {
            return mService.getVlanState();
        } catch (RemoteException e) {
            return 0;
        }
    }
    
    /**
    * @param mode
    * ETHERNET_CONNECT_MODE_DHCP or ETHERNET_CONNECT_MODE_MANUAL
    * @param dhcpInfo
    * if mode is ETHERNET_CONNECT_MODE_MANUAL,it is Required.
    */
    public void setVlanMode(String mode, DhcpInfo dhcpInfo) {
	    try {
			mService.setVlanMode(mode);
			if(mode.equals(VLAN_CONNECT_MODE_MANUAL)) {
				Slog.d(TAG, "setVlanMode" +
                           " dhcpInfo.ipAddress : " + NetworkUtils.intToInetAddress(dhcpInfo.ipAddress).getHostAddress() +
            			   " hcpInfo.dns1 : " + NetworkUtils.intToInetAddress(dhcpInfo.dns1).getHostAddress() +
				           " dhcpInfo.dns2 : " + NetworkUtils.intToInetAddress(dhcpInfo.dns2).getHostAddress() +
				           " dhcpInfo.gateway : " + NetworkUtils.intToInetAddress(dhcpInfo.gateway).getHostAddress() +
				           " dhcpInfo.netmask : " + NetworkUtils.intToInetAddress(dhcpInfo.netmask).getHostAddress());
				//TODO with dhcpInfo
				//ipAddress; gateway; netmask; dns1; dns2
				VlanDevInfo vlanDevInfo = getSavedVlanConfig();
				if(vlanDevInfo != null) {
					vlanDevInfo.setIpAddress(NetworkUtils.intToInetAddress(dhcpInfo.ipAddress).getHostAddress());
					vlanDevInfo.setDns1Addr(NetworkUtils.intToInetAddress(dhcpInfo.dns1).getHostAddress());
					vlanDevInfo.setDns2Addr(NetworkUtils.intToInetAddress(dhcpInfo.dns2).getHostAddress());
					vlanDevInfo.setRouteAddr(NetworkUtils.intToInetAddress(dhcpInfo.gateway).getHostAddress());
					vlanDevInfo.setNetMask(NetworkUtils.intToInetAddress(dhcpInfo.netmask).getHostAddress());
					updateVlanDevInfo(vlanDevInfo);
				}
			}
		} catch (RemoteException e) {
		}
     }

     /**
     * @return
     */
     public String getVlanMode() {
	     String vlanMode = null;
	     VlanDevInfo vlanDevInfo = getSavedVlanConfig();
	     if(vlanDevInfo != null) {
		 	vlanMode = vlanDevInfo.getConnectMode();
		}
         if(vlanMode != null)
            return vlanMode;
         else
            return "null";
	}

	 /**
	 * @return
	 */
	 public String getInterfaceName() {
	 	String interfaceName = null;
		VlanDevInfo vlanDevInfo = getSavedVlanConfig();
		if(vlanDevInfo != null) {
			interfaceName = vlanDevInfo.getIfName();
		}
		return interfaceName;
	}

	public boolean setInterfaceName(String iface) {
		if(iface != null && !iface.equals("")) {
			VlanDevInfo vlanDevInfo = getSavedVlanConfig();
			if(vlanDevInfo != null) {
				vlanDevInfo.setIfName(iface);
				Slog.d(TAG, "FIXME!!! BUG-99514. DO NOT call updateVlanDevInfo() in setInterfaceName(), for it will trigger dhcp");
				//updateVlanDevInfo(vlanDevInfo);
			}
		}
		return true;
	}

	/*
	* @param enable
	*/
	public void setWifiDisguise(boolean enable) {
	}

	/**
	* @return
	*/
	public boolean getWifiDisguiseState() {
		return false;
	}
	
   public boolean getNetLinkStatus() {
   	return getNetLinkStatus(getInterfaceName()) > 0;
   }

   public int getNetLinkStatus(String ifaceName) {
   	try {
		return mService.hasVlanDeviceUp() ? 1:0;
	} catch (RemoteException e) {
		return 0;
	}
    }

    public boolean vlanConfigured() {
        try {
            return mService.isVlanConfigured();
        } catch (RemoteException e) {
            return false;
        }
    }

    public DhcpInfo getDhcpInfo() {
        try {
            return mService.getDhcpInfo();
        } catch (RemoteException e) {
            return null;
        }
    }

    public int getTotalInterface() {
        try {
            return mService.getTotalInterface();
        } catch (RemoteException e) {
            return 0;
        }
    }

    public void vlanSetDefaultConf() {
        try {
            mService.setVlanMode(VlanDevInfo.VLAN_CONN_MODE_DHCP);
        } catch (RemoteException e) {
        }
    }

    public boolean hasVlanDeviceUp() {
        try {
            return mService.hasVlanDeviceUp();
        } catch (RemoteException e) {
            return false;
        }
    }

    public boolean isVlanDeviceUp(String ifname) {
        try {
            return mService.isVlanDeviceUp(ifname);
        } catch (RemoteException e) {
            return false;
        }
    }

    public boolean hasVlanDeviceAdded() {
        try {
            return mService.hasVlanDeviceAdded();
        } catch (RemoteException e) {
            return false;
        }
    }

    public void disconnect() {
        try {
            mService.disconnect();
        } catch (RemoteException e) {
        }
    }

    public boolean isVlanDeviceAdded(String ifname) {
        try {
            return mService.isVlanDeviceAdded(ifname);
        } catch (RemoteException e) {
            return false;
        }
    }

    public void enableIpv6(boolean enable) {
        try {
            mService.enableIpv6(enable);
        } catch (RemoteException e) {
        }
    }

    public int getIpv6PersistedState() {
        try {
            return mService.getIpv6PersistedState();
        } catch (RemoteException e) {
		  return VlanManager.IPV6_STATE_UNKNOWN;
        }
    }

    public void setVlanMode6(String mode){
        try {
            mService.setVlanMode6(mode);
        } catch (RemoteException e) {
        }
    }

    public void setVlanDefaultConf6() {
        try {
            mService.setVlanDefaultConf6();
        } catch (RemoteException e) {
        }
    }

    public String getVlanMode6()  {
        try {
            return mService.getVlanMode6();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public void setIpv6DatabaseInfo(String ip, int prefixlength, String gw, String dns1, String dns2) {
        try {
            mService.setIpv6DatabaseInfo(ip, prefixlength, gw, dns1, dns2);
        } catch (RemoteException e) {
        }
    }

    public String getIpv6DatabaseAddress() {
        try {
            return mService.getIpv6DatabaseAddress();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public int getIpv6DatabasePrefixlength(){
        try {
            return mService.getIpv6DatabasePrefixlength();
        } catch (RemoteException e) {
		    return 0;
        }
    }
    public String getIpv6DatabaseDns1() {
        try {
            return mService.getIpv6DatabaseDns1();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public String getIpv6DatabaseDns2(){
        try {
            return mService.getIpv6DatabaseDns2();
        } catch (RemoteException e) {
		    return null;
        }
    }
    public String getIpv6DatabaseGateway() {
        try {
            return mService.getIpv6DatabaseGateway();
        } catch (RemoteException e) {
		    return null;
        }
    }

    public boolean checkDhcpv6Status(String ifname){
        try {
            return mService.checkDhcpv6Status(ifname);
        } catch (RemoteException e) {
		    return false;
        }
    }
    public String getDhcpv6Ipaddress(String ifname) {
        try {
            return mService.getDhcpv6Ipaddress(ifname);
        } catch (RemoteException e) {
		    return null;
        }
    }

    public String getDhcpv6Gateway(){
        try {
            return mService.getDhcpv6Gateway();
        } catch (RemoteException e) {
		    return null;
        }
    }
    public int getDhcpv6Prefixlen(String ifname) {
        try {
            return mService.getDhcpv6Prefixlen(ifname);
        } catch (RemoteException e) {
            return 0;
        }
    }

    public String getDhcpv6Dns(String ifname, int number){
        try {
            return mService.getDhcpv6Dns(ifname, number);
        } catch (RemoteException e) {
		    return null;
        }
    }

    public int getDhcpv6DnsCnt(String ifname){
        try {
            return mService.getDhcpv6DnsCnt(ifname);
        } catch (RemoteException e) {
		    return 0;
        }
    }

    public boolean releaseDhcpLease(String ifname){
        try {
            return mService.releaseDhcpLease(ifname);
        } catch (RemoteException e) {
		    return false;
        }
    }
}
