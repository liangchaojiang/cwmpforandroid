package android.net.vlan;

public class VlanOperation {
    private static VlanOperation VlanOp;

    public native boolean connect(String ifname, String account, String passwd);
    public native boolean disconnect();
    public native boolean terminate();
    static {
        //System.loadLibrary("cbpppoejni");
    }

    public static void createInstance(){
        if (VlanOp != null){
            throw new RuntimeException("Last VlanOp instance still live.");
        }
        VlanOp = new VlanOperation();
    }

    public static VlanOperation getInstance() {
        if(VlanOp == null) {
            VlanOp = new VlanOperation();
        }
        return VlanOp;
    }
}
