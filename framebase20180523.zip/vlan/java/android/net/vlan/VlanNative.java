package android.net.vlan;

/**
 * Native calls to vlan interface.
 *
 * {@hide}
 */

public class VlanNative {
	public native static String getInterfaceName(int i);
	public native static int getInterfaceCnt();
	public native static int initVlanNative();
	public native static String waitForEvent();
	public native static int isInterfaceAdded(String ifname);
}
