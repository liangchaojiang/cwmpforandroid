package android.net.vlan;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.DhcpInfoInternal;
import android.net.DhcpStateMachine;
import android.net.InterfaceConfiguration;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.NetworkInfo;
import android.net.NetworkInfo.DetailedState;
import android.net.NetworkUtils;
import android.net.RouteInfo;
import android.os.Binder;
import android.os.IBinder;
import android.os.INetworkManagementService;
import android.os.Message;
import android.os.Messenger;
import android.os.PowerManager;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.Handler;
import android.provider.Settings;
import android.util.EventLog;
import android.util.Log;
import android.util.LruCache;

import com.android.internal.util.Protocol;
import com.android.internal.util.State;
import com.android.internal.util.StateMachine;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import android.util.*;


/**
 * Track the state of Ethernet connectivity. All event handling is done here,
 * and all changes in connectivity state are initiated here.
 *
 *
 * @hide
 */
public class VlanStateMachine extends StateMachine {

    private static final String TAG = "VlanStateMachine";

    private static final boolean DBG = true;
    private VlanManager mVL = null;

    private Handler mTrackerTarget = null;

    private ConnectivityManager mCm;

    private LinkProperties mLinkProperties;

    private Context mContext;

    private DhcpInfoInternal mDhcpInfoInternal;
    private NetworkInfo mNetworkInfo;
    private DhcpStateMachine mDhcpStateMachine;


    /* The base for wifi message types */
    static final int BASE = Protocol.BASE_WIFI;

    /* Indicates Static IP succeded */
    static final int CMD_STATIC_IP_SUCCESS                = BASE + 15;
    /* Indicates Static IP failed */
    static final int CMD_STATIC_IP_FAILURE                = BASE + 16;

    /* Default parent state */
    private State mDefaultState = new DefaultState();
    /* Temporary initial state */
    private State mInitialState = new InitialState();

    private State mVLANRemovedState = new VLANRemovedState();

    private State mVLANAddedState = new VLANAddedState();

    /* Fetching IP */
    private State mConnectingState = new ConnectingState();

    /* Connected with IP addr */
    private State mConnectedState = new ConnectedState();

    /* disconnect issued, waiting for network disconnect confirmation */
    private State mDisconnectingState = new DisconnectingState();

    /* Network is not connected */
    private State mDisconnectedState = new DisconnectedState();


    public VlanStateMachine(Context context,int networkType) {
        super(TAG);

        mContext = context;

        mNetworkInfo = new NetworkInfo(networkType, 0, ConnectivityManager.getNetworkTypeName(networkType), "");

        mDhcpInfoInternal = new DhcpInfoInternal();

        mLinkProperties = new LinkProperties();

        mNetworkInfo.setIsAvailable(false);
        mLinkProperties.clear();


        addState(mDefaultState);
            addState(mInitialState, mDefaultState);
            addState(mVLANAddedState, mDefaultState);
            addState(mVLANRemovedState, mDefaultState);
            addState(mConnectingState, mDefaultState);
            addState(mConnectedState, mDefaultState);
            addState(mDisconnectingState, mDefaultState);
            addState(mDisconnectedState, mDefaultState);

        setInitialState(mInitialState);

        if (DBG) setDbg(true);

        //start the state machine
        start();
    }
    
    private boolean isDhcpConnectMode() {
        final ContentResolver cr = mContext.getContentResolver();
        String connectMode = Settings.Secure.getString(cr, Settings.Secure.VLAN_MODE);
        Slog.d(TAG, "VLAN_MODE: " + connectMode + "\n");
        if (VlanDevInfo.VLAN_CONN_MODE_DHCP_AUTH.equals(connectMode)
                || VlanDevInfo.VLAN_CONN_MODE_DHCP.equals(connectMode)) {
            return true;
        } else {
            return false;
        }
    }

    /*********************************************************
     * Methods exposed for public use
     ********************************************************/
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        String LS = System.getProperty("line.separator");
        sb.append("current HSM state: ").append(getCurrentState().getName()).append(LS);
        sb.append("mLinkProperties ").append(mLinkProperties).append(LS);
        sb.append("mDhcpInfoInternal ").append(mDhcpInfoInternal).append(LS);
        sb.append("mNetworkInfo ").append(mNetworkInfo).append(LS);

        return sb.toString();
    }


    void handlePreDhcpSetup() {
        Slog.d(TAG, "Received CMD_PRE_DHCP_ACTION, DO NOTHING currently :-)\n");
    }


    void handlePostDhcpSetup() {
        Slog.d(TAG, "Received CMD_POST_DHCP_ACTION, DO NOTHING currently :-)\n");
    }

    void handleStopDhcpSetup() {
        Slog.d(TAG, "Received CMD_STOP_DHCP_ACTION, DO NOTHING currently :-)\n");
    }

    public void startDhcp(String ifname) {
        if (DBG) Slog.d(TAG, "VLAN startDhcp: send CMD_START_DHCP");
        //if (mDhcpStateMachine == null) {
            mDhcpStateMachine = DhcpStateMachine.makeDhcpStateMachine(
                    mContext, VlanStateMachine.this, ifname);
        //}
        if (!ifname.equals(mDhcpStateMachine.getInterfaceName())) {
            if (DBG) Slog.d(TAG, "startDhcp on another intferface" );
            mDhcpStateMachine.sendMessage(DhcpStateMachine.CMD_STOP_DHCP);
            mDhcpStateMachine = DhcpStateMachine.makeDhcpStateMachine(
                    mContext, VlanStateMachine.this, ifname);
        }
        else {
            if (DBG) Slog.d(TAG, "startDhcp: DhcpStateMachine exists!!!");
        }
        //mDhcpStateMachine.registerForPreDhcpNotification();
        mDhcpStateMachine.sendMessage(DhcpStateMachine.CMD_START_DHCP);
    }

    public void stopDhcp() {
        if (DBG && mDhcpStateMachine == null) Slog.d(TAG, "stopDhcp: DO NOTHING");
        if (mDhcpStateMachine != null) {
            if (DBG) Slog.d(TAG, "VLAN stopDhcp: send CMD_STOP_DHCP");
            mDhcpStateMachine.sendMessage(DhcpStateMachine.CMD_STOP_DHCP);
        }
    }

    /********************************************************
     * HSM states
     *******************************************************/

    class DefaultState extends State {
        @Override
        public boolean processMessage(Message message) {
            if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");

            return HANDLED;
        }
    }

    class InitialState extends State {
        @Override
        public void enter() {
            if (DBG) Slog.d(TAG, getName() + "\n");
        }

        @Override
        public boolean processMessage(Message message) {
            if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");
            switch(message.what) {
            case DhcpStateMachine.CMD_PRE_DHCP_ACTION:
                handlePreDhcpSetup();
                mDhcpStateMachine.sendMessage(DhcpStateMachine.CMD_PRE_DHCP_ACTION_COMPLETE);
                break;
            case DhcpStateMachine.CMD_POST_DHCP_ACTION:
                handlePostDhcpSetup();
                if(!isDhcpConnectMode()) {
                    Slog.d(TAG, "Fixme: ConnectMode is changed, is not dhcp, do not send dhcp fail or success msg! ???\n");
                }
                if (message.arg1 == DhcpStateMachine.DHCP_SUCCESS) {
                    Message msg = mTrackerTarget.obtainMessage(VlanStateTracker.EVENT_INTERFACE_CONFIGURATION_SUCCEEDED, message.obj);
                    msg.sendToTarget();
                } else if (message.arg1 == DhcpStateMachine.DHCP_FAILURE) {
                    mTrackerTarget.sendEmptyMessage(VlanStateTracker.EVENT_INTERFACE_CONFIGURATION_FAILED);
                }
                break;
            case DhcpStateMachine.CMD_STOP_DHCP:
                handleStopDhcpSetup();
                break;
            default:
                return NOT_HANDLED;
            }

            return HANDLED;
        }
    }


    class VLANAddedState extends State {
        @Override
        public void enter() {
            if (DBG) Slog.d(TAG, getName() + "\n");
        }

        @Override
        public boolean processMessage(Message message) {
            if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");

            return HANDLED;
        }

        @Override
        public void exit() {
        }
    }


    class VLANRemovedState extends State {
        @Override
        public void enter() {
            if (DBG) Slog.d(TAG, getName() + "\n");
        }
        @Override
        public boolean processMessage(Message message) {
            if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");

            return HANDLED;
        }

        @Override
        public void exit() {
        }
    }


    class ConnectingState extends State {

        @Override
        public void enter() {
            if (DBG) Slog.d(TAG, getName() + "\n");
        }
      @Override
      public boolean processMessage(Message message) {
          if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");

          return HANDLED;
      }
    }

    class ConnectedState extends State {
        @Override
        public void enter() {
            if (DBG) Slog.d(TAG, getName() + "\n");

        }
        @Override
        public boolean processMessage(Message message) {
            if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");

            return HANDLED;
        }
        @Override
        public void exit() {

        }
    }

    class DisconnectingState extends State {
        @Override
        public void enter() {
            if (DBG) Slog.d(TAG, getName() + "\n");

        }
        @Override
        public boolean processMessage(Message message) {
            if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");

            return HANDLED;
        }
    }

    class DisconnectedState extends State {
        @Override
        public void enter() {
            if (DBG) Slog.d(TAG, getName() + "\n");


        }
        @Override
        public boolean processMessage(Message message) {
            if (DBG) Slog.d(TAG, getName() + message.toString() + "\n");

            return HANDLED;
        }

        @Override
        public void exit() {
        }
    }

    public void setTrackerTarget(Handler trackerTarget) {
        mTrackerTarget = trackerTarget;
    }
}

