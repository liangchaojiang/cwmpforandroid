package com.zhangwoshenghuo.netcwmp;

public class JniInter {

	static {
		System.loadLibrary("tr111");
	}
	public native int tr111test();
}
