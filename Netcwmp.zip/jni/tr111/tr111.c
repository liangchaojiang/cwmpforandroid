#include "tr111.h"


#ifdef ANDROID
#include <jni.h>
#include <android/log.h>
#define LOGE(format, ...)  __android_log_print(ANDROID_LOG_ERROR, "(>_<)", format, ##__VA_ARGS__)
#define LOGI(format, ...)  __android_log_print(ANDROID_LOG_INFO,  "(=_=)", format, ##__VA_ARGS__)
#else
#define LOGE(format, ...)  printf("(>_<) " format "\n", ##__VA_ARGS__)
#define LOGI(format, ...)  printf("(^_^) " format "\n", ##__VA_ARGS__)
#endif



#define STUN_MESSAGE_LEN 128
static unsigned char msg[STUN_MESSAGE_LEN];
//static unsigned char msg_changed[STUN_MESSAGE_LEN];
//static unsigned char msg_cred[STUN_MESSAGE_LEN];
//static unsigned char msg_cred_changed[STUN_MESSAGE_LEN];
static unsigned char msg_resp_addr[STUN_MESSAGE_LEN];
static unsigned char msg_cred_resp_addr[STUN_MESSAGE_LEN];
//static unsigned char *sent_msg;


#define UNIT_TYPE(m)  ((m)[0] * 256 + (m)[1])
#define UNIT_LEN(m)   ((m)[2] * 256 + (m)[3])
#define MSG_LEN(m)    (UNIT_LEN(m) + 20)
#define FIRST_ATTR(m) ((m) + 20)
#define NEXT_ATTR(m)  ((m) + 4 + UNIT_LEN(m))



static void init_stun_request(unsigned char *m)//the header length is 20byte and the message is variable its length was assigned by m[2]&m[3]
{

    char *t_id = "0101010101010101";//事物ID
	memset(m,0,STUN_MESSAGE_LEN);
	m[0] = 0x00;
	m[1] = 0x01;//前两个字节代表消息类型 0x0001：捆绑请求  0x0101：捆绑响应    0x0111：捆绑错误响应     0x0002：共享私密请求     0x0102：共享私密响应    0x0112：共享私密错误响应
                //the m[2]&m[3]is the length of message without the header
	memcpy(m + 4, t_id, MIN(16, strlen(t_id)));

}

static void add_attribute(unsigned char *m, uint16_t type, char *data, uint16_t len)
{
    uint16_t *d;
    uint16_t l;
    d = (uint16_t *)(m + MSG_LEN(m));
    l = len % 4 == 0 ? len : len + 4 - (len % 4);
    *d++ = htons(type);
    *d++ = htons(l);

    if (len > 0)
        memcpy(d, data, len);

    d = (uint16_t *)(m + 2);

    *d = htons(MSG_LEN(m) - 16 + l);
}

static void init_message(unsigned char * m)
{

    /* Connection-Request-Binding tr111 attribute type 0xc001*/
    char *crb = "\x64\x73\x6C\x66\x6F\x72\x75\x6D\x2E\x6F\x72\x67\x2F\x54\x52\x2D\x31\x31\x31\x20";
    init_stun_request(m);

     /* Add the Connection-Request-Binding Attribute */
     if (m != msg_resp_addr && m != msg_cred_resp_addr) {
        add_attribute(m, 0xC001, crb, 20);
    } else { /* Add the RESPONSE-ADDRESS Attribute */


    }
     /*0x0006 add username attribute*/
     add_attribute(m,0x0006,"0047040000021010FF00900a1a000280",32);



}

static void udp_listen(int port,char * ip,unsigned char *m)//set up the udp connection and send the message *m
{

    int socket_descriptor;
    struct sockaddr_in address;//the choice of socket
    bzero(&address,sizeof(address));
    address.sin_family = AF_INET;//sin_family表示协议簇，一般用AF_INET表示TCP/IP协议。
    address.sin_addr.s_addr=inet_addr(ip);//sin_addr是一个联合体，用联合体就可以使用多种方式表示IP地址
    address.sin_port=htons(port);//give the port

    socket_descriptor=socket(AF_INET,SOCK_DGRAM,0);//set the socket domain tcp/ip ,type udp, one type only udp so protocol is 0

    sendto(socket_descriptor,m,MSG_LEN(m),0,(struct sockaddr *)&address,sizeof(address));


}

void test()
{
    init_message(msg);
    udp_listen(3478,"192.168.1.111",msg);

}



