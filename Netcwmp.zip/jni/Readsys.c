#include <stdio.h>
#include <sys/system_properties.h>

void main()
{
	char osVersion[PROP_VALUE_MAX];
	int osVersionLength = __system_property_get("persist.sys.pppoe.user",osVersion);
	printf("the hardware id is %s\n",osVersion);
}
