#include "DeviceInfo.c"
#include "ManagementServer.c"
#include "WANDevice.c"
#include "WANConnectionDevice.c"
#include "WANIPConnection.c"



char* cpe_get_igd_device_summary(void * arg, void * pool)
{
    //pool_t * p = (pool_t *)pool;
    return	NULL;
}

char* cpe_get_igd_lan_device_number_of_entries(void * arg, void * pool)
{
    //pool_t * p = (pool_t *)pool;
    return NULL;
}





