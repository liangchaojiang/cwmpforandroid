/** Automatically generated file. DO NOT MODIFY */
package com.zhangwoshenghuo.netcwmp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}